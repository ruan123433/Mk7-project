# Gerar o APK do MT7 Keymapper 2.6.0

Este ZIP contém o código-fonte, não um APK pronto.

## Gerar pelo Android Studio

1. Instale Android Studio e JDK 17 ou superior.
2. Instale Android SDK Platform 37, Build-Tools compatíveis, NDK 28.2.13676358 e CMake 3.22.1.
3. Instale Gradle 9.6.0 e, na raiz do projeto, gere o wrapper com `gradle wrapper --gradle-version 9.6.0`.
4. Abra o projeto no Android Studio e sincronize o Gradle.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de depuração deverá ficar em `app/build/outputs/apk/debug/app-debug.apk`.

## Alterações 2.4.6

- Captura EVIOCGRAB aplicada ao nó selecionado como mouse; teclado pode ser informado em um segundo event node, sem grab.
- Falha de grab encerra o modo visão e libera os contatos virtuais.
- Contato da câmera limitado à área direita e reancorado ao atingir as bordas.
- Acúmulo de frações de movimento para não perder deslocamentos com sensibilidade baixa (0,1).
- Sensibilidade de perfil normalizada para décimos; perfis antigos são normalizados ao carregar.
- Direção do scroll corrigida conforme Linux REL_WHEEL.
- Falhas de escrita no uinput são detectadas; helper tenta liberar contatos antes de destruir o dispositivo virtual.
- CMake copia os helpers executáveis para `app/build/generated/mt7-jniLibs/<abi>`; o Gradle inclui essa pasta e usa extração legacy para que os helpers fiquem disponíveis em `nativeLibraryDir`.

## Limitações

`EVIOCGRAB` congela a entrega dos eventos do mouse aos outros consumidores, mas não garante que o desenho da seta desapareça globalmente. O modo visão ainda precisa de validação em aparelho real; a área de mira é um ponto de partida genérico. Para teclado e mouse em nós separados, é necessário informar os dois caminhos ao iniciar `PrivilegedOtgMappingSession`.

Não houve build Gradle completo nem teste físico no Redmi Note 14 / Android 16 nesta revisão. Não considerar o MT7 pronto para jogar até essas validações e a integração com a interface/serviço serem concluídas.


## Alterações 2.4.6

- Painel de dispositivos permite atribuir separadamente event nodes como mouse e teclado e memoriza as escolhas.
- Diagnóstico do mouse usa helper EVIOCGRAB; teclado separado usa getevent sem grab.
- A confirmação de ativação/liberação do grab é aguardada e validada pelo retorno nativo; eventos são despachados fora da thread de leitura do helper.
- A ocultação global da seta ainda não está resolvida por EVIOCGRAB.
