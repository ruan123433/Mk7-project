# Correções na montagem do APK 3.11.0-dev7

- MappingProfile.kt (linha 72): a verificação das sensibilidades dos modos Normal/Combate/Precisão
  comparava `it * 10f` com `it.roundToInt()` em vez de `(it * 10f).roundToInt()`. Com isso, qualquer
  perfil com sensibilidade quebrada (ex.: 1,2 ou 0,8, que são os padrões) era recusado e o app fechava
  ao criar ou carregar perfis. 5 testes falhavam por isso. Corrigido.
- app/build.gradle.kts: versão atualizada de 3.10.0-dev1 (49) para 3.11.0-dev7 (50).
- Resultado: 104 testes passando e `:app:assembleDebug` concluído.

## Assinatura
`assinatura/debug.keystore` é a chave de teste usada neste APK (senha `android`, alias `androiddebugkey`).
Copie para `~/.android/debug.keystore` antes de montar as próximas versões para poder instalar por cima.
