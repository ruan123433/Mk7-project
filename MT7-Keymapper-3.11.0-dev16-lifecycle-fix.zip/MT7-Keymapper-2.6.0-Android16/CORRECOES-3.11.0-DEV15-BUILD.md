# MT7 Keymapper 3.11.0-dev15 — preparação do APK

## Ajustes nesta revisão
- `versionName` atualizado para `3.11.0-dev15` e `versionCode` para 54.
- Assinatura de debug configurada explicitamente usando `assinatura/debug.keystore`, para que builds sucessivos deste repositório possam atualizar a instalação anterior sem erro de assinatura.
- Workflow valida a existência do APK antes de publicar o artefato.
- Workflow publica também os relatórios de testes unitários, mesmo quando os testes falham.
- README reorganizado com os dados atuais do projeto e instruções de geração/instalação.

## Verificações feitas neste ambiente
- ZIP original testado com `unzip -t`: íntegro.
- Keystore testado com `keytool`: alias `androiddebugkey` presente.
- `input_grab.cpp` e `uinput_probe.cpp` passaram pela verificação sintática C++17 com `-Wall -Wextra -Werror` no host.
- `native_bridge.cpp` não pôde ser verificado no host porque o ambiente não contém `jni.h`/Android NDK.

## O que ainda falta
Este ambiente não possui Android SDK, Android NDK, Gradle instalado ou `gradle-wrapper.jar`; portanto não foi possível executar `:app:testDebugUnitTest`, `assembleDebug` nem instalar/testar o APK. O arquivo APK não é incluído neste ZIP. Para obtê-lo, envie a pasta do projeto para o GitHub e execute o workflow `.github/workflows/android-build.yml`. Só considere o APK pronto quando o workflow concluir com sucesso e publicar o artefato.
