package com.mt7.keymapper

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.mt7.keymapper.core.mapping.MappingProfile
import com.mt7.keymapper.core.mapping.KeyTapBindings
import com.mt7.keymapper.core.mapping.KeyComboBindings
import com.mt7.keymapper.core.mapping.KeyComboBinding
import com.mt7.keymapper.core.input.OtgEventMapper
import com.mt7.keymapper.core.mapping.ControlMarker
import com.mt7.keymapper.core.mapping.ControlPositionMath
import com.mt7.keymapper.core.mapping.ProfileStore
import com.mt7.keymapper.core.mapping.JoystickSettings
import com.mt7.keymapper.core.mapping.JoystickVector
import com.mt7.keymapper.core.mapping.FireMode
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Slider
import com.mt7.keymapper.core.activation.BackendKind
import com.mt7.keymapper.core.activation.BackendStatus
import com.mt7.keymapper.core.mapping.PointerDelta
import com.mt7.keymapper.core.mapping.VisionSettings
import com.mt7.keymapper.core.runtime.LocalTestEventSource
import com.mt7.keymapper.core.runtime.LocalMappingSession
import com.mt7.keymapper.core.runtime.RuntimeState
import com.mt7.keymapper.ui.devices.InputDeviceDiagnosticsPanel
import com.mt7.keymapper.ui.devices.MouseDiagnosticsPanel
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mt7.keymapper.core.activation.ActivationRepository
import com.mt7.keymapper.core.permissions.PermissionManager
import com.mt7.keymapper.service.MT7InputService
import com.mt7.keymapper.ui.permissions.PermissionScreen
import com.mt7.keymapper.ui.theme.MT7Theme
import androidx.compose.foundation.background
import androidx.compose.ui.unit.sp
import com.mt7.keymapper.core.permissions.PermissionState
import com.mt7.keymapper.ui.apps.AppsScreen
import com.mt7.keymapper.ui.home.HomeScreen
import com.mt7.keymapper.ui.theme.Neon
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private lateinit var permissionManager: PermissionManager
    private val activationRepository = ActivationRepository()

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST_CODE) {
            // The Compose screen refreshes when the user returns to the app.
            shizukuGrantResult = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    private var shizukuGrantResult: Boolean? = null

    override fun onStart() {
        super.onStart()
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
    }

    override fun onStop() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        super.onStop()
    }

    private var resumeTick by mutableStateOf(0)

    override fun onResume() {
        super.onResume()
        // Refresh permission/backend status when the user returns from system settings.
        resumeTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionManager = PermissionManager(this)

        setContent {
            MT7Theme {
                var selectedTab by remember { mutableStateOf(0) }
                var moreTab by remember { mutableStateOf(0) }
                var shizukuStatus by remember { mutableStateOf(activationRepository.inspectShizukuNow()) }
                var rootStatus by remember { mutableStateOf(BackendStatus(BackendKind.ROOT, false, "Verificando root…")) }
                var message by remember { mutableStateOf("Escolha um método de ativação.") }
                var mappedCount by remember { mutableStateOf(com.mt7.keymapper.ui.apps.MappedApps.get(this@MainActivity).size) }
                val tick = resumeTick
                val permissionItems = remember(tick, shizukuStatus, rootStatus) {
                    permissionManager.getItems(shizukuStatus.available, rootStatus.available)
                }
                LaunchedEffect(tick) {
                    shizukuStatus = activationRepository.inspectShizukuNow()
                    rootStatus = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        activationRepository.inspectRootNow()
                    }
                }

                Scaffold(
                    containerColor = Color.Transparent,
                    modifier = Modifier.fillMaxSize().background(Neon.Background),
                    bottomBar = {
                        NavigationBar(containerColor = Neon.Panel, tonalElevation = 0.dp) {
                            listOf("🏠" to "Início", "🎮" to "Apps", "🛡" to "Permissões", "⚙" to "Avançado")
                                .forEachIndexed { index, (icon, label) ->
                                    NavigationBarItem(
                                        selected = selectedTab == index,
                                        onClick = { selectedTab = index },
                                        icon = { Text(icon, fontSize = 20.sp) },
                                        label = { Text(label, fontWeight = FontWeight.Bold) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedTextColor = Neon.Cyan,
                                            unselectedTextColor = Neon.Muted,
                                            indicatorColor = Neon.Magenta.copy(alpha = 0.25f)
                                        )
                                    )
                                }
                        }
                    }
                ) { padding ->
                    Box(Modifier.fillMaxSize().padding(padding)) {
                        when (selectedTab) {
                            0 -> HomeScreen(
                                shizukuOk = shizukuStatus.available,
                                rootOk = rootStatus.available,
                                permissionsGranted = permissionItems.count { it.granted && it.state == PermissionState.REQUIRED },
                                permissionsTotal = permissionItems.count { it.state == PermissionState.REQUIRED },
                                mappedApps = mappedCount,
                                message = message,
                                onPermissions = { selectedTab = 2 },
                                onApps = { selectedTab = 1 }
                            )
                            1 -> AppsScreen(
                                onMappedChanged = { mappedCount = it },
                                onLaunch = { packageName ->
                                    val serviceIntent = Intent(this@MainActivity, MT7InputService::class.java).apply {
                                        action = MT7InputService.ACTION_AUTO_START
                                        putExtra(MT7InputService.EXTRA_TARGET_PACKAGE, packageName)
                                    }
                                    runCatching { ContextCompat.startForegroundService(this@MainActivity, serviceIntent) }
                                }
                            )
                            2 -> PermissionScreen(
                                items = permissionItems,
                                onOpen = { item ->
                                    when (item.id) {
                                        "shizuku" -> { selectedTab = 3 }
                                        "root" -> { moreTab = 1; selectedTab = 3 }
                                        else -> permissionManager.openAction(item)
                                    }
                                }
                            )
                            else -> Column(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Spacer(Modifier.height(6.dp))
                                Text("Avançado", color = Neon.Cyan, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                                ScrollableTabRow(
                                    selectedTabIndex = moreTab,
                                    containerColor = Color.Transparent,
                                    contentColor = Neon.Cyan,
                                    edgePadding = 0.dp
                                ) {
                                    listOf("Shizuku", "Root", "Dispositivos", "Mouse").forEachIndexed { i, t ->
                                        Tab(selected = moreTab == i, onClick = { moreTab = i }, text = { Text(t) })
                                    }
                                }
                                Box(Modifier.weight(1f).fillMaxWidth()) {
                                    when (moreTab) {
                                        0 -> BackendPanel(
                                            title = "Backend Shizuku",
                                            status = if (shizukuStatus.available) "AUTORIZADO" else "NÃO AUTORIZADO",
                                            detail = shizukuStatus.detail,
                                            explanation = "Abra o app Shizuku, inicie o serviço e depois toque em Solicitar autorização.",
                                            primaryAction = "Solicitar autorização Shizuku",
                                            onPrimary = {
                                                val alive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
                                                if (alive) {
                                                    runCatching { Shizuku.requestPermission(SHIZUKU_REQUEST_CODE) }
                                                        .onSuccess { message = "Pedido enviado. Responda à janela do Shizuku." }
                                                        .onFailure { message = "Não foi possível solicitar: ${it.message}" }
                                                } else {
                                                    message = "Shizuku não está iniciado."
                                                }
                                            },
                                            onRefresh = {
                                                shizukuStatus = activationRepository.inspectShizukuNow()
                                                message = shizukuGrantResult?.let {
                                                    if (it) "Autorização Shizuku concedida." else "Autorização Shizuku negada."
                                                } ?: "Estado Shizuku atualizado."
                                            }
                                        )
                                        1 -> BackendPanel(
                                            title = "Backend Root",
                                            status = if (rootStatus.available) "ROOT AUTORIZADO" else "ROOT NÃO AUTORIZADO",
                                            detail = rootStatus.detail,
                                            explanation = "A verificação executa apenas id via su; aceite o pedido no gerenciador de root.",
                                            primaryAction = "Verificar Root",
                                            onPrimary = { rootStatus = activationRepository.inspectRootNow(); message = rootStatus.detail },
                                            onRefresh = { rootStatus = activationRepository.inspectRootNow(); message = rootStatus.detail }
                                        )
                                        2 -> InputDeviceDiagnosticsPanel(modifier = Modifier.fillMaxSize())
                                        else -> MouseDiagnosticsPanel(modifier = Modifier.fillMaxSize())
                                    }
                                }
                                if (moreTab < 2) {
                                    Text(message, color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    companion object {
        private const val SHIZUKU_REQUEST_CODE = 701
        const val EXTRA_OPEN_MAPPING_EDITOR = "com.mt7.keymapper.extra.OPEN_MAPPING_EDITOR"
    }
}

@Composable
private fun GeneralSettingsPanel(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE) }
    var pollingHz by remember { mutableIntStateOf(prefs.getInt("polling_hz", 250).let { if (it in listOf(125, 250, 500, 1000)) it else 250 }) }
    var cursorSize by remember { mutableFloatStateOf(prefs.getFloat("cursor_size_dp", 34f).coerceIn(18f, 64f)) }
    var cursorSpeed by remember { mutableFloatStateOf(prefs.getFloat("cursor_speed", 1f).coerceIn(0.25f, 3f)) }
    var suspendPointer by remember { mutableStateOf(prefs.getBoolean("suspend_pointer_while_aiming", true)) }
    val optPrefs = remember { context.getSharedPreferences("mt7_optimization", android.content.Context.MODE_PRIVATE) }
    var optFilter by remember { mutableFloatStateOf(optPrefs.getFloat("filter", 0f).coerceIn(0f, 0.8f)) }
    var optThreshold by remember { mutableFloatStateOf(optPrefs.getFloat("threshold", 0f).coerceIn(0f, 4f)) }
    var optBurst by remember { mutableFloatStateOf(optPrefs.getFloat("burst", 0f).coerceIn(0f, 0.5f)) }
    var optBrake by remember { mutableFloatStateOf(optPrefs.getFloat("brake", 0f).coerceIn(0f, 0.8f)) }
    Card(modifier = modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("CONFIGURAÇÕES GERAIS", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Text("Ajustes do cursor e da resposta do mouse. Sensibilidade de mira fica em Editar Keymap > Vista.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Preferência de Hz: $pollingHz Hz", color = Color.White, fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(125, 250, 500, 1000).forEach { hz ->
                    FilterChip(selected = pollingHz == hz, onClick = { pollingHz = hz; prefs.edit().putInt("polling_hz", hz).apply() }, label = { Text(hz.toString()) })
                }
            }
            Text("Tamanho da seta: ${cursorSize.toInt()} dp", color = Color.White, fontWeight = FontWeight.SemiBold)
            Slider(value = cursorSize, onValueChange = { cursorSize = it; prefs.edit().putFloat("cursor_size_dp", it).apply() }, valueRange = 18f..64f)
            Text("Velocidade da seta: ${"%.2f".format(cursorSpeed)}x", color = Color.White, fontWeight = FontWeight.SemiBold)
            Slider(value = cursorSpeed, onValueChange = { cursorSpeed = it; prefs.edit().putFloat("cursor_speed", it).apply() }, valueRange = 0.25f..3f)
            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("Usar seta própria do MT7", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Ao iniciar o mapeamento, oculta a seta do Android e usa o cursor independente do MT7.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = suspendPointer, onCheckedChange = { suspendPointer = it; prefs.edit().putBoolean("suspend_pointer_while_aiming", it).apply() })
            }
            Divider(color = Color(0xFF233B55))
            Text("OTIMIZAÇÃO DE TESTE • CÂMERA", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Estes controles atuam no deslocamento relativo que movimenta a câmera durante a Vista, não apenas na seta. Os valores neutros (0) mantêm o comportamento original.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Filtro de movimento: ${"%.2f".format(optFilter)}")
            Slider(value = optFilter, onValueChange = { optFilter = it; optPrefs.edit().putFloat("filter", it).apply() }, valueRange = 0f..0.8f)
            Text("Limiar de micro movimento: ${"%.1f".format(optThreshold)}")
            Slider(value = optThreshold, onValueChange = { optThreshold = it; optPrefs.edit().putFloat("threshold", it).apply() }, valueRange = 0f..4f)
            Text("Burst em movimentos rápidos: ${"%.2f".format(optBurst)}")
            Slider(value = optBurst, onValueChange = { optBurst = it; optPrefs.edit().putFloat("burst", it).apply() }, valueRange = 0f..0.5f)
            Text("Freio em correções pequenas: ${"%.2f".format(optBrake)}")
            Slider(value = optBrake, onValueChange = { optBrake = it; optPrefs.edit().putFloat("brake", it).apply() }, valueRange = 0f..0.8f)
            OutlinedButton(onClick = {
                optFilter = 0f; optThreshold = 0f; optBurst = 0f; optBrake = 0f
                optPrefs.edit().putFloat("filter", 0f).putFloat("threshold", 0f).putFloat("burst", 0f).putFloat("brake", 0f).apply()
            }, modifier = Modifier.fillMaxWidth()) { Text("Restaurar otimização neutra") }
            Text("Observação: Hz é uma preferência interna; não altera a taxa USB física nem o firmware do mouse. Os ajustes experimentais entram em vigor ao iniciar novamente o mapeamento OTG.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun BackendPanel(
    title: String,
    status: String,
    detail: String,
    explanation: String,
    primaryAction: String,
    onPrimary: () -> Unit,
    onRefresh: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, color = Color(0xFF1597FF), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(status, color = Color(0xFF35D07F), style = MaterialTheme.typography.labelLarge)
            Text(detail, color = Color.White, style = MaterialTheme.typography.bodyMedium)
            Text(explanation, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Button(onClick = onPrimary, modifier = Modifier.fillMaxWidth()) { Text(primaryAction) }
            OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Atualizar estado") }
        }
    }
}


@Composable
private fun LocalRuntimeTestPanel(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val session = remember { LocalMappingSession() }
    val eventSource = remember { LocalTestEventSource() }
    val profileStore = remember { ProfileStore(context.applicationContext) }

    var profiles by remember { mutableStateOf(profileStore.loadAll()) }
    var activeProfile by remember { mutableStateOf(profiles.first()) }
    var profileName by remember { mutableStateOf(activeProfile.name) }
    var sensitivityX by remember { mutableFloatStateOf(activeProfile.sensitivityX.coerceAtLeast(0.2f)) }
    var sensitivityY by remember { mutableFloatStateOf(activeProfile.sensitivityY.coerceAtMost((activeProfile.sensitivityX - 0.1f).coerceAtLeast(0.1f)) ) }
    var viewMode by remember { mutableStateOf(activeProfile.viewMode) }
    var normalSensitivityX by remember { mutableFloatStateOf(activeProfile.normalSensitivityX.coerceAtLeast(0.2f)) }
    var normalSensitivityY by remember { mutableFloatStateOf(activeProfile.normalSensitivityY.coerceAtMost((activeProfile.normalSensitivityX - 0.1f).coerceAtLeast(0.1f))) }
    var combatSensitivityX by remember { mutableFloatStateOf(activeProfile.combatSensitivityX.coerceAtLeast(0.2f)) }
    var combatSensitivityY by remember { mutableFloatStateOf(activeProfile.combatSensitivityY.coerceAtMost((activeProfile.combatSensitivityX - 0.1f).coerceAtLeast(0.1f))) }
    var precisionSensitivityX by remember { mutableFloatStateOf(activeProfile.precisionSensitivityX.coerceAtLeast(0.2f)) }
    var precisionSensitivityY by remember { mutableFloatStateOf(activeProfile.precisionSensitivityY.coerceAtMost((activeProfile.precisionSensitivityX - 0.1f).coerceAtLeast(0.1f))) }
    var joystickSensitivityX by remember { mutableFloatStateOf(activeProfile.joystickSensitivityX) }
    var joystickSensitivityY by remember { mutableFloatStateOf(activeProfile.joystickSensitivityY) }
    var joystickDeadzone by remember { mutableFloatStateOf(activeProfile.joystickDeadzone) }
    var joystickPositionX by remember { mutableFloatStateOf(activeProfile.joystickPositionX) }
    var joystickPositionY by remember { mutableFloatStateOf(activeProfile.joystickPositionY) }
    var viewPositionX by remember { mutableFloatStateOf(activeProfile.viewPositionX) }
    var viewPositionY by remember { mutableFloatStateOf(activeProfile.viewPositionY) }
    var firePositionX by remember { mutableFloatStateOf(activeProfile.firePositionX) }
    var firePositionY by remember { mutableFloatStateOf(activeProfile.firePositionY) }
    var draggedControl by remember { mutableStateOf("Nenhum") }
    var joystickInputX by remember { mutableFloatStateOf(0.5f) }
    var joystickInputY by remember { mutableFloatStateOf(-0.5f) }
    var joystickOutput by remember { mutableStateOf<JoystickVector?>(null) }
    var fireMode by remember { mutableStateOf(activeProfile.fireMode) }
    var keyRepeatDelayMs by remember { mutableIntStateOf(activeProfile.keyRepeatDelayMs.coerceIn(0, 50)) }
    var viewToggleBinding by remember { mutableStateOf(activeProfile.viewToggleBinding) }
    var mouseRightMappedKey by remember { mutableStateOf(activeProfile.mouseRightMappedKey) }
    var scrollUpMappedKey by remember { mutableStateOf(activeProfile.scrollUpMappedKey) }
    var scrollDownMappedKey by remember { mutableStateOf(activeProfile.scrollDownMappedKey) }
    var keyTapsText by remember { mutableStateOf(KeyTapBindings.format(activeProfile.keyTaps)) }
    var keyCombos by remember { mutableStateOf(activeProfile.keyCombos) }
    var comboDraftKeys by remember { mutableStateOf("") }
    var comboDraftTarget by remember { mutableStateOf("ESPAÇO") }
    var fireSnapshot by remember { mutableStateOf(session.fireSnapshot()) }
    var runtimeState by remember { mutableStateOf(session.snapshot()) }
    var inputX by remember { mutableFloatStateOf(1.0f) }
    var inputY by remember { mutableFloatStateOf(1.0f) }
    var output by remember { mutableStateOf<PointerDelta?>(null) }
    var eventMessage by remember { mutableStateOf("Nenhum evento de teste enviado.") }

    LaunchedEffect(activeProfile.id) {
        context.getSharedPreferences("mt7_mapping_points", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("joystick_x", activeProfile.joystickPositionX)
            .putFloat("joystick_y", activeProfile.joystickPositionY)
            .putFloat("view_x", activeProfile.viewPositionX)
            .putFloat("view_y", activeProfile.viewPositionY)
            .putFloat("fire_x", activeProfile.firePositionX)
            .putFloat("fire_y", activeProfile.firePositionY)
            .apply()
        context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("sensitivity_x", activeProfile.sensitivityX)
            .putFloat("sensitivity_y", activeProfile.sensitivityY)
            .putString("view_mode", activeProfile.viewMode)
            .apply()
    }

    fun applyProfile(profile: MappingProfile) {
        context.getSharedPreferences("mt7_mapping_points", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("joystick_x", profile.joystickPositionX)
            .putFloat("joystick_y", profile.joystickPositionY)
            .putFloat("view_x", profile.viewPositionX)
            .putFloat("view_y", profile.viewPositionY)
            .putFloat("fire_x", profile.firePositionX)
            .putFloat("fire_y", profile.firePositionY)
            .apply()
        context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("sensitivity_x", profile.sensitivityX)
            .putFloat("sensitivity_y", profile.sensitivityY)
            .putString("view_mode", profile.viewMode)
            .apply()
        activeProfile = profile
        profileName = profile.name
        sensitivityX = profile.sensitivityX.coerceAtLeast(0.2f)
        sensitivityY = profile.sensitivityY.coerceAtMost((profile.sensitivityX - 0.1f).coerceAtLeast(0.1f))
        viewMode = profile.viewMode
        normalSensitivityX = profile.normalSensitivityX.coerceAtLeast(0.2f)
        normalSensitivityY = profile.normalSensitivityY.coerceAtMost((profile.normalSensitivityX - 0.1f).coerceAtLeast(0.1f))
        combatSensitivityX = profile.combatSensitivityX.coerceAtLeast(0.2f)
        combatSensitivityY = profile.combatSensitivityY.coerceAtMost((profile.combatSensitivityX - 0.1f).coerceAtLeast(0.1f))
        precisionSensitivityX = profile.precisionSensitivityX.coerceAtLeast(0.2f)
        precisionSensitivityY = profile.precisionSensitivityY.coerceAtMost((profile.precisionSensitivityX - 0.1f).coerceAtLeast(0.1f))
        joystickSensitivityX = profile.joystickSensitivityX
        joystickSensitivityY = profile.joystickSensitivityY
        joystickDeadzone = profile.joystickDeadzone
        joystickPositionX = profile.joystickPositionX
        joystickPositionY = profile.joystickPositionY
        viewPositionX = profile.viewPositionX
        viewPositionY = profile.viewPositionY
        firePositionX = profile.firePositionX
        firePositionY = profile.firePositionY
        fireMode = profile.fireMode
        keyRepeatDelayMs = profile.keyRepeatDelayMs.coerceIn(0, 50)
        viewToggleBinding = profile.viewToggleBinding
        mouseRightMappedKey = profile.mouseRightMappedKey
        scrollUpMappedKey = profile.scrollUpMappedKey
        scrollDownMappedKey = profile.scrollDownMappedKey
        keyTapsText = KeyTapBindings.format(profile.keyTaps)
        keyCombos = profile.keyCombos
        comboDraftKeys = ""
        fireSnapshot = session.setFireMode(profile.fireMode)
        output = null
        joystickOutput = null
        eventMessage = "Perfil '${profile.name}' carregado."
    }

    fun rememberCurrentViewSensitivity() {
        when (viewMode) {
            "NORMAL" -> { normalSensitivityX = sensitivityX; normalSensitivityY = sensitivityY }
            "COMBATE" -> { combatSensitivityX = sensitivityX; combatSensitivityY = sensitivityY }
            "PRECISAO" -> { precisionSensitivityX = sensitivityX; precisionSensitivityY = sensitivityY }
        }
    }

    fun selectViewMode(mode: String) {
        rememberCurrentViewSensitivity()
        viewMode = mode
        val values = when (mode) {
            "COMBATE" -> combatSensitivityX to combatSensitivityY
            "PRECISAO" -> precisionSensitivityX to precisionSensitivityY
            else -> normalSensitivityX to normalSensitivityY
        }
        sensitivityX = values.first.coerceAtLeast(0.2f)
        sensitivityY = values.second.coerceAtMost((sensitivityX - 0.1f).coerceAtLeast(0.1f))
        context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE).edit()
            .putFloat("sensitivity_x", values.first)
            .putFloat("sensitivity_y", values.second)
            .putString("view_mode", mode)
            .apply()
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Text("EDITAR KEYMAP", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Text("Posicione joystick, visão e tiro na área de jogo. Salve para aplicar no serviço OTG.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Estado: ${runtimeState.state}", color = if (runtimeState.state == RuntimeState.READY) Color(0xFF35D07F) else Color(0xFF9CB0C7))
            Text(runtimeState.message, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)

            Text("PERFIS", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                profiles.forEach { profile ->
                    FilterChip(
                        selected = activeProfile.id == profile.id,
                        onClick = { applyProfile(profile) },
                        label = { Text(profile.name) }
                    )
                }
            }
            OutlinedTextField(
                value = profileName,
                onValueChange = { profileName = it.take(28) },
                label = { Text("Nome do perfil") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Delay das teclas adicionadas: ${if (keyRepeatDelayMs == 0) "Desativado" else "$keyRepeatDelayMs ms"}")
            Slider(value = keyRepeatDelayMs.coerceIn(1, 50).toFloat(), onValueChange = { keyRepeatDelayMs = it.toInt().coerceIn(1, 50) }, valueRange = 1f..50f, steps = 48)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { keyRepeatDelayMs = 0 }) { Text("Sem delay") }
                Text("1 a 50 ms • intervalo de 1 ms", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            }
            Text("Aplica às teclas livres adicionadas ao Keymap, como A, B, C, D, Espaço e Shift, controlando o intervalo mínimo entre acionamentos.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)

            Divider(color = Color(0xFF233B55))
            Text("VISTA / MIRA", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("MODO DE VISTA", color = Color(0xFF9CB0C7), fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = viewMode == "NORMAL",
                    onClick = { selectViewMode("NORMAL") },
                    label = { Text("Normal") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = viewMode == "COMBATE",
                    onClick = { selectViewMode("COMBATE") },
                    label = { Text("Combate") },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = viewMode == "PRECISAO",
                    onClick = { selectViewMode("PRECISAO") },
                    label = { Text("Precisão") },
                    modifier = Modifier.weight(1f)
                )
            }
            Text(
                when (viewMode) {
                    "COMBATE" -> "Combate: resposta mais rápida para movimentação e trocas próximas."
                    "PRECISAO" -> "Precisão: resposta mais controlada para ajustes finos da mira."
                    else -> "Normal: equilíbrio entre velocidade e controle."
                },
                color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall
            )
            Text("Sensibilidade X (horizontal): ${"%.1f".format(sensitivityX)}")
            Slider(value = sensitivityX, onValueChange = {
                sensitivityX = ((it * 10f).toInt() / 10f).coerceAtLeast(0.2f)
                if (sensitivityY >= sensitivityX) sensitivityY = (sensitivityX - 0.1f).coerceAtLeast(0.1f)
                when (viewMode) {
                    "COMBATE" -> combatSensitivityX = sensitivityX
                    "PRECISAO" -> precisionSensitivityX = sensitivityX
                    else -> normalSensitivityX = sensitivityX
                }
                context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE).edit().putFloat("sensitivity_x", sensitivityX).apply()
            }, valueRange = 0.2f..10f, steps = 97)
            Text("Sensibilidade Y (vertical — sempre menor que X): ${"%.1f".format(sensitivityY)}")
            Slider(value = sensitivityY, onValueChange = {
                sensitivityY = ((it * 10f).toInt() / 10f).coerceAtMost((sensitivityX - 0.1f).coerceAtLeast(0.1f))
                when (viewMode) {
                    "COMBATE" -> combatSensitivityY = sensitivityY
                    "PRECISAO" -> precisionSensitivityY = sensitivityY
                    else -> normalSensitivityY = sensitivityY
                }
                context.getSharedPreferences("mt7_vision", android.content.Context.MODE_PRIVATE).edit().putFloat("sensitivity_y", sensitivityY).apply()
            }, valueRange = 0.1f..(sensitivityX - 0.1f).coerceAtLeast(0.1f), steps = 0)
            OutlinedTextField(
                value = viewToggleBinding,
                onValueChange = { viewToggleBinding = it.take(32) },
                label = { Text("Tecla para ativar Vista e suspender a seta (padrão: Mouse do meio)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Esta tecla ativa/desativa a Vista. A seta própria do MT7 permanece independente durante o mapeamento.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Ações aceitas: Nenhuma, ESPAÇO, R, F ou qualquer tecla livre abaixo. O botão esquerdo permanece reservado ao tiro.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(value = mouseRightMappedKey, onValueChange = { value -> mouseRightMappedKey = if (value.equals("nenhuma", true)) "Nenhuma" else value.uppercase().take(16) }, label = { Text("Ação do botão direito") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = scrollUpMappedKey, onValueChange = { value -> scrollUpMappedKey = if (value.equals("nenhuma", true)) "Nenhuma" else value.uppercase().take(16) }, label = { Text("Ação do scroll para cima") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = scrollDownMappedKey, onValueChange = { value -> scrollDownMappedKey = if (value.equals("nenhuma", true)) "Nenhuma" else value.uppercase().take(16) }, label = { Text("Ação do scroll para baixo") }, singleLine = true, modifier = Modifier.fillMaxWidth())

            Text("TECLAS LIVRES (ESTILO SS KEYMOUSE)", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = keyTapsText,
                onValueChange = { keyTapsText = it.take(600) },
                label = { Text("Tecla = X%, Y% da tela") },
                placeholder = { Text("G=55,80; 1=40,10; Q=60,30; Mouse lateral 1=90,40") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
            val parsedTaps = KeyTapBindings.parse(keyTapsText)
            Text(
                "Segurar a tecla = segurar o dedo naquele ponto. X vai da esquerda (0) à direita (100), Y de cima (0) a baixo (100), com o celular deitado. " +
                    "Aceita letras, números, F1–F12, setas, SHIFT, CTRL, TAB, ESPAÇO e Mouse direito / lateral 1 / lateral 2. W, A, S, D e Mouse esquerdo são do joystick e do tiro. " +
                    "Reconhecidas agora: ${parsedTaps.size}" + if (parsedTaps.isEmpty()) "" else " (${parsedTaps.joinToString { it.key }})",
                color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall
            )

            Divider(color = Color(0xFF233B55))
            Text("COMBINAÇÕES DE TECLAS (COMBOS)", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = comboDraftKeys,
                onValueChange = { comboDraftKeys = it.take(64) },
                label = { Text("Teclas físicas (2 a 4, separadas por +)") },
                placeholder = { Text("CTRL+1 ou SHIFT+Q") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = comboDraftTarget,
                onValueChange = { comboDraftTarget = it.take(16) },
                label = { Text("Ação que será mantida pressionada") },
                placeholder = { Text("ESPAÇO, R, F ou tecla livre cadastrada") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    val keys = comboDraftKeys.split('+').map(KeyComboBindings::canonical).toSet()
                    val target = KeyComboBindings.canonical(comboDraftTarget)
                    val candidate = runCatching { KeyComboBinding(keys, target) }.getOrNull()
                    if (candidate != null && keys.all { it in OtgEventMapper.KNOWN_LABELS && !it.startsWith("Mouse ", true) } &&
                        (target in setOf("ESPAÇO", "R", "F") || target in KeyTapBindings.parse(keyTapsText).map { it.key }) &&
                        keyCombos.size < KeyComboBindings.MAX_BINDINGS && keyCombos.none { it.signature == candidate.signature || it.targetKey == candidate.targetKey }) {
                        keyCombos = keyCombos + candidate
                        comboDraftKeys = ""
                        eventMessage = "Combo ${candidate.signature} → ${candidate.targetKey} adicionado. Salve o perfil para aplicar."
                    } else {
                        eventMessage = "Combo inválido, repetido ou limite de 16 combinações atingido."
                    }
                },
                enabled = keyCombos.size < KeyComboBindings.MAX_BINDINGS,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Adicionar combinação") }
            if (keyCombos.isEmpty()) {
                Text("Nenhum combo configurado.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            } else {
                keyCombos.forEach { combo ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(combo.signature, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("Mantém ${combo.targetKey} pressionado", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { keyCombos = keyCombos.filterNot { it.signature == combo.signature } }) { Text("Remover", color = Color(0xFFFF7B8B)) }
                    }
                }
            }
            Text(
                "Use teclas do teclado (não botões do mouse). A ação deve ser ESPAÇO, R, F ou uma tecla já cadastrada em Teclas livres. Ao soltar uma tecla do combo, a ação é liberada. Até 16 combos por perfil.",
                color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val updated = MappingProfile(
                        id = activeProfile.id,
                        name = profileName.ifBlank { "Meu perfil" },
                        sensitivityX = sensitivityX,
                        sensitivityY = sensitivityY,
                        viewMode = viewMode,
                        normalSensitivityX = normalSensitivityX,
                        normalSensitivityY = normalSensitivityY,
                        combatSensitivityX = combatSensitivityX,
                        combatSensitivityY = combatSensitivityY,
                        precisionSensitivityX = precisionSensitivityX,
                        precisionSensitivityY = precisionSensitivityY,
                        joystickSensitivityX = joystickSensitivityX,
                        joystickSensitivityY = joystickSensitivityY,
                        joystickDeadzone = joystickDeadzone,
                        fireMode = fireMode,
                        keyRepeatDelayMs = keyRepeatDelayMs,
                        joystickPositionX = joystickPositionX,
                        joystickPositionY = joystickPositionY,
                        viewPositionX = viewPositionX,
                        viewPositionY = viewPositionY,
                        firePositionX = firePositionX,
                        firePositionY = firePositionY,
                        viewToggleBinding = viewToggleBinding,
                        mouseRightMappedKey = KeyTapBindings.canonicalKey(mouseRightMappedKey),
                        scrollUpMappedKey = KeyTapBindings.canonicalKey(scrollUpMappedKey),
                        scrollDownMappedKey = KeyTapBindings.canonicalKey(scrollDownMappedKey),
                        keyTaps = KeyTapBindings.parse(keyTapsText),
                        keyCombos = keyCombos
                    )
                    if (profileStore.save(updated)) {
                        profiles = profileStore.loadAll()
                        applyProfile(updated)
                        context.startService(Intent(context, MT7InputService::class.java).apply {
                            action = MT7InputService.ACTION_RELOAD_PROFILE
                            putExtra(MT7InputService.EXTRA_PROFILE_ID, updated.id)
                        })
                        eventMessage = "Perfil salvo e enviado ao serviço MT7."
                    } else {
                        eventMessage = "Não foi possível salvar o perfil."
                    }
                }) { Text("Salvar perfil") }
                OutlinedButton(onClick = {
                    val created = MappingProfile(
                        id = java.util.UUID.randomUUID().toString(),
                        name = profileName.ifBlank { "Novo perfil" },
                        sensitivityX = sensitivityX,
                        sensitivityY = sensitivityY,
                        viewMode = viewMode,
                        normalSensitivityX = normalSensitivityX,
                        normalSensitivityY = normalSensitivityY,
                        combatSensitivityX = combatSensitivityX,
                        combatSensitivityY = combatSensitivityY,
                        precisionSensitivityX = precisionSensitivityX,
                        precisionSensitivityY = precisionSensitivityY,
                        joystickSensitivityX = joystickSensitivityX,
                        joystickSensitivityY = joystickSensitivityY,
                        joystickDeadzone = joystickDeadzone,
                        fireMode = fireMode,
                        keyRepeatDelayMs = keyRepeatDelayMs,
                        joystickPositionX = joystickPositionX,
                        joystickPositionY = joystickPositionY,
                        viewPositionX = viewPositionX,
                        viewPositionY = viewPositionY,
                        firePositionX = firePositionX,
                        firePositionY = firePositionY,
                        viewToggleBinding = viewToggleBinding,
                        mouseRightMappedKey = KeyTapBindings.canonicalKey(mouseRightMappedKey),
                        scrollUpMappedKey = KeyTapBindings.canonicalKey(scrollUpMappedKey),
                        scrollDownMappedKey = KeyTapBindings.canonicalKey(scrollDownMappedKey),
                        keyTaps = KeyTapBindings.parse(keyTapsText),
                        keyCombos = keyCombos
                    )
                    if (profileStore.save(created)) {
                        profiles = profileStore.loadAll()
                        applyProfile(created)
                        context.startService(Intent(context, MT7InputService::class.java).apply {
                            action = MT7InputService.ACTION_RELOAD_PROFILE
                            putExtra(MT7InputService.EXTRA_PROFILE_ID, created.id)
                        })
                        eventMessage = "Novo perfil criado e enviado ao serviço MT7."
                    } else eventMessage = "Falha ao criar perfil."
                }) { Text("Novo") }
            }

            Divider(color = Color(0xFF233B55))
            Text("JOYSTICK", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Sensibilidade horizontal: ${"%.2f".format(joystickSensitivityX)}")
            Slider(value = joystickSensitivityX, onValueChange = { joystickSensitivityX = it; joystickOutput = null }, valueRange = 0.1f..2.0f)
            Text("Sensibilidade vertical: ${"%.2f".format(joystickSensitivityY)}")
            Slider(value = joystickSensitivityY, onValueChange = { joystickSensitivityY = it; joystickOutput = null }, valueRange = 0.1f..2.0f)
            Text("Zona morta: ${"%.2f".format(joystickDeadzone)}")
            Slider(value = joystickDeadzone, onValueChange = { joystickDeadzone = it; joystickOutput = null }, valueRange = 0f..0.5f)
            Text("Entrada do joystick X: ${"%.2f".format(joystickInputX)}")
            Slider(value = joystickInputX, onValueChange = { joystickInputX = it; joystickOutput = null }, valueRange = -1f..1f)
            Text("Entrada do joystick Y: ${"%.2f".format(joystickInputY)}")
            Slider(value = joystickInputY, onValueChange = { joystickInputY = it; joystickOutput = null }, valueRange = -1f..1f)
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = runtimeState.state == RuntimeState.READY,
                onClick = {
                    joystickOutput = session.processJoystick(
                        JoystickVector(joystickInputX, joystickInputY),
                        JoystickSettings(joystickSensitivityX, joystickSensitivityY, joystickDeadzone)
                    )
                    eventMessage = if (joystickOutput != null) "Vetor do joystick calculado na sessão local." else "Evento bloqueado pela sessão."
                }
            ) { Text("Testar joystick") }
            Text("Saída joystick X: ${joystickOutput?.x?.let { "%.2f".format(it) } ?: "--"}")
            Text("Saída joystick Y: ${joystickOutput?.y?.let { "%.2f".format(it) } ?: "--"}")

            Divider(color = Color(0xFF233B55))
            Text("POSIÇÕES DOS CONTROLES", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Prévia proporcional da tela. Ajuste cada marcador pelos controles X/Y.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Canvas(
                modifier = Modifier.fillMaxWidth().height(190.dp).pointerInput(
                    joystickPositionX, joystickPositionY, viewPositionX, viewPositionY,
                    firePositionX, firePositionY
                ) {
                    detectDragGestures(
                        onDragStart = { touch ->
                            val w = size.width.coerceAtLeast(1).toFloat()
                            val h = size.height.coerceAtLeast(1).toFloat()
                            val targets = listOf(
                                ControlMarker("Joystick", joystickPositionX * w, joystickPositionY * h),
                                ControlMarker("Visão", viewPositionX * w, viewPositionY * h),
                                ControlMarker("Atirar", firePositionX * w, firePositionY * h)
                            )
                            draggedControl = ControlPositionMath.nearestMarker(
                                touch.x, touch.y, targets
                            ) ?: "Nenhum"
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            if (draggedControl != "Nenhum") {
                                val nx = ControlPositionMath.normalize(change.position.x, size.width)
                                val ny = ControlPositionMath.normalize(change.position.y, size.height)
                                when (draggedControl) {
                                    "Joystick" -> { joystickPositionX = nx; joystickPositionY = ny }
                                    "Visão" -> { viewPositionX = nx; viewPositionY = ny }
                                    "Atirar" -> { firePositionX = nx; firePositionY = ny }
                                }
                            }
                        },
                        onDragEnd = { draggedControl = "Nenhum" },
                        onDragCancel = { draggedControl = "Nenhum" }
                    )
                }
            ) {
                drawRoundRect(color = Color(0xFF14283D), cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f))
                drawRoundRect(color = Color(0xFF42617F), style = Stroke(width = 2f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(16f, 16f))
                val radius = 15f
                fun marker(x: Float, y: Float, color: Color, selected: Boolean) {
                    val center = Offset(x * size.width, y * size.height)
                    drawCircle(color = color, radius = radius + if (selected) 4f else 0f, center = center)
                    drawCircle(color = Color.White, radius = radius, center = center, style = Stroke(width = 2f))
                }
                marker(joystickPositionX, joystickPositionY, Color(0xFF1597FF), draggedControl == "Joystick")
                marker(viewPositionX, viewPositionY, Color(0xFFFFC857), draggedControl == "Visão")
                marker(firePositionX, firePositionY, Color(0xFF35D07F), draggedControl == "Atirar")
            }
            Text("Arraste os marcadores para reposicionar. Azul: joystick • Amarelo: visão • Verde: atirar", color = Color.White, style = MaterialTheme.typography.bodySmall)
            Text(if (draggedControl == "Nenhum") "Toque e arraste um marcador." else "Movendo: $draggedControl", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Joystick X ${"%.2f".format(joystickPositionX)}  |  Y ${"%.2f".format(joystickPositionY)}")
            Slider(value = joystickPositionX, onValueChange = { joystickPositionX = it }, valueRange = 0f..1f)
            Slider(value = joystickPositionY, onValueChange = { joystickPositionY = it }, valueRange = 0f..1f)
            Text("Visão X ${"%.2f".format(viewPositionX)}  |  Y ${"%.2f".format(viewPositionY)}")
            Slider(value = viewPositionX, onValueChange = { viewPositionX = it }, valueRange = 0f..1f)
            Slider(value = viewPositionY, onValueChange = { viewPositionY = it }, valueRange = 0f..1f)
            Text("Atirar X ${"%.2f".format(firePositionX)}  |  Y ${"%.2f".format(firePositionY)}")
            Slider(value = firePositionX, onValueChange = { firePositionX = it }, valueRange = 0f..1f)
            Slider(value = firePositionY, onValueChange = { firePositionY = it }, valueRange = 0f..1f)

            Divider(color = Color(0xFF233B55))
            Text("BOTÃO DE ATIRAR", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Entrada do botão: Mouse esquerdo (disparo) • posição ajustável no HUD acima.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Modo", color = Color.White)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(FireMode.TAP, FireMode.HOLD, FireMode.TOGGLE).forEach { mode ->
                    FilterChip(
                        selected = fireMode == mode,
                        onClick = {
                            fireMode = mode
                            fireSnapshot = session.setFireMode(mode)
                        },
                        label = {
                            Text(when (mode) {
                                FireMode.TAP -> "Toque"
                                FireMode.HOLD -> "Segurar"
                                FireMode.TOGGLE -> "Alternar"
                            })
                        }
                    )
                }
            }
            Text(
                when (fireMode) {
                    FireMode.TAP -> "Um toque gera pressionar e soltar em sequência no simulador."
                    FireMode.HOLD -> "Pressionar mantém o estado ativo até você tocar em Soltar."
                    FireMode.TOGGLE -> "Cada toque alterna entre pressionado e solto."
                },
                color = Color(0xFF9CB0C7),
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { fireSnapshot = session.activateFire() }) {
                    Text(when (fireMode) {
                        FireMode.TAP -> "Executar toque"
                        FireMode.HOLD -> "Pressionar"
                        FireMode.TOGGLE -> "Alternar estado"
                    })
                }
                OutlinedButton(
                    onClick = { fireSnapshot = session.releaseFire() },
                    enabled = fireMode == FireMode.HOLD && fireSnapshot.isPressed
                ) { Text("Soltar") }
                OutlinedButton(onClick = { fireSnapshot = session.resetFire() }) { Text("Reset") }
            }
            Text(
                "Estado: ${if (fireSnapshot.isPressed) "PRESSIONADO" else "SOLTO"}  •  Transições: ${fireSnapshot.transitionCount}",
                color = if (fireSnapshot.isPressed) Color(0xFF35D07F) else Color.White
            )

            Divider(color = Color(0xFF233B55))
            Text("VISTA (MOUSE)", color = Color(0xFF1597FF), fontWeight = FontWeight.Bold)
            Text("Entrada X: ${"%.2f".format(inputX)}")
            Slider(value = inputX, onValueChange = { inputX = it }, valueRange = -20f..20f)
            Text("Entrada Y: ${"%.2f".format(inputY)}")
            Slider(value = inputY, onValueChange = { inputY = it }, valueRange = -20f..20f)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    runtimeState = session.start(BackendStatus(BackendKind.ANDROID, true, "Backend local de diagnóstico."))
                    eventMessage = "Runtime local iniciado."
                    output = null
                }) { Text("Iniciar") }
                OutlinedButton(onClick = {
                    runtimeState = session.pause()
                    fireSnapshot = session.fireSnapshot()
                    output = null
                    eventMessage = "Eventos bloqueados enquanto estiver pausado."
                }) { Text("Pausar") }
                OutlinedButton(onClick = {
                    runtimeState = session.stop()
                    fireSnapshot = session.fireSnapshot()
                    output = null
                    eventMessage = "Runtime parado."
                }) { Text("Parar") }
            }
            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = runtimeState.state == RuntimeState.READY,
                onClick = {
                    val delta = eventSource.createDelta(inputX, inputY)
                    val settings = VisionSettings(
                        sensitivityX = sensitivityX,
                        sensitivityY = sensitivityY
                    )
                    output = session.processPointer(delta, settings)
                    eventMessage = if (output != null) "Evento processado com o perfil '${activeProfile.name}'." else "Evento bloqueado pelo estado do runtime."
                }
            ) { Text("Enviar evento de teste") }
            Text(eventMessage, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            Text("Saída X: ${output?.x?.let { "%.2f".format(it) } ?: "--"}")
            Text("Saída Y: ${output?.y?.let { "%.2f".format(it) } ?: "--"}")
            Text("Os perfis salvam joystick, posições e modo do botão. A sessão coordena os testes locais e bloqueia eventos quando pausada ou parada. Não captura entradas do sistema, não injeta comandos em jogos ou outros apps e não altera o comportamento interno do Free Fire.", color = Color(0xFFFFC857), style = MaterialTheme.typography.bodySmall)
        }
    }
}

