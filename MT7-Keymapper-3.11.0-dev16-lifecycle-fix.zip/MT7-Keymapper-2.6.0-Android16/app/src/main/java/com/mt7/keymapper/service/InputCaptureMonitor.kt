package com.mt7.keymapper.service

import android.view.KeyEvent
import android.view.MotionEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Lightweight in-app diagnostics for input events supplied by an active capture backend. */
data class InputCaptureSnapshot(
    val keyboardEvents: Long = 0,
    val mouseMoves: Long = 0,
    val mouseButtons: Long = 0,
    val wheelEvents: Long = 0,
    val lastInput: String = "Aguardando entrada OTG",
    val lastDevice: String = "—",
    val lastDeltaX: Float = 0f,
    val lastDeltaY: Float = 0f,
    val mappingActive: Boolean = false
)

object InputCaptureMonitor {
    private val mutable = MutableStateFlow(InputCaptureSnapshot())
    val state: StateFlow<InputCaptureSnapshot> = mutable.asStateFlow()

    fun setMappingActive(active: Boolean) {
        mutable.value = mutable.value.copy(mappingActive = active)
    }

    fun key(event: KeyEvent, deviceName: String) {
        val old = mutable.value
        val action = if (event.action == KeyEvent.ACTION_DOWN) "pressionada" else "liberada"
        mutable.value = old.copy(
            keyboardEvents = old.keyboardEvents + 1,
            lastInput = "Tecla ${KeyEvent.keyCodeToString(event.keyCode)} $action",
            lastDevice = deviceName
        )
    }

    fun mouseMove(dx: Float, dy: Float, deviceName: String) {
        val old = mutable.value
        mutable.value = old.copy(
            mouseMoves = old.mouseMoves + 1,
            lastInput = "Movimento do mouse",
            lastDevice = deviceName,
            lastDeltaX = dx,
            lastDeltaY = dy
        )
    }

    fun mouseButton(event: MotionEvent, buttonName: String, deviceName: String) {
        val old = mutable.value
        val action = if (event.actionMasked == MotionEvent.ACTION_BUTTON_PRESS) "pressionado" else "liberado"
        mutable.value = old.copy(
            mouseButtons = old.mouseButtons + 1,
            lastInput = "$buttonName $action",
            lastDevice = deviceName
        )
    }

    fun wheel(deviceName: String, amount: Float) {
        val old = mutable.value
        mutable.value = old.copy(
            wheelEvents = old.wheelEvents + 1,
            lastInput = "Scroll: ${"%.1f".format(amount)}",
            lastDevice = deviceName
        )
    }

    fun reset() { mutable.value = InputCaptureSnapshot(mappingActive = mutable.value.mappingActive) }
}
