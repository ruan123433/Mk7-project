package com.mt7.keymapper.core.mapping

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.roundToInt

/**
 * Persists user-created mapping profiles locally in app-private preferences.
 */
class ProfileStore(context: Context) {
    private val prefs = context.getSharedPreferences("mt7_profiles", Context.MODE_PRIVATE)

    fun loadAll(): List<MappingProfile> {
        val raw = prefs.getString(KEY_PROFILES, null) ?: return listOf(defaultProfile())
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        MappingProfile(
                            id = item.getString("id"),
                            name = item.getString("name"),
                            sensitivityX = normalizeSensitivity(item.getDouble("x").toFloat()).coerceAtLeast(0.2f),
                            sensitivityY = normalizeSensitivity(item.getDouble("y").toFloat()).coerceAtMost((normalizeSensitivity(item.getDouble("x").toFloat()).coerceAtLeast(0.2f) - 0.1f).coerceAtLeast(0.1f)),
                            viewMode = item.optString("viewMode", "NORMAL").uppercase().let { if (it in setOf("NORMAL", "COMBATE", "PRECISAO")) it else "NORMAL" },
                            normalSensitivityX = normalizeSensitivity(item.optDouble("normalX", item.optDouble("x", 1.2)).toFloat()).coerceAtLeast(0.2f).coerceAtLeast(0.2f),
                            normalSensitivityY = normalizeSensitivity(item.optDouble("normalY", item.optDouble("y", 0.8)).toFloat()).coerceAtMost((normalizeSensitivity(item.optDouble("normalX", item.optDouble("x", 1.2)).toFloat()).coerceAtLeast(0.2f) - 0.1f).coerceAtLeast(0.1f)),
                            combatSensitivityX = normalizeSensitivity(item.optDouble("combatX", 2.0).toFloat()).coerceAtLeast(0.2f),
                            combatSensitivityY = normalizeSensitivity(item.optDouble("combatY", 1.2).toFloat()).coerceAtMost((normalizeSensitivity(item.optDouble("combatX", 2.0).toFloat()).coerceAtLeast(0.2f) - 0.1f).coerceAtLeast(0.1f)),
                            precisionSensitivityX = normalizeSensitivity(item.optDouble("precisionX", 1.0).toFloat()).coerceAtLeast(0.2f),
                            precisionSensitivityY = normalizeSensitivity(item.optDouble("precisionY", 0.5).toFloat()).coerceAtMost((normalizeSensitivity(item.optDouble("precisionX", 1.0).toFloat()).coerceAtLeast(0.2f) - 0.1f).coerceAtLeast(0.1f)),
                            acceleration = item.optDouble("acceleration", 0.0).toFloat(),
                            smoothing = item.optDouble("smoothing", 0.0).toFloat().coerceIn(0f, 0.95f),
                            optimizationFilter = item.optDouble("optFilter", 0.0).toFloat().coerceIn(0f, 0.8f),
                            optimizationThreshold = item.optDouble("optThreshold", 0.0).toFloat().coerceIn(0f, 4f),
                            optimizationBurst = item.optDouble("optBurst", 0.0).toFloat().coerceIn(0f, 0.5f),
                            optimizationBrake = item.optDouble("optBrake", 0.0).toFloat().coerceIn(0f, 0.8f),
                            mouseDpi = item.optInt("mouseDpi", 1200).coerceIn(100, 16000),
                            joystickSensitivityX = item.optDouble("joyX", 1.0).toFloat(),
                            joystickSensitivityY = item.optDouble("joyY", 1.0).toFloat(),
                            joystickDeadzone = item.optDouble("joyDeadzone", 0.08).toFloat(),
                            fireMode = runCatching { FireMode.valueOf(item.optString("fireMode", "TAP")) }.getOrDefault(FireMode.TAP),
                            firePullMultiplier = item.optDouble("firePullMultiplier", 1.0).toFloat().coerceIn(0.5f, 3.0f),
                            keyRepeatDelayMs = item.optInt("keyRepeatDelayMs", 0).coerceIn(0, 50),
                            joystickPositionX = item.optDouble("joyPosX", 0.18).toFloat(),
                            joystickPositionY = item.optDouble("joyPosY", 0.78).toFloat(),
                            viewPositionX = item.optDouble("viewPosX", 0.72).toFloat(),
                            viewPositionY = item.optDouble("viewPosY", 0.48).toFloat(),
                            firePositionX = item.optDouble("firePosX", 0.86).toFloat(),
                            firePositionY = item.optDouble("firePosY", 0.72).toFloat(),
                            jumpPositionX = item.optDouble("jumpPosX", 0.72).toFloat().coerceIn(0f, 1f),
                            jumpPositionY = item.optDouble("jumpPosY", 0.78).toFloat().coerceIn(0f, 1f),
                            reloadPositionX = item.optDouble("reloadPosX", 0.88).toFloat().coerceIn(0f, 1f),
                            reloadPositionY = item.optDouble("reloadPosY", 0.54).toFloat().coerceIn(0f, 1f),
                            interactPositionX = item.optDouble("interactPosX", 0.63).toFloat().coerceIn(0f, 1f),
                            interactPositionY = item.optDouble("interactPosY", 0.72).toFloat().coerceIn(0f, 1f),
                            pollingRateHz = item.optInt("pollingRateHz", VisionSettings.DEFAULT_POLLING_RATE_HZ).let { rate -> if (rate in VisionSettings.SUPPORTED_POLLING_RATES) rate else VisionSettings.DEFAULT_POLLING_RATE_HZ },
                            viewToggleBinding = item.optString("viewToggleBinding", "Mouse do meio"),
                            mouseRightMappedKey = item.optString("mouseRightMappedKey", "Nenhuma"),
                            scrollUpMappedKey = item.optString("scrollUpMappedKey", "Nenhuma"),
                            scrollDownMappedKey = item.optString("scrollDownMappedKey", "Nenhuma"),
                            suspendPointerWhileAiming = item.optBoolean("suspendPointerWhileAiming", true),
                            keyTaps = KeyTapBindings.parse(item.optString("keyTaps", "")),
                            keyCombos = KeyComboBindings.parse(
                                item.optString("keyCombos", ""),
                                setOf("ESPAÇO", "R", "F") + KeyTapBindings.parse(item.optString("keyTaps", "")).map { it.key }
                            ),
                            calibrationImageUri = item.optString("calibrationImageUri", "").takeIf { it.isNotBlank() }
                        )
                    )
                }
            }.ifEmpty { listOf(defaultProfile()) }
        }.getOrElse { listOf(defaultProfile()) }
    }

    fun save(profile: MappingProfile): Boolean {
        val profiles = loadAll().filterNot { it.id == profile.id }.toMutableList()
        profiles.add(profile)
        val array = JSONArray()
        profiles.forEach { p ->
            array.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("x", p.sensitivityX.toDouble())
                    .put("y", p.sensitivityY.toDouble())
                    .put("viewMode", p.viewMode)
                    .put("normalX", p.normalSensitivityX.toDouble()).put("normalY", p.normalSensitivityY.toDouble())
                    .put("combatX", p.combatSensitivityX.toDouble()).put("combatY", p.combatSensitivityY.toDouble())
                    .put("precisionX", p.precisionSensitivityX.toDouble()).put("precisionY", p.precisionSensitivityY.toDouble())
                    .put("acceleration", p.acceleration.toDouble())
                    .put("smoothing", p.smoothing.toDouble())
                    .put("optFilter", p.optimizationFilter.toDouble()).put("optThreshold", p.optimizationThreshold.toDouble())
                    .put("optBurst", p.optimizationBurst.toDouble()).put("optBrake", p.optimizationBrake.toDouble())
                    .put("mouseDpi", p.mouseDpi)
                    .put("joyX", p.joystickSensitivityX.toDouble())
                    .put("joyY", p.joystickSensitivityY.toDouble())
                    .put("joyDeadzone", p.joystickDeadzone.toDouble())
                    .put("fireMode", p.fireMode.name)
                    .put("firePullMultiplier", p.firePullMultiplier.toDouble())
                    .put("keyRepeatDelayMs", p.keyRepeatDelayMs)
                    .put("joyPosX", p.joystickPositionX.toDouble())
                    .put("joyPosY", p.joystickPositionY.toDouble())
                    .put("viewPosX", p.viewPositionX.toDouble())
                    .put("viewPosY", p.viewPositionY.toDouble())
                    .put("firePosX", p.firePositionX.toDouble())
                    .put("firePosY", p.firePositionY.toDouble())
                    .put("jumpPosX", p.jumpPositionX.toDouble()).put("jumpPosY", p.jumpPositionY.toDouble())
                    .put("reloadPosX", p.reloadPositionX.toDouble()).put("reloadPosY", p.reloadPositionY.toDouble())
                    .put("interactPosX", p.interactPositionX.toDouble()).put("interactPosY", p.interactPositionY.toDouble())
                    .put("pollingRateHz", p.pollingRateHz)
                    .put("viewToggleBinding", p.viewToggleBinding)
                    .put("mouseRightMappedKey", p.mouseRightMappedKey)
                    .put("scrollUpMappedKey", p.scrollUpMappedKey)
                    .put("scrollDownMappedKey", p.scrollDownMappedKey)
                    .put("suspendPointerWhileAiming", p.suspendPointerWhileAiming)
                    .put("keyTaps", KeyTapBindings.format(p.keyTaps))
                    .put("keyCombos", KeyComboBindings.format(p.keyCombos))
                    .put("calibrationImageUri", p.calibrationImageUri ?: "")
            )
        }
        return prefs.edit().putString(KEY_PROFILES, array.toString()).commit()
    }

    fun delete(id: String): Boolean {
        val remaining = loadAll().filterNot { it.id == id }
        val array = JSONArray()
        remaining.forEach { p ->
            array.put(
                JSONObject().put("id", p.id).put("name", p.name)
                    .put("x", p.sensitivityX.toDouble()).put("y", p.sensitivityY.toDouble())
                    .put("viewMode", p.viewMode)
                    .put("normalX", p.normalSensitivityX.toDouble()).put("normalY", p.normalSensitivityY.toDouble())
                    .put("combatX", p.combatSensitivityX.toDouble()).put("combatY", p.combatSensitivityY.toDouble())
                    .put("precisionX", p.precisionSensitivityX.toDouble()).put("precisionY", p.precisionSensitivityY.toDouble())
                    .put("acceleration", p.acceleration.toDouble()).put("smoothing", p.smoothing.toDouble())
                    .put("optFilter", p.optimizationFilter.toDouble()).put("optThreshold", p.optimizationThreshold.toDouble())
                    .put("optBurst", p.optimizationBurst.toDouble()).put("optBrake", p.optimizationBrake.toDouble())
                    .put("mouseDpi", p.mouseDpi)
                    .put("joyX", p.joystickSensitivityX.toDouble())
                    .put("joyY", p.joystickSensitivityY.toDouble())
                    .put("joyDeadzone", p.joystickDeadzone.toDouble())
                    .put("fireMode", p.fireMode.name)
                    .put("firePullMultiplier", p.firePullMultiplier.toDouble())
                    .put("keyRepeatDelayMs", p.keyRepeatDelayMs)
                    .put("joyPosX", p.joystickPositionX.toDouble())
                    .put("joyPosY", p.joystickPositionY.toDouble())
                    .put("viewPosX", p.viewPositionX.toDouble())
                    .put("viewPosY", p.viewPositionY.toDouble())
                    .put("firePosX", p.firePositionX.toDouble())
                    .put("firePosY", p.firePositionY.toDouble())
                    .put("jumpPosX", p.jumpPositionX.toDouble()).put("jumpPosY", p.jumpPositionY.toDouble())
                    .put("reloadPosX", p.reloadPositionX.toDouble()).put("reloadPosY", p.reloadPositionY.toDouble())
                    .put("interactPosX", p.interactPositionX.toDouble()).put("interactPosY", p.interactPositionY.toDouble())
                    .put("pollingRateHz", p.pollingRateHz)
                    .put("viewToggleBinding", p.viewToggleBinding)
                    .put("mouseRightMappedKey", p.mouseRightMappedKey)
                    .put("scrollUpMappedKey", p.scrollUpMappedKey)
                    .put("scrollDownMappedKey", p.scrollDownMappedKey)
                    .put("suspendPointerWhileAiming", p.suspendPointerWhileAiming)
                    .put("keyTaps", KeyTapBindings.format(p.keyTaps))
                    .put("keyCombos", KeyComboBindings.format(p.keyCombos))
                    .put("calibrationImageUri", p.calibrationImageUri ?: "")
            )
        }
        return prefs.edit().putString(KEY_PROFILES, array.toString()).commit()
    }

    private fun normalizeSensitivity(value: Float): Float =
        (value.coerceIn(0.1f, 10.0f) * 10f).roundToInt() / 10f

    private fun defaultProfile() = MappingProfile(id = "default", name = "Padrão")

    private companion object { const val KEY_PROFILES = "profiles_json" }
}
