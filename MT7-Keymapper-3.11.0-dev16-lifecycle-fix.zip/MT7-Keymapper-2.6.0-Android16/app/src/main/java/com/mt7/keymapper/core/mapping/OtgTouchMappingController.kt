package com.mt7.keymapper.core.mapping

import com.mt7.keymapper.core.input.OtgEventMapper
import kotlin.math.roundToInt

/** Minimal output contract implemented by the persistent privileged uinput session. */
interface MultiTouchOutput {
    fun pointerDown(pointerId: Int, x: Int, y: Int): Boolean
    fun pointerMove(pointerId: Int, x: Int, y: Int): Boolean
    fun pointerUp(pointerId: Int): Boolean
    fun cancelAll(): Boolean
}

/** A physical-key chord that emits one existing mapped action while all keys are held. */
data class KeyComboBinding(val keys: Set<String>, val targetKey: String) {
    init {
        require(keys.size in 2..4)
        require(keys.none { it.isBlank() })
        require(targetKey in OtgEventMapper.KNOWN_LABELS)
        require(keys.all { it in OtgEventMapper.KNOWN_LABELS })
        require(targetKey !in keys)
    }
    val signature: String = keys.sorted().joinToString("+")
}

data class TouchLayout(
    val width: Int,
    val height: Int,
    val joystickX: Float = 0.18f,
    val joystickY: Float = 0.78f,
    val joystickRadius: Float = 0.105f,
    val fireX: Float = 0.86f,
    val fireY: Float = 0.72f,
    val lookX: Float = 0.69f,
    val lookY: Float = 0.43f,
    val jumpX: Float = 0.72f,
    val jumpY: Float = 0.78f,
    val reloadX: Float = 0.88f,
    val reloadY: Float = 0.54f,
    val interactX: Float = 0.63f,
    val interactY: Float = 0.72f,
    val lookSensitivityX: Float = 1.6f,
    val lookSensitivityY: Float = 1.6f,
    val mouseDpi: Int = 1200,
    val acceleration: Float = 0.0f,
    val smoothing: Float = 0.0f,
    val optimizationFilter: Float = 0.0f,
    val optimizationThreshold: Float = 0.0f,
    val optimizationBurst: Float = 0.0f,
    val optimizationBrake: Float = 0.0f,
    val firePullMultiplier: Float = 1.0f,
    /** Minimum interval between successive action-key taps; zero disables the limiter. */
    val keyRepeatDelayMs: Int = 0,
    val pollingRateHz: Int = VisionSettings.DEFAULT_POLLING_RATE_HZ,
    val viewToggleBinding: String = "Mouse do meio",
    val mouseRightMappedKey: String = "Nenhuma",
    val scrollUpMappedKey: String = "Nenhuma",
    val scrollDownMappedKey: String = "Nenhuma",
    val suspendPointerWhileAiming: Boolean = true,
    val keyTaps: List<KeyTapBinding> = emptyList(),
    val keyCombos: List<KeyComboBinding> = emptyList()
) {
    init {
        require(width > 0 && height > 0)
        listOf(joystickX, joystickY, fireX, fireY, lookX, lookY, jumpX, jumpY,
            reloadX, reloadY, interactX, interactY).forEach { require(it.isFinite() && it in 0f..1f) }
        require(joystickRadius.isFinite() && joystickRadius in 0.01f..0.3f)
        require(lookSensitivityX.isFinite() && lookSensitivityX in 0.1f..10f && kotlin.math.abs(lookSensitivityX * 10f - (lookSensitivityX * 10f).roundToInt()) < 0.001f)
        require(lookSensitivityY.isFinite() && lookSensitivityY in 0.1f..10f && kotlin.math.abs(lookSensitivityY * 10f - (lookSensitivityY * 10f).roundToInt()) < 0.001f)
        require(mouseDpi in 100..16000)
        require(acceleration.isFinite() && acceleration in 0f..3f)
        require(smoothing.isFinite() && smoothing in 0f..0.95f)
        require(optimizationFilter.isFinite() && optimizationFilter in 0f..0.8f)
        require(optimizationThreshold.isFinite() && optimizationThreshold in 0f..4f)
        require(optimizationBurst.isFinite() && optimizationBurst in 0f..0.5f)
        require(optimizationBrake.isFinite() && optimizationBrake in 0f..0.8f)
        require(firePullMultiplier.isFinite() && firePullMultiplier in 0.5f..3.0f)
        require(keyRepeatDelayMs in 0..50)
        require(pollingRateHz in VisionSettings.SUPPORTED_POLLING_RATES)
        require(viewToggleBinding.isNotBlank() && viewToggleBinding.length <= 32 && viewToggleBinding !in setOf("Mouse esquerdo", "Mouse direito"))
        require(mouseRightMappedKey.isNotBlank() && mouseRightMappedKey.length <= 16)
        require(scrollUpMappedKey.isNotBlank() && scrollUpMappedKey.length <= 16)
        require(scrollDownMappedKey.isNotBlank() && scrollDownMappedKey.length <= 16)
        require(keyTaps.size <= KeyTapBindings.MAX_BINDINGS && keyTaps.map { it.key }.toSet().size == keyTaps.size)
        require(keyCombos.size <= 16 && keyCombos.map { it.signature }.toSet().size == keyCombos.size && keyCombos.map { it.targetKey }.toSet().size == keyCombos.size)
        require(keyCombos.all { it.targetKey in setOf("ESPAÇO", "R", "F") || it.targetKey in keyTaps.map(KeyTapBinding::key) })
    }

    companion object {
        /** Builds the live OTG HUD layout from the selected saved game profile. */
        fun fromProfile(width: Int, height: Int, profile: MappingProfile): TouchLayout =
            TouchLayout(
                width = width,
                height = height,
                joystickX = profile.joystickPositionX,
                joystickY = profile.joystickPositionY,
                fireX = profile.firePositionX,
                fireY = profile.firePositionY,
                jumpX = profile.jumpPositionX,
                jumpY = profile.jumpPositionY,
                reloadX = profile.reloadPositionX,
                reloadY = profile.reloadPositionY,
                interactX = profile.interactPositionX,
                interactY = profile.interactPositionY,
                lookX = profile.viewPositionX,
                lookY = profile.viewPositionY,
                lookSensitivityX = profile.sensitivityX,
                lookSensitivityY = profile.sensitivityY,
                mouseDpi = profile.mouseDpi,
                acceleration = profile.acceleration,
                smoothing = profile.smoothing,
                optimizationFilter = profile.optimizationFilter,
                optimizationThreshold = profile.optimizationThreshold,
                optimizationBurst = profile.optimizationBurst,
                optimizationBrake = profile.optimizationBrake,
                firePullMultiplier = profile.firePullMultiplier,
                keyRepeatDelayMs = profile.keyRepeatDelayMs.coerceIn(0, 50),
                pollingRateHz = profile.pollingRateHz,
                viewToggleBinding = profile.viewToggleBinding,
                mouseRightMappedKey = profile.mouseRightMappedKey,
                scrollUpMappedKey = profile.scrollUpMappedKey,
                scrollDownMappedKey = profile.scrollDownMappedKey,
                suspendPointerWhileAiming = profile.suspendPointerWhileAiming,
                keyTaps = profile.keyTaps,
                keyCombos = profile.keyCombos
            )
    }
}

/**
 * Converts the current MT7 semantic OTG actions into multitouch contacts.
 * Defaults are a starting layout, not a calibrated Free Fire profile.
 */
class OtgTouchMappingController(
    private val output: MultiTouchOutput,
    private val layout: TouchLayout,
    private val onPointerSuspensionChanged: (Boolean) -> Boolean = { true },
    private val onSoftwareCursorVisibilityChanged: (Boolean) -> Unit = {},
    private val onSoftwareCursorMoved: (Int, Int) -> Unit = { _, _ -> },
    /** Returns true when a captured mouse click is routed to an MT7 overlay control. */
    private val onSoftwareCursorClick: (String, Boolean) -> Boolean = { _, _ -> false }
) {
    private val heldKeys = mutableSetOf<String>()
    private val physicalKeys = mutableSetOf<String>()
    private val activeComboTargets = mutableMapOf<String, String>()
    private val comboKeys = layout.keyCombos.flatMap { it.keys }.toSet()
    private val heldActionKeys = mutableSetOf<String>()
    private var fireHeld = false
    private var viewModeActive = false
    private var suspendPointerWhileAiming = layout.suspendPointerWhileAiming
    // Actual kernel capture state is distinct from the saved user preference.
    // Defaults to active for standalone controller use; session startup immediately
    // synchronizes it with the real native EVIOCGRAB result.
    private var pointerCaptureActive = true
    private var pointerCaptureStateKnown = false
    private var viewToggleHeld = false
    private var lookContactActive = false
    private var lookX = px(layout.lookX)
    private var lookY = pxY(layout.lookY)
    private var lookRemainderX = 0f
    private var lookRemainderY = 0f
    private var filteredDx = 0f
    private var filteredDy = 0f
    private var lastMotionNanos = 0L
    private var joystickActive = false
    private val lastActionAtNanos = mutableMapOf<String, Long>()
    /** Free keys (SS KeyMouse style): label -> pointer id and screen point. Free keys win over the built-in Space/R/F. */
    private val freeTaps: Map<String, Pair<Int, Pair<Int, Int>>> =
        layout.keyTaps.withIndex().associate { (i, b) -> b.key to (FREE_BASE_ID + i to (px(b.x) to pxY(b.y))) }

    /** Enables/disables MT7's independent cursor and exclusive mouse capture for the mapper. */
    @Synchronized
    fun setPointerSuspensionEnabled(enabled: Boolean): Boolean {
        val previousPreference = suspendPointerWhileAiming
        suspendPointerWhileAiming = enabled
        if (!enabled && viewModeActive) {
            // Lift the camera finger before releasing EVIOCGRAB. Otherwise the
            // game may keep a stuck look contact after the pointer is restored.
            if (lookContactActive && !output.pointerUp(LOOK_ID)) {
                suspendPointerWhileAiming = previousPreference
                return false
            }
            lookContactActive = false
            viewModeActive = false
            viewToggleHeld = false
            lookRemainderX = 0f; lookRemainderY = 0f
            filteredDx = 0f; filteredDy = 0f; lastMotionNanos = 0L
        }
        // Capture is a mapper-wide mode, not something that starts only while aiming.
        // This suppresses Android's hardware cursor and lets MT7 draw its own cursor.
        val applied = onPointerSuspensionChanged(enabled)
        if (!applied) {
            suspendPointerWhileAiming = previousPreference
            // Before the first successful grab, a failed request means there is
            // no exclusive capture; do not leave the software cursor pretending
            // that the kernel has hidden Android's pointer.
            if (!pointerCaptureStateKnown) pointerCaptureActive = false
            pointerCaptureStateKnown = true
            onSoftwareCursorVisibilityChanged(pointerCaptureActive)
            return false
        }
        pointerCaptureActive = enabled
        pointerCaptureStateKnown = true
        onSoftwareCursorVisibilityChanged(pointerCaptureActive)
        return true
    }

    /** Re-acquire the mouse after the floating mapper has been resumed from pause. */
    @Synchronized
    fun resumePointerCapture(): Boolean {
        if (!suspendPointerWhileAiming) {
            pointerCaptureActive = false
            pointerCaptureStateKnown = true
            onSoftwareCursorVisibilityChanged(false)
            return true
        }
        val applied = onPointerSuspensionChanged(true)
        if (applied) {
            pointerCaptureActive = true
            pointerCaptureStateKnown = true
            onSoftwareCursorVisibilityChanged(true)
        } else {
            pointerCaptureActive = false
            pointerCaptureStateKnown = true
            onSoftwareCursorVisibilityChanged(false)
        }
        return applied
    }

    @Synchronized
    fun accept(action: OtgEventMapper.Action): Boolean {
        // Linux autorepeat (value=2) is not a new press. Ignore it so a held
        // action cannot be retriggered by keyboard repeat or create extra taps.
        if (action.repeat) return true
        return when (action.kind) {
        OtgEventMapper.Kind.KEY -> {
            if (action.label == layout.viewToggleBinding) handleViewToggle(action.pressed == true)
            else handleKey(action.label, action.pressed == true)
        }
        OtgEventMapper.Kind.MOUSE_BUTTON -> handleMouse(action.label, action.pressed == true)
        OtgEventMapper.Kind.POINTER_MOVE -> handleMove(action.deltaX, action.deltaY)
        OtgEventMapper.Kind.SCROLL -> handleScroll(action.deltaY)
        }
    }

    private fun handleKey(key: String, pressed: Boolean): Boolean {
        if (pressed) physicalKeys.add(key) else physicalKeys.remove(key)
        if (key in comboKeys) {
            val matching = layout.keyCombos.filter { physicalKeys.containsAll(it.keys) }.maxByOrNull { it.keys.size }?.let { listOf(it) }.orEmpty()
            val matchingSignatures = matching.map { it.signature }.toSet()
            // Release chords that ceased to match before activating newly completed chords.
            val toRelease = activeComboTargets.filterKeys { it !in matchingSignatures }
            for ((signature, target) in toRelease) {
                if (!handleSingleKey(target, false)) return false
                activeComboTargets.remove(signature)
            }
            for (combo in matching) {
                if (combo.signature !in activeComboTargets) {
                    if (!handleSingleKey(combo.targetKey, true)) return false
                    activeComboTargets[combo.signature] = combo.targetKey
                }
            }
            return true
        }
        return handleSingleKey(key, pressed)
    }

    private fun handleSingleKey(key: String, pressed: Boolean): Boolean {
        if (key in MOVE_KEYS) {
            if (pressed) heldKeys.add(key) else heldKeys.remove(key)
            return updateJoystick()
        }
        val target = freeTaps[key] ?: when (key) {
            "ESPAÇO" -> JUMP_ID to (px(layout.jumpX) to pxY(layout.jumpY))
            "R" -> RELOAD_ID to (px(layout.reloadX) to pxY(layout.reloadY))
            "F" -> INTERACT_ID to (px(layout.interactX) to pxY(layout.interactY))
            else -> return true
        }
        if (pressed) {
            if (!heldActionKeys.add(key)) return true
            val now = System.nanoTime()
            val previous = lastActionAtNanos[key] ?: 0L
            if (layout.keyRepeatDelayMs > 0 && previous != 0L &&
                now - previous < layout.keyRepeatDelayMs * 1_000_000L) {
                heldActionKeys.remove(key)
                return true
            }
            lastActionAtNanos[key] = now
            val ok = output.pointerDown(target.first, target.second.first, target.second.second)
            if (!ok) heldActionKeys.remove(key)
            return ok
        }
        if (!heldActionKeys.remove(key)) return true
        return output.pointerUp(target.first)
    }

    private fun handleMouse(button: String, pressed: Boolean): Boolean {
        // Give the floating MT7 controls first refusal. When the cursor is over
        // an MT7 overlay, the click must operate that UI instead of firing in-game.
        if (onSoftwareCursorClick(button, pressed)) return true
        if (button == "Mouse esquerdo") {
            // Left mouse is reserved exclusively for the in-game fire contact.
            return if (pressed == fireHeld) true else if (pressed) {
                val ok = output.pointerDown(FIRE_ID, px(layout.fireX), pxY(layout.fireY))
                if (ok) fireHeld = true
                ok
            } else {
                val ok = output.pointerUp(FIRE_ID)
                fireHeld = false
                ok
            }
        }
        if (button == layout.viewToggleBinding) return handleViewToggle(pressed)
        // A free key placed directly on a mouse button wins; otherwise right mouse uses its mapped action.
        if (button in freeTaps) return handleKey(button, pressed)
        if (button == "Mouse direito") {
            return handleKey(layout.mouseRightMappedKey, pressed)
        }
        return true
    }

    private fun handleScroll(deltaY: Int): Boolean {
        if (deltaY == 0) return true
        // Linux REL_WHEEL: positive is wheel-up; negative is wheel-down.
        val key = if (deltaY > 0) layout.scrollUpMappedKey else layout.scrollDownMappedKey
        if (key == "Nenhuma") return true
        // Wheel events are impulses, so emit a short down/up contact pair.
        if (!handleKey(key, true)) return false
        return handleKey(key, false)
    }

    private fun handleViewToggle(pressed: Boolean): Boolean {
        if (pressed == viewToggleHeld) return true
        viewToggleHeld = pressed
        if (!pressed) return true
        if (!pointerCaptureActive) return false
        return toggleViewMode()
    }

    private fun toggleViewMode(): Boolean {
        if (!viewModeActive) {
            // The mouse is already captured for the mapper lifetime. Vista only
            // changes how relative movement is translated into the camera touch.
            viewModeActive = true
            lookX = px(layout.lookX).coerceIn(lookMinX(), lookMaxX())
            lookY = pxY(layout.lookY).coerceIn(lookMinY(), lookMaxY())
            lookRemainderX = 0f
            lookRemainderY = 0f
            filteredDx = 0f; filteredDy = 0f; lastMotionNanos = 0L
            return true
        }
        val released = if (lookContactActive) output.pointerUp(LOOK_ID) else true
        lookContactActive = false
        viewModeActive = false
        // Do not release EVIOCGRAB here: the independent MT7 cursor remains
        // active outside Vista and until the whole mapper is paused or stopped.
        lookRemainderX = 0f
        lookRemainderY = 0f
        filteredDx = 0f; filteredDy = 0f; lastMotionNanos = 0L
        return released
    }

    /** Called on the native reader thread after an asynchronous grab failure/device loss. */
    @Synchronized
    fun abortViewMode() {
        // Do not request another EVIOCGRAB transition here: this callback can run
        // on the thread that must read the native helper's acknowledgement. Clear
        // every logical contact and mark capture lost instead of waiting on itself.
        heldKeys.clear()
        physicalKeys.clear()
        activeComboTargets.clear()
        heldActionKeys.clear()
        lastActionAtNanos.clear()
        fireHeld = false
        viewModeActive = false
        viewToggleHeld = false
        lookContactActive = false
        joystickActive = false
        pointerCaptureActive = false
        pointerCaptureStateKnown = true
        lookRemainderX = 0f; lookRemainderY = 0f
        filteredDx = 0f; filteredDy = 0f; lastMotionNanos = 0L
        onSoftwareCursorVisibilityChanged(false)
        output.cancelAll()
    }

    private fun handleMove(dx: Int, dy: Int): Boolean {
        if (dx == 0 && dy == 0) return true
        // The custom MT7 pointer follows the mouse whenever mapping capture is on,
        // even outside Vista. Vista additionally converts the same delta to touch.
        if (pointerCaptureActive) onSoftwareCursorMoved(dx, dy)
        if (!viewModeActive || !pointerCaptureActive) return true
        // Keep the virtual finger inside the right-side look zone. When it reaches
        // an edge, lift and re-anchor near the configured center instead of leaving
        // the contact pinned to a screen edge (which would stop further camera motion).
        val minX = lookMinX(); val maxX = lookMaxX()
        val minY = lookMinY(); val maxY = lookMaxY()
        // Normalize declared DPI against the 1200-DPI reference profile. This is
        // a software scale only; it never changes the mouse firmware setting.
        val dpiScale = (1200f / layout.mouseDpi).coerceIn(0.25f, 4f)
        val now = System.nanoTime()
        val dtSeconds = if (lastMotionNanos == 0L) 1f / 250f
            else ((now - lastMotionNanos) / 1_000_000_000f).coerceIn(0.001f, 0.050f)
        lastMotionNanos = now

        // Experimental camera tuning: threshold removes only tiny raw deltas;
        // filter smooths the camera contact; burst adds bounded gain to fast swipes;
        // brake reduces very small corrections. All defaults are neutral (zero).
        val threshold = layout.optimizationThreshold
        val thresholdedX = if (kotlin.math.abs(dx.toFloat()) < threshold) 0f else dx.toFloat()
        val thresholdedY = if (kotlin.math.abs(dy.toFloat()) < threshold) 0f else dy.toFloat()
        val rawMagnitude = kotlin.math.sqrt((thresholdedX * thresholdedX + thresholdedY * thresholdedY))
        val speed = rawMagnitude / dtSeconds
        // Bounded speed curve: zero means strictly linear; higher values add
        // controlled gain only for fast swipes, avoiding unbounded acceleration.
        val speedFactor = (speed / 2400f).coerceIn(0f, 1f)
        // Headshot pull curve: only a fast upward swipe while the fire contact is
        // held receives extra gain. Slow corrections and ordinary camera movement
        // remain at the selected single sensitivity.
        val upwardFireGain = if (fireHeld && dy < 0)
            1f + layout.acceleration * speedFactor
        else 1f
        val combinedFilter = (layout.smoothing + layout.optimizationFilter).coerceIn(0f, 0.9f)
        val alpha = if (combinedFilter <= 0f) 1f else (1f - combinedFilter).coerceIn(0.05f, 1f)
        filteredDx += (thresholdedX - filteredDx) * alpha
        filteredDy += (thresholdedY - filteredDy) * alpha
        val slowBrake = if (rawMagnitude in 0.001f..3f) 1f - layout.optimizationBrake else 1f
        val burstGain = if (rawMagnitude >= 12f) 1f + layout.optimizationBurst else 1f
        val optimizationGain = slowBrake * burstGain

        // The transformed deltas move the virtual look contact, which is how this
        // pipeline rotates the in-game camera; they are not cursor-only settings.
        val scaledX = filteredDx * layout.lookSensitivityX * dpiScale * optimizationGain + lookRemainderX
        val firePullGain = if (fireHeld && dy < 0) layout.firePullMultiplier else 1f
        val scaledY = filteredDy * layout.lookSensitivityY * dpiScale * upwardFireGain * firePullGain * optimizationGain + lookRemainderY
        val stepX = scaledX.roundToInt()
        val stepY = scaledY.roundToInt()
        lookRemainderX = scaledX - stepX
        lookRemainderY = scaledY - stepY
        if (stepX == 0 && stepY == 0) return true
        val rawX = lookX + stepX
        val rawY = lookY + stepY
        val crossedEdge = rawX !in minX..maxX || rawY !in minY..maxY
        if (crossedEdge && lookContactActive) {
            // Re-anchor the virtual finger while preserving every pixel of an oversized
            // relative delta. A modulo wrap prevents fast swipes from being clamped at
            // the edge (which previously discarded the excess and could stall 360 turns).
            fun wrapCoordinate(value: Int, minimum: Int, maximum: Int): Int {
                val span = (maximum - minimum + 1).coerceAtLeast(1)
                return minimum + Math.floorMod(value - minimum, span)
            }
            val rebasedX = wrapCoordinate(rawX, minX, maxX)
            val rebasedY = wrapCoordinate(rawY, minY, maxY)
            if (!output.pointerUp(LOOK_ID)) { lookContactActive = false; return false }
            lookContactActive = false
            lookX = rebasedX
            lookY = rebasedY
            val rebased = output.pointerDown(LOOK_ID, lookX, lookY)
            lookContactActive = rebased
            return rebased
        }
        lookX = rawX.coerceIn(minX, maxX)
        lookY = rawY.coerceIn(minY, maxY)
        val ok = if (lookContactActive) output.pointerMove(LOOK_ID, lookX, lookY)
        else output.pointerDown(LOOK_ID, lookX, lookY)
        if (ok) lookContactActive = true
        return ok
    }

    private fun updateJoystick(): Boolean {
        val horizontal = (if ("D" in heldKeys) 1 else 0) - (if ("A" in heldKeys) 1 else 0)
        val vertical = (if ("S" in heldKeys) 1 else 0) - (if ("W" in heldKeys) 1 else 0)
        if (horizontal == 0 && vertical == 0) {
            if (!joystickActive) return true
            joystickActive = false
            return output.pointerUp(JOYSTICK_ID)
        }
        val radius = (minOf(layout.width, layout.height) * layout.joystickRadius).roundToInt()
        val centerX = px(layout.joystickX)
        val centerY = pxY(layout.joystickY)
        val norm = if (horizontal != 0 && vertical != 0) 0.70710678f else 1f
        val x = (centerX + horizontal * radius * norm).roundToInt().coerceIn(0, layout.width)
        val y = (centerY + vertical * radius * norm).roundToInt().coerceIn(0, layout.height)
        if (!joystickActive) {
            // Emulator-like virtual stick: establish the finger at the configured
            // neutral point first, then deflect it. This avoids spawning the touch
            // at the rim, which some games interpret as a dropped/invalid stick.
            if (!output.pointerDown(JOYSTICK_ID, centerX, centerY)) return false
            joystickActive = true
            if (x == centerX && y == centerY) return true
        }
        return output.pointerMove(JOYSTICK_ID, x, y)
    }

    /** Release every logical contact on pause, stop, device loss, or backend loss. */
    @Synchronized
    fun releaseAll(): Boolean {
        heldKeys.clear(); heldActionKeys.clear(); lastActionAtNanos.clear(); physicalKeys.clear(); activeComboTargets.clear(); fireHeld = false
        viewModeActive = false; viewToggleHeld = false; lookContactActive = false; joystickActive = false
        lookRemainderX = 0f; lookRemainderY = 0f
        filteredDx = 0f; filteredDy = 0f; lastMotionNanos = 0L
        val pointerReleased = !pointerCaptureActive || onPointerSuspensionChanged(false)
        if (pointerReleased) {
            pointerCaptureActive = false
            pointerCaptureStateKnown = true
            onSoftwareCursorVisibilityChanged(false)
        }
        return output.cancelAll() && pointerReleased
    }

    private fun lookMinX() = (layout.width * 0.52f).roundToInt()
    private fun lookMaxX() = (layout.width * 0.97f).roundToInt()
    private fun lookMinY() = (layout.height * 0.08f).roundToInt()
    private fun lookMaxY() = (layout.height * 0.92f).roundToInt()
    private fun px(fraction: Float) = (fraction * layout.width).roundToInt().coerceIn(0, layout.width)
    private fun pxY(fraction: Float) = (fraction * layout.height).roundToInt().coerceIn(0, layout.height)

    companion object {
        private val MOVE_KEYS = setOf("W", "A", "S", "D")
        private const val JOYSTICK_ID = 0
        private const val LOOK_ID = 1
        private const val FIRE_ID = 2
        private const val JUMP_ID = 3
        private const val RELOAD_ID = 4
        private const val INTERACT_ID = 5
        private const val FREE_BASE_ID = 6
    }
}
