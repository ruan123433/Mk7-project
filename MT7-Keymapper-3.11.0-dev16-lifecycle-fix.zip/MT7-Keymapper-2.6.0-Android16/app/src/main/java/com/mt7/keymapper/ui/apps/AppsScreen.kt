package com.mt7.keymapper.ui.apps

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.mt7.keymapper.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class LaunchableApp(val packageName: String, val label: String, val icon: ImageBitmap?)

object MappedApps {
    private const val PREFS = "mt7_apps"
    private const val KEY = "mapped"
    fun get(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(KEY, emptySet())?.toSet() ?: emptySet()
    fun set(context: Context, value: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY, value).apply()
    }
}

private fun loadApps(context: Context): List<LaunchableApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0)
        .asSequence()
        .filter { it.activityInfo.packageName != context.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { info ->
            val icon = runCatching { info.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
            LaunchableApp(info.activityInfo.packageName, info.loadLabel(pm).toString(), icon)
        }
        .sortedBy { it.label.lowercase() }
        .toList()
}

@Composable
fun AppsScreen(onMappedChanged: (Int) -> Unit, onLaunch: (String) -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var onlyMapped by remember { mutableStateOf(false) }
    var mapped by remember { mutableStateOf(MappedApps.get(context)) }
    val apps by produceState<List<LaunchableApp>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { runCatching { loadApps(context) }.getOrDefault(emptyList()) }
    }

    Column(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(6.dp))
        Text("Apps e jogos", color = Neon.Cyan, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
        Text("Marque os jogos em que o MT7 deve ativar o mapeamento.", color = Neon.Muted)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Buscar app…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Neon.Cyan,
                unfocusedBorderColor = Neon.Panel2,
                cursorColor = Neon.Cyan
            )
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(
                checked = onlyMapped,
                onCheckedChange = { onlyMapped = it },
                colors = SwitchDefaults.colors(checkedTrackColor = Neon.Magenta)
            )
            Spacer(Modifier.width(8.dp))
            Text("Mostrar só os mapeados (${mapped.size})", color = Neon.Muted)
        }

        val list = apps
        if (list == null) {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Neon.Cyan)
            }
        } else {
            val filtered = list.filter {
                (!onlyMapped || it.packageName in mapped) &&
                    (query.isBlank() || it.label.contains(query, ignoreCase = true))
            }
            if (filtered.isEmpty()) {
                Text("Nenhum app encontrado.", color = Neon.Muted, modifier = Modifier.padding(16.dp))
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
                items(filtered, key = { it.packageName }) { app ->
                    val isMapped = app.packageName in mapped
                    NeonCard(accent = if (isMapped) Neon.Magenta else Neon.Panel2) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Neon.Navy), contentAlignment = Alignment.Center) {
                                if (app.icon != null) Image(app.icon, contentDescription = app.label, modifier = Modifier.size(40.dp))
                                else Text(app.label.take(1).uppercase(), fontWeight = FontWeight.Black)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(app.label, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(app.packageName, color = Neon.Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Switch(
                                checked = isMapped,
                                onCheckedChange = { on ->
                                    mapped = if (on) mapped + app.packageName else mapped - app.packageName
                                    MappedApps.set(context, mapped)
                                    onMappedChanged(mapped.size)
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = Neon.Magenta, checkedThumbColor = androidx.compose.ui.graphics.Color.White)
                            )
                        }
                        if (isMapped) {
                            NeonOutlineButton("▶  Abrir jogo") {
                                onLaunch(app.packageName)
                                context.packageManager.getLaunchIntentForPackage(app.packageName)?.let {
                                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    runCatching { context.startActivity(it) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
