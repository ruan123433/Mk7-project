package com.mt7.keymapper.core.activation

import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit
import java.io.ByteArrayOutputStream
import kotlin.concurrent.thread

/** Runs a fixed, internally generated command through an explicitly authorized backend. */
internal object PrivilegedCommandRunner {
    data class Result(val exitCode: Int, val output: String) {
        val success: Boolean get() = exitCode == 0
    }

    fun root(command: String, timeoutMs: Long = 2_000): Result = run(
        start = { ProcessBuilder("su", "-c", command).redirectErrorStream(true).start() },
        timeoutMs = timeoutMs
    )

    @Suppress("DEPRECATION")
    fun shizuku(command: String, timeoutMs: Long = 2_000): Result = run(
        start = {
            check(Shizuku.pingBinder()) { "Shizuku desconectado" }
            check(Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                "Permissão Shizuku não concedida"
            }
            com.mt7.keymapper.core.activation.ShizukuProcess.start(command)
        },
        timeoutMs = timeoutMs
    )

    private const val MAX_OUTPUT_BYTES = 64 * 1024

    private fun run(start: () -> Process, timeoutMs: Long): Result {
        val process = runCatching(start).getOrElse {
            return Result(127, it.message ?: "Não foi possível iniciar o processo")
        }
        return try {
            // Drain stdout/stderr while the process is alive. Waiting first can
            // deadlock when commands such as `getevent -pl` fill the pipe buffer.
            val captured = ByteArrayOutputStream()
            val drain = thread(name = "MT7-privileged-output", isDaemon = true) {
                process.inputStream.use { input ->
                    val buffer = ByteArray(4_096)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        val remaining = (MAX_OUTPUT_BYTES - total).coerceAtLeast(0)
                        if (remaining > 0) {
                            val accepted = minOf(count, remaining)
                            captured.write(buffer, 0, accepted)
                            total += accepted
                        }
                    }
                }
            }
            if (!process.waitFor(timeoutMs, TimeUnit.MILLISECONDS)) {
                process.destroyForcibly()
                drain.join(500)
                Result(124, "Tempo limite excedido")
            } else {
                drain.join(500)
                Result(process.exitValue(), captured.toString(Charsets.UTF_8.name()).trim())
            }
        } catch (error: Exception) {
            process.destroyForcibly()
            Result(126, error.message ?: "Falha ao executar comando")
        }
    }
}
