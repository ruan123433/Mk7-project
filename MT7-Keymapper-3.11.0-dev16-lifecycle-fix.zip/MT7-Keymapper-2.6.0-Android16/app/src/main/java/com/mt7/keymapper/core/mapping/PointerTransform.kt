package com.mt7.keymapper.core.mapping

import kotlin.math.abs
import kotlin.math.sign

data class PointerDelta(val x: Float, val y: Float)

/**
 * Deterministic relative-motion transform.
 *
 * When accelerationProtection is enabled, each axis is a linear multiplier:
 * output = input * sensitivity. No speed-dependent gain is applied.
 *
 * This is a local transformation only. It does not capture or inject input
 * into Free Fire or any other application.
 */
class PointerTransform {
    fun apply(delta: PointerDelta, settings: VisionSettings): PointerDelta {
        require(delta.x.isFinite() && delta.y.isFinite()) {
            "Pointer deltas must be finite"
        }

        // Acceleration protection means strictly linear gain. When disabled,
        // retain the same neutral linear behavior until a separately specified
        // curve is implemented; never silently invent an acceleration curve.
        return PointerDelta(
            x = delta.x * settings.sensitivityX,
            y = delta.y * settings.sensitivityY
        )
    }

    /** Backward-compatible profile path, also made linear and deterministic. */
    fun apply(delta: PointerDelta, profile: MappingProfile): PointerDelta {
        require(delta.x.isFinite() && delta.y.isFinite()) {
            "Pointer deltas must be finite"
        }
        return PointerDelta(
            x = delta.x * profile.sensitivityX,
            y = delta.y * profile.sensitivityY
        )
    }
}
