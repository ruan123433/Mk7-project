package com.mt7.keymapper.core.activation

import rikka.shizuku.Shizuku

/** Shizuku 13.x made newProcess private; call it through reflection (same behavior as before). */
internal object ShizukuProcess {
    private val method by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun start(command: String): Process =
        method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
}
