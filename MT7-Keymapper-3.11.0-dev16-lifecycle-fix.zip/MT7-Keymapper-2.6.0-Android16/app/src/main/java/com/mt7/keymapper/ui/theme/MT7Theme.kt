package com.mt7.keymapper.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MT7Colors = darkColorScheme(
    primary = Neon.Cyan,
    secondary = Neon.Magenta,
    background = Neon.Navy,
    surface = Neon.Panel,
    surfaceVariant = Neon.Panel2,
    onPrimary = Color(0xFF001018),
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White,
    onSurfaceVariant = Neon.Muted
)

@Composable
fun MT7Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = MT7Colors, content = content)
}
