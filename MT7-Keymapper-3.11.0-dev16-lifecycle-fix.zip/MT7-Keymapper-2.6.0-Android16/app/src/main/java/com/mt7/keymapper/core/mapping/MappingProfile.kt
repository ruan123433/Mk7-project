package com.mt7.keymapper.core.mapping

import kotlin.math.roundToInt

data class MappingProfile(
    val id: String,
    val name: String,
    val sensitivityX: Float = 1.2f,
    val sensitivityY: Float = 0.8f,
    /** Selected Vista response preset for this profile. */
    val viewMode: String = "NORMAL",
    val normalSensitivityX: Float = 1.2f,
    val normalSensitivityY: Float = 0.8f,
    val combatSensitivityX: Float = 2.0f,
    val combatSensitivityY: Float = 1.2f,
    val precisionSensitivityX: Float = 1.0f,
    val precisionSensitivityY: Float = 0.5f,
    val acceleration: Float = 0.0f,
    val smoothing: Float = 0.0f,
    /** Experimental camera-motion controls; applied only while relative-look is active. */
    val optimizationFilter: Float = 0.0f,
    val optimizationThreshold: Float = 0.0f,
    val optimizationBurst: Float = 0.0f,
    val optimizationBrake: Float = 0.0f,
    /** User-declared mouse DPI used only for normalization; does not change hardware DPI. */
    val mouseDpi: Int = 1200,
    val joystickSensitivityX: Float = 1.0f,
    val joystickSensitivityY: Float = 1.0f,
    val joystickDeadzone: Float = 0.08f,
    val fireMode: FireMode = FireMode.TAP,
    /** Vertical camera gain applied only to user-driven upward mouse movement while firing. */
    val firePullMultiplier: Float = 1.0f,
    /** Minimum interval between repeated mapped action-key activations (0 = no added delay). */
    val keyRepeatDelayMs: Int = 0,
    val joystickPositionX: Float = 0.18f,
    val joystickPositionY: Float = 0.78f,
    val viewPositionX: Float = 0.72f,
    val viewPositionY: Float = 0.48f,
    val firePositionX: Float = 0.86f,
    val firePositionY: Float = 0.72f,
    /** Editable positions for the built-in jump, reload and interact touch actions. */
    val jumpPositionX: Float = 0.72f,
    val jumpPositionY: Float = 0.78f,
    val reloadPositionX: Float = 0.88f,
    val reloadPositionY: Float = 0.54f,
    val interactPositionX: Float = 0.63f,
    val interactPositionY: Float = 0.72f,
    /** Requested event processing/polling preference; cannot change the USB mouse firmware rate. */
    val pollingRateHz: Int = VisionSettings.DEFAULT_POLLING_RATE_HZ,
    /** Binding that toggles relative-look mode; independent from the right mouse button. */
    val viewToggleBinding: String = "Mouse do meio",
    /** Optional normal mapped action for right mouse; accepted values: Nenhuma, ESPAÇO, R, F. */
    val mouseRightMappedKey: String = "Nenhuma",
    /** Optional tap action for vertical wheel up; accepted values: Nenhuma, ESPAÇO, R, F. */
    val scrollUpMappedKey: String = "Nenhuma",
    /** Optional tap action for vertical wheel down; accepted values: Nenhuma, ESPAÇO, R, F. */
    val scrollDownMappedKey: String = "Nenhuma",
    /** Ask the platform adapter to suppress pointer while relative-look mode is active. */
    val suspendPointerWhileAiming: Boolean = true,
    /** SS KeyMouse-style free keys: any key or extra mouse button held = finger held at a screen point. */
    val keyTaps: List<KeyTapBinding> = emptyList(),
    /** Physical key combinations that hold a mapped action while all chord keys are down. */
    val keyCombos: List<KeyComboBinding> = emptyList(),
    /** Persisted user-selected screenshot URI used as the visual calibration canvas. */
    val calibrationImageUri: String? = null
) {
    init {
        require(sensitivityX in 0.2f..10.0f && kotlin.math.abs(sensitivityX * 10f - (sensitivityX * 10f).roundToInt()) < 0.001f)
        require(sensitivityY.isFinite() && sensitivityY in 0.1f..10.0f && kotlin.math.abs(sensitivityY * 10f - (sensitivityY * 10f).roundToInt()) < 0.001f)
        require(viewMode in setOf("NORMAL", "COMBATE", "PRECISAO"))
        require(listOf(normalSensitivityX, combatSensitivityX, precisionSensitivityX).all {
            it.isFinite() && it in 0.2f..10.0f && kotlin.math.abs(it * 10f - (it * 10f).roundToInt()) < 0.001f
        })
        require(listOf(normalSensitivityY, combatSensitivityY, precisionSensitivityY).all {
            it.isFinite() && it in 0.1f..10.0f && kotlin.math.abs(it * 10f - (it * 10f).roundToInt()) < 0.001f
        })
        require(acceleration in 0.0f..3.0f)
        require(smoothing in 0.0f..0.95f)
        require(optimizationFilter.isFinite() && optimizationFilter in 0f..0.8f)
        require(optimizationThreshold.isFinite() && optimizationThreshold in 0f..4f)
        require(optimizationBurst.isFinite() && optimizationBurst in 0f..0.5f)
        require(optimizationBrake.isFinite() && optimizationBrake in 0f..0.8f)
        require(mouseDpi in 100..16000)
        require(firePullMultiplier.isFinite() && firePullMultiplier in 0.5f..3.0f)
        require(keyRepeatDelayMs in 0..50)
        require(joystickSensitivityX in 0.1f..2.0f)
        require(joystickSensitivityY in 0.1f..2.0f)
        require(joystickDeadzone in 0.0f..0.5f)
        require(joystickPositionX in 0.0f..1.0f && joystickPositionY in 0.0f..1.0f)
        require(viewPositionX in 0.0f..1.0f && viewPositionY in 0.0f..1.0f)
        require(firePositionX in 0.0f..1.0f && firePositionY in 0.0f..1.0f)
        require(jumpPositionX in 0.0f..1.0f && jumpPositionY in 0.0f..1.0f)
        require(reloadPositionX in 0.0f..1.0f && reloadPositionY in 0.0f..1.0f)
        require(interactPositionX in 0.0f..1.0f && interactPositionY in 0.0f..1.0f)
        require(pollingRateHz in VisionSettings.SUPPORTED_POLLING_RATES)
        require(viewToggleBinding.isNotBlank() && viewToggleBinding.length <= 32 && viewToggleBinding !in setOf("Mouse esquerdo", "Mouse direito"))
        require(mouseRightMappedKey.isNotBlank() && mouseRightMappedKey.length <= 16)
        require(scrollUpMappedKey.isNotBlank() && scrollUpMappedKey.length <= 16)
        require(scrollDownMappedKey.isNotBlank() && scrollDownMappedKey.length <= 16)
        require(keyTaps.size <= KeyTapBindings.MAX_BINDINGS && keyTaps.map { it.key }.toSet().size == keyTaps.size)
        require(keyCombos.size <= 16 && keyCombos.map { it.signature }.toSet().size == keyCombos.size && keyCombos.map { it.targetKey }.toSet().size == keyCombos.size)
        require(keyCombos.all { it.targetKey in setOf("ESPAÇO", "R", "F") || it.targetKey in keyTaps.map(KeyTapBinding::key) })
        require(calibrationImageUri == null || calibrationImageUri.length <= 2048)
    }
}
