package com.mt7.keymapper.ui.devices

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import com.mt7.keymapper.core.devices.InputDeviceInspector
import com.mt7.keymapper.core.input.OtgInputEventReader
import com.mt7.keymapper.core.input.OtgEventMapper
import com.mt7.keymapper.core.injection.UinputCapabilityInspector
import com.mt7.keymapper.core.injection.UinputProbeRunner
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import android.content.Intent
import com.mt7.keymapper.service.MT7InputService
import com.mt7.keymapper.core.mapping.ProfileStore

@Composable
fun InputDeviceDiagnosticsPanel(modifier: Modifier = Modifier) {
    var devices by remember { mutableStateOf(InputDeviceInspector.scan()) }
    val reader = remember { OtgInputEventReader() }
    val keyboardReader = remember { OtgInputEventReader() }
    val eventMapper = remember { OtgEventMapper() }
    val uinputInspector = remember { UinputCapabilityInspector() }
    val context = LocalContext.current
    val devicePrefs = remember(context) { context.getSharedPreferences("mt7_otg_devices", android.content.Context.MODE_PRIVATE) }
    val uinputProbeRunner = remember(context) { UinputProbeRunner(context) }
    var uinputProbeResult by remember { mutableStateOf<UinputProbeRunner.Execution?>(null) }
    var uinputProbeRunning by remember { mutableStateOf(false) }
    var uinputReport by remember { mutableStateOf<UinputCapabilityInspector.Report?>(null) }
    var uinputChecking by remember { mutableStateOf(false) }
    var privilegedDevices by remember { mutableStateOf<List<OtgInputEventReader.Device>>(emptyList()) }
    var selectedPath by remember { mutableStateOf(devicePrefs.getString("mouse_path", null)) } // mouse node
    var selectedKeyboardPath by remember { mutableStateOf(devicePrefs.getString("keyboard_path", null)) }
    var exclusiveGrabActive by remember { mutableStateOf(false) }
    var captureStatus by remember { mutableStateOf("Captura OTG não iniciada") }
    var activeBackend by remember { mutableStateOf<String?>(null) }
    val events = remember { mutableStateListOf<OtgInputEventReader.InputEvent>() }
    val mappedEvents = remember { mutableStateListOf<OtgEventMapper.Action>() }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    DisposableEffect(reader, keyboardReader) {
        onDispose { reader.close(); keyboardReader.close() }
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1_000)
            val latest = InputDeviceInspector.scan()
            if (latest != devices) devices = latest
        }
    }

    LaunchedEffect(Unit) {
        privilegedDevices = withContext(Dispatchers.IO) { reader.listDevices() }
        if (selectedPath == null || privilegedDevices.none { it.path == selectedPath }) {
            selectedPath = devicePrefs.getString("mouse_path", null)?.takeIf { path -> privilegedDevices.any { it.path == path } }
                ?: privilegedDevices.firstOrNull { it.hasMouse }?.path
                ?: privilegedDevices.firstOrNull { it.description.contains("mouse", true) }?.path
        }
        if (selectedKeyboardPath == null || privilegedDevices.none { it.path == selectedKeyboardPath }) {
            selectedKeyboardPath = devicePrefs.getString("keyboard_path", null)?.takeIf { path -> privilegedDevices.any { it.path == path } }
                ?: privilegedDevices.firstOrNull { it.hasKeyboard }?.path
                ?: privilegedDevices.firstOrNull { it.hasMouse && it.hasKeyboard }?.path
                ?: privilegedDevices.firstOrNull { it.description.contains("keyboard", true) }?.path
        }
    }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Dispositivos de entrada", style = MaterialTheme.typography.titleLarge, color = Color(0xFF1597FF))
                Text("${devices.size} dispositivo(s) visível(is) para o Android", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = { devices = InputDeviceInspector.scan() }) { Text("Atualizar") }
        }

        Text("Pré-diagnóstico uinput (touchscreen virtual)", color = Color(0xFF1597FF), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = !uinputChecking, onClick = {
                uinputChecking = true
                Thread {
                    val report = uinputInspector.inspect()
                    mainHandler.post {
                        uinputReport = report
                        uinputChecking = false
                    }
                }.start()
            }) { Text(if (uinputChecking) "Verificando..." else "Verificar uinput") }
        }
        uinputReport?.let { report ->
            Text(report.detail, color = if (report.readyForWriteProbe) Color(0xFF42C98A) else Color(0xFFFFC078), style = MaterialTheme.typography.bodySmall)
            Text("Backend: ${report.backend ?: "indisponível"} · nó: ${report.nodePath ?: "não encontrado"} · módulo: ${if (report.moduleLoaded) "carregado" else "não detectado"} · SELinux: ${report.selinuxMode ?: "não informado"}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(enabled = !uinputProbeRunning, onClick = {
            uinputProbeRunning = true
            Thread {
                val result = uinputProbeRunner.run()
                mainHandler.post {
                    uinputProbeResult = result
                    uinputProbeRunning = false
                }
            }.start()
        }) { Text(if (uinputProbeRunning) "Testando criação real..." else "Testar criação real do uinput") }
        uinputProbeResult?.let { execution ->
            Text("Backend: ${execution.backend ?: "nenhum"} · ${execution.result.detail}", color = if (execution.result.createdAndDestroyed) Color(0xFF42C98A) else Color(0xFFFFC078), style = MaterialTheme.typography.bodySmall)
        }

        Text("Nós OTG privilegiados (/dev/input)", color = Color(0xFF1597FF), style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                reader.stop()
                keyboardReader.stop()
                activeBackend = null
                exclusiveGrabActive = false
                captureStatus = "Procurando dispositivos..."
                privilegedDevices = emptyList()
                selectedPath = null
                selectedKeyboardPath = null
                Thread {
                    val found = reader.listDevices()
                    mainHandler.post {
                        privilegedDevices = found
                        val detectedMouse = found.firstOrNull { it.hasMouse }
                        val detectedKeyboard = found.firstOrNull { it.hasKeyboard }
                        selectedPath = detectedMouse?.path ?: found.firstOrNull { it.description.contains("mouse", true) }?.path
                        selectedKeyboardPath = detectedKeyboard?.path ?: detectedMouse?.takeIf { it.hasKeyboard }?.path
                        selectedPath?.let { devicePrefs.edit().putString("mouse_path", it).apply() }
                        selectedKeyboardPath?.let { devicePrefs.edit().putString("keyboard_path", it).apply() }
                        captureStatus = when {
                            found.isEmpty() -> "Nenhum nó acessível por Root/Shizuku"
                            detectedMouse != null && detectedKeyboard != null && detectedMouse.path == detectedKeyboard.path -> "HUB detectado: mouse + teclado no mesmo nó ${detectedMouse.path}"
                            detectedMouse != null && detectedKeyboard != null -> "HUB detectado: mouse ${detectedMouse.path} · teclado ${detectedKeyboard.path}"
                            detectedMouse != null -> "Mouse detectado em ${detectedMouse.path}; teclado não identificado automaticamente"
                            else -> "${found.size} nó(s) encontrado(s), mas não foi possível classificar mouse/teclado. Selecione manualmente."
                        }
                    }
                }.start()
            }) { Text("Detectar HUB automaticamente") }
            OutlinedButton(onClick = {
                reader.stop()
                keyboardReader.stop()
                activeBackend = null
                exclusiveGrabActive = false
                captureStatus = "Captura parada; contatos virtuais devem ser liberados pela sessão de jogo"
            }) { Text("Parar") }
        }

        if (privilegedDevices.isEmpty()) {
            Text("Nenhum /dev/input/event* listado. Conceda Root ou Shizuku e toque em Detectar HUB automaticamente.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        } else {
            LazyColumn(modifier = Modifier.weight(0.8f, fill = false).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(privilegedDevices, key = { it.path }) { device ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = if (selectedPath == device.path || selectedKeyboardPath == device.path) Color(0xFF173653) else Color(0xFF0D1B2B))
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(device.path, color = Color.White)
                            if (device.description.isNotBlank()) Text(device.description, color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
                            Text(
                                "${if (device.hasMouse) "Mouse" else ""}${if (device.hasMouse && device.hasKeyboard) " + " else ""}${if (device.hasKeyboard) "Teclado" else ""}".ifBlank { "Tipo não identificado automaticamente" },
                                color = if (device.hasMouse || device.hasKeyboard) Color(0xFF42C98A) else Color(0xFFFFC078),
                                style = MaterialTheme.typography.labelSmall
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { selectedPath = device.path; devicePrefs.edit().putString("mouse_path", device.path).apply() }) { Text(if (selectedPath == device.path) "✓ Mouse" else "Usar como mouse") }
                                OutlinedButton(onClick = { selectedKeyboardPath = device.path; devicePrefs.edit().putString("keyboard_path", device.path).apply() }) { Text(if (selectedKeyboardPath == device.path) "✓ Teclado" else "Usar como teclado") }
                            }
                        }
                    }
                }
            }
            Button(
                enabled = selectedPath != null && activeBackend == null,
                onClick = {
                    events.clear()
                    mappedEvents.clear()
                    captureStatus = "Iniciando captura nativa do mouse..."
                    val mousePath = selectedPath ?: return@Button
                    val keyboardPath = selectedKeyboardPath
                    val helper = java.io.File(context.applicationInfo.nativeLibraryDir, "libmt7-input-grab.so").absolutePath
                    Thread {
                        val mouseResult = reader.startNativeCapture(
                            devicePath = mousePath,
                            helperPath = helper,
                            onEvent = { event ->
                                val mapped = eventMapper.map(event)
                                mainHandler.post {
                                    events.add(event); if (events.size > 80) events.removeAt(0)
                                    if (mapped != null) { mappedEvents.add(mapped); if (mappedEvents.size > 80) mappedEvents.removeAt(0) }
                                }
                            },
                            onStopped = { reason -> mainHandler.post {
                                exclusiveGrabActive = false
                                if (reason != null) captureStatus = reason
                                activeBackend = null
                            } },
                            onGrabStatus = { active, error -> mainHandler.post {
                                exclusiveGrabActive = active
                                if (error != null) captureStatus = "Falha no grab: $error"
                            } }
                        )
                        var keyboardDetail = "Teclado não selecionado; WASD não será capturado separadamente."
                        if (mouseResult is OtgInputEventReader.StartResult.Started && keyboardPath != null && keyboardPath != mousePath) {
                            val keyboardResult = keyboardReader.start(
                                devicePath = keyboardPath,
                                onEvent = { event ->
                                    val mapped = eventMapper.map(event)
                                    mainHandler.post {
                                        events.add(event); if (events.size > 80) events.removeAt(0)
                                        if (mapped != null) { mappedEvents.add(mapped); if (mappedEvents.size > 80) mappedEvents.removeAt(0) }
                                    }
                                },
                                onStopped = { reason -> if (reason != null) mainHandler.post { captureStatus = "Teclado: $reason" } }
                            )
                            keyboardDetail = when (keyboardResult) {
                                is OtgInputEventReader.StartResult.Started -> "Teclado em ${keyboardResult.device.path}"
                                is OtgInputEventReader.StartResult.Failed -> "Falha no teclado: ${keyboardResult.reason}"
                            }
                        } else if (mouseResult is OtgInputEventReader.StartResult.Started && keyboardPath == mousePath) {
                            keyboardDetail = "Mouse e teclado atribuídos ao mesmo nó; captura nativa única."
                        }
                        mainHandler.post {
                            when (mouseResult) {
                                is OtgInputEventReader.StartResult.Started -> {
                                    activeBackend = mouseResult.backend.name
                                    captureStatus = "Mouse ${mouseResult.device.path} via ${mouseResult.backend}; $keyboardDetail"
                                }
                                is OtgInputEventReader.StartResult.Failed -> captureStatus = mouseResult.reason
                            }
                        }
                    }.start()
                }
            ) { Text("Testar captura nativa") }
            Button(
                enabled = selectedPath != null,
                onClick = {
                    val mousePath = selectedPath ?: return@Button
                    val keyboardPath = selectedKeyboardPath
                    reader.close()
                    keyboardReader.close()
                    val profile = ProfileStore(context).loadAll().first()
                    val serviceIntent = Intent(context, MT7InputService::class.java).apply {
                        action = MT7InputService.ACTION_START_MAPPING
                        putExtra(MT7InputService.EXTRA_MOUSE_DEVICE_PATH, mousePath)
                        putExtra(MT7InputService.EXTRA_KEYBOARD_DEVICE_PATH, keyboardPath)
                        putExtra(MT7InputService.EXTRA_PROFILE_ID, profile.id)
                    }
                    ContextCompat.startForegroundService(context, serviceIntent)
                    captureStatus = "Solicitado mapeamento real: mouse $mousePath" +
                        (keyboardPath?.let { " · teclado $it" } ?: " · teclado não selecionado")
                }
            ) { Text("Iniciar mapeamento no jogo") }
            OutlinedButton(
                enabled = activeBackend != null,
                onClick = {
                    val next = !exclusiveGrabActive
                    Thread {
                        val ok = reader.setExclusiveGrab(next)
                        mainHandler.post {
                            exclusiveGrabActive = ok && next
                            captureStatus = if (ok) if (next) "EVIOCGRAB confirmado" else "EVIOCGRAB liberado" else (reader.captureError() ?: "Falha ao alterar EVIOCGRAB")
                        }
                    }.start()
                }
            ) { Text(if (exclusiveGrabActive) "Liberar captura exclusiva" else "Ativar captura exclusiva") }
        }

        Text("Mouse selecionado: ${selectedPath ?: "não definido"}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        Text("Teclado selecionado: ${selectedKeyboardPath ?: "não definido"}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        Text(captureStatus, color = Color(0xFFCAD7E5), style = MaterialTheme.typography.bodySmall)
        activeBackend?.let { Text("Backend ativo: $it", color = Color(0xFF42C98A), style = MaterialTheme.typography.labelMedium) }
        Text("Ações interpretadas (${mappedEvents.size})", color = Color(0xFF1597FF), style = MaterialTheme.typography.titleSmall)
        LazyColumn(modifier = Modifier.fillMaxWidth().height(112.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(mappedEvents) { action ->
                Text(action.displayText(), color = Color(0xFF42C98A), style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("Eventos brutos recentes (${events.size})", color = Color(0xFF1597FF), style = MaterialTheme.typography.titleSmall)
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(events) { event ->
                Text(
                    "${event.timestamp ?: "--"}  type=${event.type.toString(16).padStart(4, '0')} code=${event.code.toString(16).padStart(4, '0')} value=${event.value}",
                    color = Color(0xFFCAD7E5), style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Text("Interpretação local de teclas e mouse. Ainda não há injeção de toques no jogo.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)

        if (devices.isNotEmpty()) {
            Text("Android: ${devices.joinToString { it.name }}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        }
    }
}
