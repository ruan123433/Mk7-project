package com.mt7.keymapper.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

object Neon {
    val Navy = Color(0xFF070B1A)
    val Panel = Color(0xFF10163A)
    val Panel2 = Color(0xFF161E4A)
    val Cyan = Color(0xFF00E5FF)
    val Magenta = Color(0xFFFF8A1F) // laranja elétrico da logo 2.4.9
    val Green = Color(0xFF35F0A0)
    val Amber = Color(0xFFFFC14D)
    val Muted = Color(0xFF9AA4C7)
    val Gradient = Brush.horizontalGradient(listOf(Cyan, Magenta))
    val Background = Brush.verticalGradient(listOf(Color(0xFF0A1A33), Navy))
}

@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    accent: Color = Neon.Cyan,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Neon.Panel2, Neon.Panel)))
            .border(1.dp, accent.copy(alpha = 0.55f), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun NeonButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .clip(shape)
            .background(Neon.Gradient)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun NeonOutlineButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(Neon.Navy.copy(alpha = 0.6f))
            .border(1.dp, Neon.Cyan, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Neon.Cyan, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StatusChip(text: String, color: Color) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = color,
        fontWeight = FontWeight.Bold,
        style = MaterialTheme.typography.labelMedium,
        modifier = Modifier
            .clip(shape)
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.6f), shape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}
