package com.mt7.keymapper.core.injection

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import com.mt7.keymapper.core.mapping.MultiTouchOutput

/**
 * Persistent privileged transport for the MT7 virtual multitouch device.
 * Commands are written to the helper's stdin; no Accessibility injection is used.
 * Root is preferred. Shizuku is accepted only if the helper reports a created device.
 */
class UinputTouchSession private constructor(
    private val process: Process,
    val backend: String,
    private val maxX: Int,
    private val maxY: Int
) : AutoCloseable, MultiTouchOutput {
    private val closed = AtomicBoolean(false)
    private val writeLock = Any()
    private val ready = CountDownLatch(1)
    @Volatile private var helperReady = false
    @Volatile private var outputFailure: String? = null

    init {
        Thread({
            try {
                BufferedReader(InputStreamReader(process.inputStream)).useLines { lines ->
                    lines.forEach { line ->
                        if (line == "MT7_UINPUT_SESSION:ready") {
                            helperReady = true
                            ready.countDown()
                        } else if (line.startsWith("MT7_UINPUT_SESSION:failed:")) {
                            outputFailure = line
                            ready.countDown()
                        }
                    }
                }
            } catch (error: Exception) {
                outputFailure = error.message ?: "Falha lendo saída do helper"
                ready.countDown()
            } finally {
                if (!helperReady && outputFailure == null) outputFailure = "Helper encerrou antes de ficar pronto"
                ready.countDown()
            }
        }, "MT7-uinput-output").apply { isDaemon = true; start() }
    }

    fun awaitReady(timeoutMs: Long = 4_000): Boolean = ready.await(timeoutMs, TimeUnit.MILLISECONDS) && helperReady

    override fun pointerDown(pointerId: Int, x: Int, y: Int): Boolean = send('D', pointerId, x, y)
    override fun pointerMove(pointerId: Int, x: Int, y: Int): Boolean = send('M', pointerId, x, y)
    override fun pointerUp(pointerId: Int): Boolean = send('U', pointerId, 0, 0)

    /** Releases all active contacts in the kernel device. */
    override fun cancelAll(): Boolean = writeCommand("C")

    private fun send(command: Char, pointerId: Int, x: Int, y: Int): Boolean {
        require(pointerId >= 0) { "pointerId não pode ser negativo" }
        return writeCommand("$command $pointerId ${x.coerceIn(0, maxX)} ${y.coerceIn(0, maxY)}")
    }

    private fun writeCommand(value: String): Boolean = synchronized(writeLock) {
        if (closed.get() || !helperReady || outputFailure != null || !process.isAlive) return@synchronized false
        runCatching {
            process.outputStream.write((value + "\n").toByteArray(Charsets.UTF_8))
            process.outputStream.flush()
        }.isSuccess
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        synchronized(writeLock) {
            runCatching {
                process.outputStream.write("Q\n".toByteArray(Charsets.UTF_8))
                process.outputStream.flush()
                process.outputStream.close()
            }
        }
        runCatching {
            if (!process.waitFor(1, TimeUnit.SECONDS)) {
                process.destroy()
                if (!process.waitFor(500, TimeUnit.MILLISECONDS)) process.destroyForcibly()
            }
        }
    }

    companion object {
        data class StartResult(val session: UinputTouchSession?, val detail: String)

        fun start(context: Context, maxX: Int, maxY: Int, slots: Int = 10): StartResult {
            require(maxX > 0 && maxY > 0 && slots in 1..32)
            val helper = File(context.applicationInfo.nativeLibraryDir, HELPER_NAME)
            if (!helper.isFile) return StartResult(null, "Helper nativo ausente: ${helper.absolutePath}")
            val command = "${quote(helper.absolutePath)} --serve /dev/uinput $maxX $maxY $slots"
            val root = launchRoot(command)
            if (root != null) {
                val session = UinputTouchSession(root, "Root", maxX, maxY)
                if (session.awaitReady()) return StartResult(session, "Touchscreen virtual criado via Root")
                val detail = "Root não criou o dispositivo: ${session.outputFailure ?: "timeout"}"
                session.close()
                val shizuku = launchShizuku(command)
                if (shizuku != null) {
                    val fallback = UinputTouchSession(shizuku, "Shizuku", maxX, maxY)
                    if (fallback.awaitReady()) return StartResult(fallback, "Touchscreen virtual criado via Shizuku; $detail")
                    val failure = fallback.outputFailure ?: "timeout"
                    fallback.close()
                    return StartResult(null, "$detail | Shizuku não criou o dispositivo: $failure")
                }
                return StartResult(null, "$detail | Shizuku indisponível")
            }
            val shizuku = launchShizuku(command)
                ?: return StartResult(null, "Não foi possível iniciar helper via Root nem Shizuku")
            val session = UinputTouchSession(shizuku, "Shizuku", maxX, maxY)
            if (session.awaitReady()) return StartResult(session, "Touchscreen virtual criado via Shizuku")
            val detail = session.outputFailure ?: "timeout"
            session.close()
            return StartResult(null, "Shizuku não criou o dispositivo: $detail")
        }

        private fun launchRoot(command: String): Process? = runCatching {
            ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        }.getOrNull()

        @Suppress("DEPRECATION")
        private fun launchShizuku(command: String): Process? = runCatching {
            check(Shizuku.pingBinder()) { "Shizuku desconectado" }
            check(Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { "Permissão Shizuku não concedida" }
            com.mt7.keymapper.core.activation.ShizukuProcess.start(command)
        }.getOrNull()

        private fun quote(value: String): String = "'" + value.replace("'", "'\"'\"'") + "'"
        private const val HELPER_NAME = "libmt7-uinput-probe.so"
    }
}
