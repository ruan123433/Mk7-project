package com.mt7.keymapper.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mt7.keymapper.core.mapping.*
import com.mt7.keymapper.service.MT7InputService

private val FloatPanel = Color(0xFF101B2B)
private val FloatBlue = Color(0xFF1597FF)
private val FloatMuted = Color(0xFF9CB0C7)

/** Compact in-game editor hosted directly inside the MT7 floating overlay. */
@Composable
fun FloatingMappingEditor(
    context: Context,
    initialSection: String = "VISTA",
    onClose: () -> Unit,
    onPositionModeChanged: (Boolean) -> Unit = {}
) {
    val store = remember(context) { ProfileStore(context) }
    var profiles by remember { mutableStateOf(store.loadAll()) }
    var profile by remember { mutableStateOf(profiles.first()) }
    var section by remember { mutableStateOf(initialSection) }
    var keyText by remember { mutableStateOf("") }
    var profileName by remember { mutableStateOf("") }
    var comboKeys by remember { mutableStateOf("") }
    var comboTarget by remember { mutableStateOf("ESPAÇO") }
    val cursorPrefs = remember(context) { context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE) }
    var cursorSize by remember { mutableStateOf(cursorPrefs.getFloat("cursor_size_dp", 34f).coerceIn(18f, 64f)) }
    var cursorSpeed by remember { mutableStateOf(cursorPrefs.getFloat("cursor_speed", 1f).coerceIn(0.25f, 3f)) }
    var status by remember { mutableStateOf("Alterações ficam salvas no perfil selecionado.") }

    fun update(next: MappingProfile) { profile = next }
    fun saveCursorPreference(key: String, value: Float) {
        cursorPrefs.edit().putFloat(key, value).apply()
        context.startService(Intent(context, MT7InputService::class.java).apply {
            action = MT7InputService.ACTION_REFRESH_SOFTWARE_CURSOR
        })
    }
    fun persist() {
        val ok = store.save(profile)
        profiles = store.loadAll()
        if (ok) {
            context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE).edit()
                .putBoolean("suspend_pointer_while_aiming", profile.suspendPointerWhileAiming).apply()
            context.getSharedPreferences("mt7_optimization", Context.MODE_PRIVATE).edit()
                .putFloat("filter", profile.optimizationFilter)
                .putFloat("threshold", profile.optimizationThreshold)
                .putFloat("burst", profile.optimizationBurst)
                .putFloat("brake", profile.optimizationBrake).apply()
            context.startService(Intent(context, MT7InputService::class.java).apply {
                action = MT7InputService.ACTION_RELOAD_PROFILE
                putExtra(MT7InputService.EXTRA_PROFILE_ID, profile.id)
            })
            status = "Perfil salvo e atualização enviada ao serviço."
        } else status = "Não foi possível salvar o perfil."
    }
    fun sensitivity(mode: String, x: Float? = null, y: Float? = null): MappingProfile {
        val pair = when (mode) {
            "COMBATE" -> profile.combatSensitivityX to profile.combatSensitivityY
            "PRECISAO" -> profile.precisionSensitivityX to profile.precisionSensitivityY
            else -> profile.normalSensitivityX to profile.normalSensitivityY
        }
        val nx = (x ?: pair.first).coerceIn(0.2f, 10f)
        val ny = (y ?: pair.second).coerceIn(0.1f, 10f)
        val base = when (mode) {
            "COMBATE" -> profile.copy(combatSensitivityX = nx, combatSensitivityY = ny)
            "PRECISAO" -> profile.copy(precisionSensitivityX = nx, precisionSensitivityY = ny)
            else -> profile.copy(normalSensitivityX = nx, normalSensitivityY = ny)
        }
        val active = if (profile.viewMode == mode) base.copy(sensitivityX = nx, sensitivityY = ny) else base
        return active
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = FloatBlue, background = FloatPanel, surface = Color(0xFF17263A))) {
        if (section == "POSICIONAR") {
            // A transparent, full-screen layer lets the real game HUD remain visible underneath.
            Box(Modifier.fillMaxSize().background(Color.Transparent)) {
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val widthPx = constraints.maxWidth.toFloat()
                    val heightPx = constraints.maxHeight.toFloat()
                    DragPositionHandle("JOYSTICK", profile.joystickPositionX, profile.joystickPositionY, widthPx, heightPx, FloatBlue) { x, y -> update(profile.copy(joystickPositionX = x, joystickPositionY = y)) }
                    DragPositionHandle("VISTA", profile.viewPositionX, profile.viewPositionY, widthPx, heightPx, Color(0xFF8B7CFF)) { x, y -> update(profile.copy(viewPositionX = x, viewPositionY = y)) }
                    DragPositionHandle("TIRO", profile.firePositionX, profile.firePositionY, widthPx, heightPx, Color(0xFFFF756E)) { x, y -> update(profile.copy(firePositionX = x, firePositionY = y)) }
                    DragPositionHandle("PULAR", profile.jumpPositionX, profile.jumpPositionY, widthPx, heightPx, Color(0xFF38BFA0)) { x, y -> update(profile.copy(jumpPositionX = x, jumpPositionY = y)) }
                    DragPositionHandle("RECARREGAR", profile.reloadPositionX, profile.reloadPositionY, widthPx, heightPx, Color(0xFFE0A84B)) { x, y -> update(profile.copy(reloadPositionX = x, reloadPositionY = y)) }
                    DragPositionHandle("INTERAGIR", profile.interactPositionX, profile.interactPositionY, widthPx, heightPx, Color(0xFFB77AE8)) { x, y -> update(profile.copy(interactPositionX = x, interactPositionY = y)) }
                    profile.keyTaps.forEach { binding ->
                        DragPositionHandle(binding.key, binding.x, binding.y, widthPx, heightPx, Color(0xFF4DA6D8)) { x, y ->
                            update(profile.copy(keyTaps = profile.keyTaps.map { if (it.key == binding.key) it.copy(x = x, y = y) else it }))
                        }
                    }
                }

                Column(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth()
                        .background(Color(0x990A1421), RoundedCornerShape(bottomStart = 14.dp, bottomEnd = 14.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("MT7 • POSICIONAR NO HUD", color = FloatBlue, fontWeight = FontWeight.Black, fontSize = 15.sp)
                            Text("${profile.name} • fundo do jogo transparente", color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp)
                        }
                        TextButton(onClick = onClose) { Text("FECHAR", color = Color.White) }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("VISTA", "TIRO", "JOYSTICK", "SETA", "POSICIONAR", "TECLAS", "COMBOS", "PERFIL", "OTIMIZAR").forEach { item ->
                            TextButton(onClick = {
                                onPositionModeChanged(item == "POSICIONAR")
                                section = item
                            }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp)) {
                                Text(item, fontSize = 9.sp, color = if (section == item) FloatBlue else Color.White.copy(alpha = 0.85f), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color(0x990A1421), RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Text("Arraste os marcadores até a posição dos botões que aparecem no HUD do jogo.", color = Color.White, fontSize = 10.sp)
                    Text(status, color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp)
                    Button(onClick = { persist() }, modifier = Modifier.fillMaxWidth()) { Text("SALVAR E APLICAR PERFIL") }
                }
            }
        } else {
        Box(Modifier.fillMaxSize().background(Color.Transparent)) {
        Column(
            (if (initialSection == "POSICIONAR") Modifier.width(340.dp).heightIn(min = 280.dp, max = 570.dp) else Modifier.fillMaxSize())
                .background(FloatPanel, RoundedCornerShape(16.dp)).padding(12.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("MT7 • EDITAR KEYMAP", color = FloatBlue, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    Text("Central flutuante • ${profile.name}", color = FloatMuted, fontSize = 10.sp)
                }
                TextButton(onClick = onClose) { Text("FECHAR") }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf("VISTA", "TIRO", "JOYSTICK", "SETA", "POSICIONAR", "TECLAS", "COMBOS", "PERFIL", "OTIMIZAR").forEach { item ->
                    TextButton(onClick = {
                        onPositionModeChanged(item == "POSICIONAR")
                        section = item
                    }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 3.dp)) {
                        Text(item, fontSize = 9.sp, color = if (section == item) FloatBlue else FloatMuted, fontWeight = FontWeight.Bold)
                    }
                }
            }
            HorizontalDivider(color = Color(0xFF29415D))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 10.dp)) {
                when (section) {
                    "VISTA" -> {
                        item { Text("MODO DE VISTA", color = Color.White, fontWeight = FontWeight.Bold) }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                listOf("NORMAL", "COMBATE", "PRECISAO").forEach { mode ->
                                    Button(onClick = {
                                        val pair = when (mode) {
                                            "COMBATE" -> profile.combatSensitivityX to profile.combatSensitivityY
                                            "PRECISAO" -> profile.precisionSensitivityX to profile.precisionSensitivityY
                                            else -> profile.normalSensitivityX to profile.normalSensitivityY
                                        }
                                        update(profile.copy(viewMode = mode, sensitivityX = pair.first, sensitivityY = pair.second))
                                    }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text(if (mode == "PRECISAO") "PRECISÃO" else mode, fontSize = 9.sp) }
                                }
                            }
                        }
                        val mode = profile.viewMode
                        item { FloatSlider("Sensibilidade X • horizontal", profile.sensitivityX, 0.2f, 10f) { update(sensitivity(mode, x = it)) } }
                        item { FloatSlider("Sensibilidade Y • vertical", profile.sensitivityY, 0.1f, 10f) { update(sensitivity(mode, y = it)) } }
                        item {
                            val viewKeys = listOf("Mouse do meio", "SHIFT ESQ", "CTRL ESQ", "ALT ESQ", "Q", "E", "F", "G", "V")
                            val currentIndex = viewKeys.indexOf(profile.viewToggleBinding).coerceAtLeast(0)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column(Modifier.weight(1f)) {
                                    Text("Tecla para ativar Vista", color = Color.White, fontSize = 11.sp)
                                    Text(profile.viewToggleBinding, color = FloatBlue, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(onClick = { update(profile.copy(viewToggleBinding = viewKeys[(currentIndex + 1) % viewKeys.size])) }) { Text("TROCAR") }
                            }
                        }
                        item { FloatSlider("Posição da Vista • X", profile.viewPositionX, 0f, 1f) { update(profile.copy(viewPositionX = it)) } }
                        item { FloatSlider("Posição da Vista • Y", profile.viewPositionY, 0f, 1f) { update(profile.copy(viewPositionY = it)) } }
                    }
                    "TIRO" -> {
                        item { Text("BOTÃO DE TIRO", color = Color.White, fontWeight = FontWeight.Bold) }
                        item { FloatSlider("Força da remada vertical • ${"%.1f".format(profile.firePullMultiplier)}×", profile.firePullMultiplier, 0.5f, 3f) { update(profile.copy(firePullMultiplier = it)) } }
                        item { FloatSlider("Posição do tiro • X", profile.firePositionX, 0f, 1f) { update(profile.copy(firePositionX = it)) } }
                        item { FloatSlider("Posição do tiro • Y", profile.firePositionY, 0f, 1f) { update(profile.copy(firePositionY = it)) } }
                        item { Text("Amplifica somente o movimento vertical que você fizer com o mouse enquanto atira.", color = FloatMuted, fontSize = 10.sp) }
                    }
                    "JOYSTICK" -> {
                        item { Text("JOYSTICK", color = Color.White, fontWeight = FontWeight.Bold) }
                        item { FloatSlider("Sensibilidade horizontal", profile.joystickSensitivityX, 0.1f, 2f) { update(profile.copy(joystickSensitivityX = it)) } }
                        item { FloatSlider("Sensibilidade vertical", profile.joystickSensitivityY, 0.1f, 2f) { update(profile.copy(joystickSensitivityY = it)) } }
                        item { FloatSlider("Zona morta", profile.joystickDeadzone, 0f, 0.5f) { update(profile.copy(joystickDeadzone = it)) } }
                        item { FloatSlider("Posição X", profile.joystickPositionX, 0f, 1f) { update(profile.copy(joystickPositionX = it)) } }
                        item { FloatSlider("Posição Y", profile.joystickPositionY, 0f, 1f) { update(profile.copy(joystickPositionY = it)) } }
                    }
                    "SETA" -> {
                        item { Text("SETA PRÓPRIA MT7", color = Color.White, fontWeight = FontWeight.Bold) }
                        item {
                            var enabled by remember(profile.id) { mutableStateOf(profile.suspendPointerWhileAiming) }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Ativar seta independente", color = Color.White, fontSize = 11.sp)
                                    Text(if (enabled) "Usa a seta MT7 e captura o mouse durante o mapeamento" else "Mantém a seta padrão do Android", color = FloatMuted, fontSize = 10.sp)
                                }
                                Switch(checked = enabled, onCheckedChange = { value ->
                                    enabled = value
                                    update(profile.copy(suspendPointerWhileAiming = value))
                                    context.startService(Intent(context, MT7InputService::class.java).apply {
                                        action = MT7InputService.ACTION_SET_POINTER_SUSPENSION
                                        putExtra(MT7InputService.EXTRA_POINTER_SUSPENSION_ENABLED, value)
                                    })
                                })
                            }
                        }
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("Tamanho da seta: ${cursorSize.toInt()} dp", color = Color.White, fontSize = 12.sp)
                                Slider(value = cursorSize, onValueChange = { cursorSize = it }, onValueChangeFinished = { saveCursorPreference("cursor_size_dp", cursorSize) }, valueRange = 18f..64f)
                            }
                        }
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("Velocidade da seta: ${"%.2f".format(cursorSpeed)}×", color = Color.White, fontSize = 12.sp)
                                Slider(value = cursorSpeed, onValueChange = { cursorSpeed = it }, onValueChangeFinished = { saveCursorPreference("cursor_speed", cursorSpeed) }, valueRange = 0.25f..3f)
                            }
                        }
                        item {
                            Text("CONFIGURAÇÃO DE CLIQUE", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Clique esquerdo: botão de tiro (fixo). Clique do meio: ${profile.viewToggleBinding} (ajustável em Vista). Clique direito:", color = FloatMuted, fontSize = 10.sp)
                        }
                        item {
                            val clickOptions = listOf("Nenhuma", "ESPAÇO", "R", "F") + profile.keyTaps.map { it.key }
                            val current = profile.mouseRightMappedKey
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Ação do clique direito", color = Color.White, fontSize = 11.sp)
                                    Text(current, color = FloatBlue, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(onClick = {
                                    val index = clickOptions.indexOf(current).coerceAtLeast(0)
                                    update(profile.copy(mouseRightMappedKey = clickOptions[(index + 1) % clickOptions.size]))
                                }) { Text("TROCAR") }
                            }
                        }
                        item { Text("Salve e aplique o perfil para ativar a configuração do clique direito. A seta é visual e não intercepta os toques do jogo.", color = FloatMuted, fontSize = 10.sp) }
                    }
                    "TECLAS" -> {
                        item { Text("TECLAS MAPEADAS", color = Color.White, fontWeight = FontWeight.Bold) }
                        item { Text("Delay entre ativações: ${profile.keyRepeatDelayMs.coerceIn(1, 50)} ms", color = FloatMuted) }
                        item { Slider(value = profile.keyRepeatDelayMs.coerceIn(1, 50).toFloat(), onValueChange = { update(profile.copy(keyRepeatDelayMs = it.toInt().coerceIn(1, 50))) }, valueRange = 1f..50f, steps = 48) }
                        item { Text("Ajuste disponível de 1 ms até 50 ms para as teclas mapeadas.", color = FloatMuted, fontSize = 10.sp) }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedTextField(value = keyText, onValueChange = { keyText = it.take(16) }, label = { Text("Tecla (ex.: G, SHIFT)") }, modifier = Modifier.weight(1f), singleLine = true)
                                Button(onClick = {
                                    val key = KeyTapBindings.canonicalKey(keyText)
                                    if (key.isNotBlank() && key != "Nenhuma" && key.uppercase() !in KeyTapBindings.RESERVED && profile.keyTaps.none { it.key == key } && profile.keyTaps.size < KeyTapBindings.MAX_BINDINGS) {
                                        update(profile.copy(keyTaps = profile.keyTaps + KeyTapBinding(key, 0.5f, 0.5f)))
                                        keyText = ""
                                    }
                                }, enabled = keyText.isNotBlank() && profile.keyTaps.size < KeyTapBindings.MAX_BINDINGS) { Text("+") }
                            }
                        }
                        items(profile.keyTaps, key = { it.key }) { binding ->
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${binding.key} • ${(binding.x * 100).toInt()}%, ${(binding.y * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                                    TextButton(onClick = { update(profile.copy(keyTaps = profile.keyTaps.filterNot { it.key == binding.key })) }) { Text("REMOVER") }
                                }
                                FloatSlider("${binding.key} posição X", binding.x, 0f, 1f) { v -> update(profile.copy(keyTaps = profile.keyTaps.map { if (it.key == binding.key) it.copy(x = v) else it })) }
                                FloatSlider("${binding.key} posição Y", binding.y, 0f, 1f) { v -> update(profile.copy(keyTaps = profile.keyTaps.map { if (it.key == binding.key) it.copy(y = v) else it })) }
                            }
                        }
                    }
                    "COMBOS" -> {
                        item { Text("COMBINAÇÕES DE TECLAS", color = Color.White, fontWeight = FontWeight.Bold) }
                        item { Text("Exemplo: CTRL ESQ+1 aciona ESPAÇO. Use de 2 a 4 teclas físicas.", color = FloatMuted, fontSize = 10.sp) }
                        item {
                            OutlinedTextField(
                                value = comboKeys,
                                onValueChange = { comboKeys = it.take(48) },
                                label = { Text("Teclas (ex.: CTRL ESQ+1)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("ESPAÇO", "R", "F").forEach { target ->
                                    FilterChip(selected = comboTarget == target, onClick = { comboTarget = target }, label = { Text(target) })
                                }
                            }
                        }
                        item {
                            Button(
                                onClick = {
                                    val allowed = setOf("ESPAÇO", "R", "F") + profile.keyTaps.map { it.key }
                                    val parsed = KeyComboBindings.parse("${comboKeys}=${comboTarget}", allowed)
                                    val candidate = parsed.firstOrNull()
                                    if (candidate != null && profile.keyCombos.none { it.signature == candidate.signature || it.targetKey == candidate.targetKey } && profile.keyCombos.size < KeyComboBindings.MAX_BINDINGS) {
                                        update(profile.copy(keyCombos = profile.keyCombos + candidate))
                                        comboKeys = ""
                                        status = "Combinação adicionada. Salve para aplicar."
                                    } else {
                                        status = "Combinação inválida, repetida ou limite de 16 atingido."
                                    }
                                },
                                enabled = comboKeys.isNotBlank() && profile.keyCombos.size < KeyComboBindings.MAX_BINDINGS,
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("ADICIONAR COMBINAÇÃO") }
                        }
                        items(profile.keyCombos, key = { it.signature }) { combo ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${combo.signature} → ${combo.targetKey}", color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                TextButton(onClick = { update(profile.copy(keyCombos = profile.keyCombos.filterNot { it.signature == combo.signature })) }) { Text("REMOVER") }
                            }
                        }
                    }
                    "PERFIL" -> {
                        item { Text("PERFIS", color = Color.White, fontWeight = FontWeight.Bold) }
                        item {
                            OutlinedTextField(value = profileName, onValueChange = { profileName = it.take(24) }, label = { Text("Nome do novo perfil") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        }
                        item {
                            Button(onClick = {
                                val name = profileName.trim()
                                if (name.isNotEmpty() && profiles.none { it.name.equals(name, ignoreCase = true) }) {
                                    store.save(profile)
                                    val created = profile.copy(id = java.util.UUID.randomUUID().toString(), name = name)
                                    if (store.save(created)) {
                                        profiles = store.loadAll()
                                        profile = created
                                        profileName = ""
                                        status = "Perfil $name criado. Salve e aplique para ativá-lo."
                                    } else status = "Não foi possível criar o perfil."
                                } else status = "Informe um nome novo para o perfil."
                            }, modifier = Modifier.fillMaxWidth(), enabled = profileName.isNotBlank()) { Text("CRIAR CÓPIA DESTE PERFIL") }
                        }
                        items(profiles, key = { it.id }) { item ->
                            Button(onClick = {
                                store.save(profile)
                                profile = store.loadAll().firstOrNull { it.id == item.id } ?: item
                                profiles = store.loadAll()
                                status = "Perfil ${profile.name} selecionado."
                            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (profile.id == item.id) Color(0xFF155A91) else Color(0xFF26384D))) { Text(if (profile.id == item.id) "✓ ${item.name}" else item.name) }
                        }
                    }
                    else -> {
                        item { Text("OTIMIZAÇÃO EXPERIMENTAL DA CÂMERA", color = Color.White, fontWeight = FontWeight.Bold) }
                        item { FloatSlider("Filtro", profile.optimizationFilter, 0f, 0.8f) { update(profile.copy(optimizationFilter = it)) } }
                        item { FloatSlider("Limiar", profile.optimizationThreshold, 0f, 4f) { update(profile.copy(optimizationThreshold = it)) } }
                        item { FloatSlider("Burst", profile.optimizationBurst, 0f, 0.5f) { update(profile.copy(optimizationBurst = it)) } }
                        item { FloatSlider("Freio", profile.optimizationBrake, 0f, 0.8f) { update(profile.copy(optimizationBrake = it)) } }
                        item { Text("Os controles são aplicados ao movimento relativo da câmera; comece com valores baixos.", color = FloatMuted, fontSize = 10.sp) }
                    }
                }
            }
            Text(status, color = FloatMuted, fontSize = 10.sp)
            Button(onClick = { persist() }, modifier = Modifier.fillMaxWidth()) { Text("SALVAR E APLICAR PERFIL") }
        }
        }
        }
    }
}

@Composable
private fun DragPositionHandle(
    label: String,
    x: Float,
    y: Float,
    widthPx: Float,
    heightPx: Float,
    tint: Color,
    onMove: (Float, Float) -> Unit
) {
    val density = LocalDensity.current
    val halfWidth = with(density) { 42.dp.toPx() }
    val halfHeight = with(density) { 18.dp.toPx() }
    Surface(
        color = tint.copy(alpha = 0.78f),
        contentColor = Color.White,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .offset {
                IntOffset(
                    (x.coerceIn(0f, 1f) * widthPx - halfWidth).roundToInt(),
                    (y.coerceIn(0f, 1f) * heightPx - halfHeight).roundToInt()
                )
            }
            .pointerInput(widthPx, heightPx, x, y) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onMove(
                        (x + dragAmount.x / widthPx.coerceAtLeast(1f)).coerceIn(0.03f, 0.97f),
                        (y + dragAmount.y / heightPx.coerceAtLeast(1f)).coerceIn(0.05f, 0.95f)
                    )
                }
            }
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 9.dp, vertical = 7.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun FloatSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text("$label: ${"%.2f".format(value)}", color = Color.White, fontSize = 12.sp)
        Slider(value = value.coerceIn(min, max), onValueChange = onChange, valueRange = min..max)
    }
}
