package com.mt7.keymapper.core.runtime

/**
 * Thread-safe counters for the live OTG -> mapper -> uinput pipeline.
 * Timings measure synchronous processing only; they are not end-to-end display latency.
 */
data class InputEngineSnapshot(
    val eventsReceived: Long,
    val actionsProduced: Long,
    val actionsDelivered: Long,
    val deliveryFailures: Long,
    val ignoredEvents: Long,
    val lastProcessingMicros: Long,
    val maxProcessingMicros: Long
)

class InputEngineDiagnostics {
    private val events = java.util.concurrent.atomic.AtomicLong()
    private val actions = java.util.concurrent.atomic.AtomicLong()
    private val delivered = java.util.concurrent.atomic.AtomicLong()
    private val failures = java.util.concurrent.atomic.AtomicLong()
    private val ignored = java.util.concurrent.atomic.AtomicLong()
    private val lastMicros = java.util.concurrent.atomic.AtomicLong()
    private val maxMicros = java.util.concurrent.atomic.AtomicLong()

    fun record(startNanos: Long, producedAction: Boolean, delivery: Boolean?) {
        events.incrementAndGet()
        if (producedAction) actions.incrementAndGet()
        when (delivery) {
            true -> delivered.incrementAndGet()
            false -> failures.incrementAndGet()
            null -> if (!producedAction) ignored.incrementAndGet()
        }
        val elapsed = ((System.nanoTime() - startNanos).coerceAtLeast(0L)) / 1_000L
        lastMicros.set(elapsed)
        maxMicros.accumulateAndGet(elapsed) { current, next -> maxOf(current, next) }
    }

    fun snapshot() = InputEngineSnapshot(
        events.get(), actions.get(), delivered.get(), failures.get(), ignored.get(),
        lastMicros.get(), maxMicros.get()
    )

    fun reset() {
        events.set(0); actions.set(0); delivered.set(0); failures.set(0); ignored.set(0)
        lastMicros.set(0); maxMicros.set(0)
    }
}
