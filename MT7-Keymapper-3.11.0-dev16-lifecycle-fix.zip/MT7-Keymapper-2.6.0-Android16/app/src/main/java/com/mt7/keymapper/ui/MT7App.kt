package com.mt7.keymapper.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mt7.keymapper.core.activation.ActivationRepository
import com.mt7.keymapper.core.mapping.KeyTapBinding
import com.mt7.keymapper.core.mapping.KeyTapBindings
import com.mt7.keymapper.core.mapping.MappingProfile
import com.mt7.keymapper.core.mapping.ProfileStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF0D1B2B)
private val Blue = Color(0xFF1597FF)
private val Muted = Color(0xFF9CB0C7)
private val Green = Color(0xFF35D07F)

@Composable
fun MT7App(activationRepository: ActivationRepository) {
    val context = LocalContext.current
    val store = remember(context) { ProfileStore(context) }
    var profiles by remember { mutableStateOf(store.loadAll()) }
    var selectedId by remember { mutableStateOf(profiles.first().id) }
    var editing by remember { mutableStateOf(false) }
    var diagnostics by remember { mutableStateOf(false) }
    var profile by remember { mutableStateOf(profiles.first()) }
    var saveMessage by remember { mutableStateOf("") }
    val shizuku = remember { activationRepository.inspectShizukuNow() }
    val root = remember { activationRepository.inspectRootNow() }
    val screenshotPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            profile = profile.copy(calibrationImageUri = uri.toString())
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Panel, primary = Blue, onBackground = Color.White, onSurface = Color.White)) {
        if (diagnostics) {
            BackendDiagnosticsScreen(
                shizukuAvailable = shizuku.available,
                shizukuDetail = shizuku.detail,
                rootAvailable = root.available,
                rootDetail = root.detail,
                profileCount = profiles.size,
                selectedProfileName = profiles.firstOrNull { it.id == selectedId }?.name ?: "Nenhum",
                onBack = { diagnostics = false }
            )
        } else if (editing) {
            VisualMappingEditor(
                profile = profile,
                onProfileChange = { profile = it },
                onBack = { editing = false; saveMessage = "" },
                onSave = {
                    val ok = store.save(profile)
                    if (ok) {
                        profiles = store.loadAll()
                        selectedId = profile.id
                        saveMessage = "Perfil salvo neste dispositivo."
                    } else saveMessage = "Não foi possível salvar o perfil."
                },
                saveMessage = saveMessage,
                onImportScreenshot = { screenshotPicker.launch(arrayOf("image/*")) }
            )
        } else {
            Scaffold(containerColor = Navy) { padding ->
                LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("MT7", color = Blue, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                            Text("KEYMAPPER", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Precisão total. Controle absoluto.", color = Muted)
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Editor visual", color = Blue, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("Arraste os controles até as posições desejadas na tela de jogo e salve no perfil.", color = Muted)
                                Button(onClick = { profile = profiles.firstOrNull { it.id == selectedId } ?: profiles.first(); editing = true }) { Text("Abrir editor de tela") }
                            }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Diagnóstico em tempo real", color = Blue, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("Confira permissões, backends e estado de preparação antes de iniciar uma sessão OTG.", color = Muted)
                                Button(onClick = { diagnostics = true }) { Text("Abrir painel de diagnóstico") }
                            }
                        }
                    }
                    item { Text("Ativação híbrida", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                    item { BackendCard("Android", "Disponível", true, "Funções locais do aplicativo") }
                    item { BackendCard("Shizuku", if (shizuku.available) "Conectado" else "Não conectado", shizuku.available, shizuku.detail) }
                    item { BackendCard("Root", "Verificar disponibilidade", root.available, root.detail) }
                    item { Text("Perfis", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                    items(profiles.size) { index ->
                        val item = profiles[index]
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                RadioButton(selected = selectedId == item.id, onClick = { selectedId = item.id })
                                Column(Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.SemiBold)
                                    Text("${item.keyTaps.size} controles • ${item.keyCombos.size} combos", color = Muted, style = MaterialTheme.typography.bodySmall)
                                }
                                TextButton(onClick = { profile = item; selectedId = item.id; editing = true }) { Text("EDITAR", color = Blue) }
                            }
                        }
                    }
                    item { Text("MT7 v3.9.0-dev1 • Live diagnostics", color = Muted, style = MaterialTheme.typography.labelSmall) }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VisualMappingEditor(
    profile: MappingProfile,
    onProfileChange: (MappingProfile) -> Unit,
    onBack: () -> Unit,
    onSave: () -> Unit,
    saveMessage: String,
    onImportScreenshot: () -> Unit
) {
    var newKey by remember { mutableStateOf("") }
    var selectedMarker by remember { mutableStateOf("view") }
    val calibrationBitmap = rememberCalibrationBitmap(profile.calibrationImageUri)
    Scaffold(containerColor = Navy, topBar = {
        TopAppBar(
            title = { Text("Editor de tela", fontWeight = FontWeight.Bold) },
            navigationIcon = { TextButton(onClick = onBack) { Text("VOLTAR", color = Blue) } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White)
        )
    }, bottomBar = {
        Surface(color = Panel) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Cancelar") }
                Button(onClick = onSave, modifier = Modifier.weight(1f)) { Text("Salvar perfil") }
            }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Editor de layout", color = Blue, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Arraste cada controle até a posição correspondente na tela do jogo. As posições são proporcionais e acompanham diferentes resoluções.", color = Muted, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onImportScreenshot) { Text(if (profile.calibrationImageUri == null) "Importar captura" else "Trocar captura") }
                if (profile.calibrationImageUri != null) {
                    TextButton(onClick = { onProfileChange(profile.copy(calibrationImageUri = null)) }) { Text("Remover", color = Color(0xFFFF8A80)) }
                }
            }
            BoxWithConstraints(
                Modifier.fillMaxWidth().weight(1f).background(Color(0xFF101F31), RoundedCornerShape(18.dp)).padding(8.dp)
            ) {
                val imageRatio = calibrationBitmap?.let { it.width.toFloat() / it.height.coerceAtLeast(1) } ?: (16f / 9f)
                val canvasWidth = minOf(maxWidth, maxHeight * imageRatio)
                val canvasHeight = canvasWidth / imageRatio
                val density = LocalDensity.current
                val widthPx = with(density) { canvasWidth.toPx().coerceAtLeast(1f) }
                val heightPx = with(density) { canvasHeight.toPx().coerceAtLeast(1f) }
                Box(Modifier.width(canvasWidth).height(canvasHeight).align(Alignment.Center).background(Color(0xFF172B40), RoundedCornerShape(14.dp))) {
                    if (calibrationBitmap != null) {
                        Image(bitmap = calibrationBitmap.asImageBitmap(), contentDescription = "Captura de jogo para calibração", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                    } else {
                        Text(if (profile.calibrationImageUri == null) "IMPORTAR UMA CAPTURA DO JOGO" else "CAPTURA INDISPONÍVEL — IMPORTE OUTRA", Modifier.fillMaxSize().wrapContentSize(Alignment.Center), color = Muted, fontSize = 11.sp)
                        Text("Prévia ilustrativa", Modifier.align(Alignment.BottomCenter).padding(8.dp), color = Muted.copy(alpha = 0.7f), fontSize = 9.sp)
                    }
                    DraggableMarker("joystick", "MOV", profile.joystickPositionX, profile.joystickPositionY, widthPx, heightPx, Color(0xFF1597FF), selectedMarker == "joystick", { selectedMarker = "joystick" }) { x, y -> onProfileChange(profile.copy(joystickPositionX = x, joystickPositionY = y)) }
                    DraggableMarker("view", "AIM", profile.viewPositionX, profile.viewPositionY, widthPx, heightPx, Color(0xFFB36BFF), selectedMarker == "view", { selectedMarker = "view" }) { x, y -> onProfileChange(profile.copy(viewPositionX = x, viewPositionY = y)) }
                    DraggableMarker("fire", "FIRE", profile.firePositionX, profile.firePositionY, widthPx, heightPx, Color(0xFFFF685E), selectedMarker == "fire", { selectedMarker = "fire" }) { x, y -> onProfileChange(profile.copy(firePositionX = x, firePositionY = y)) }
                    DraggableMarker("jump", "PULO", profile.jumpPositionX, profile.jumpPositionY, widthPx, heightPx, Color(0xFFFFB74D), selectedMarker == "jump", { selectedMarker = "jump" }) { x, y -> onProfileChange(profile.copy(jumpPositionX = x, jumpPositionY = y)) }
                    DraggableMarker("reload", "REC", profile.reloadPositionX, profile.reloadPositionY, widthPx, heightPx, Color(0xFF4DD0E1), selectedMarker == "reload", { selectedMarker = "reload" }) { x, y -> onProfileChange(profile.copy(reloadPositionX = x, reloadPositionY = y)) }
                    DraggableMarker("interact", "AÇÃO", profile.interactPositionX, profile.interactPositionY, widthPx, heightPx, Color(0xFFFFD54F), selectedMarker == "interact", { selectedMarker = "interact" }) { x, y -> onProfileChange(profile.copy(interactPositionX = x, interactPositionY = y)) }
                    profile.keyTaps.forEach { binding ->
                        DraggableMarker("key:${binding.key}", binding.key, binding.x, binding.y, widthPx, heightPx, Color(0xFF35D07F), selectedMarker == "key:${binding.key}", { selectedMarker = "key:${binding.key}" }) { x, y ->
                            onProfileChange(profile.copy(keyTaps = profile.keyTaps.map { if (it.key == binding.key) it.copy(x = x, y = y) else it }))
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                MarkerLegend("MOV", Color(0xFF1597FF)); MarkerLegend("AIM", Color(0xFFB36BFF)); MarkerLegend("FIRE", Color(0xFFFF685E)); MarkerLegend("PULO", Color(0xFFFFB74D)); MarkerLegend("REC", Color(0xFF4DD0E1)); MarkerLegend("AÇÃO", Color(0xFFFFD54F)); MarkerLegend("TECLA", Color(0xFF35D07F))
            }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("BOTÃO DE ATIRAR • REMADA VERTICAL", color = Color(0xFFFF8A80), fontWeight = FontWeight.Bold)
                    Text("Ajusta quanto a câmera sobe quando você move o mouse para cima enquanto mantém o botão de tiro pressionado. Não move a mira sozinho: amplifica somente o movimento que você fizer.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text("Força da remada: ${"%.1f".format(profile.firePullMultiplier)}×", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Slider(
                        value = profile.firePullMultiplier,
                        onValueChange = { onProfileChange(profile.copy(firePullMultiplier = it)) },
                        valueRange = 0.5f..3.0f,
                        steps = 24
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Mais lenta • 0,5×", color = Muted, style = MaterialTheme.typography.labelSmall)
                        TextButton(onClick = { onProfileChange(profile.copy(firePullMultiplier = 1.0f)) }) { Text("Padrão 1,0×") }
                        Text("Mais rápida • 3,0×", color = Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = newKey, onValueChange = { newKey = it.take(16) }, label = { Text("Nova tecla (ex.: G)") }, singleLine = true, modifier = Modifier.weight(1f))
                Button(onClick = {
                    val key = KeyTapBindings.canonicalKey(newKey)
                    if (key.isNotBlank() && key != "Nenhuma" && key.uppercase() !in KeyTapBindings.RESERVED && profile.keyTaps.none { it.key == key } && profile.keyTaps.size < KeyTapBindings.MAX_BINDINGS) {
                        onProfileChange(profile.copy(keyTaps = profile.keyTaps + KeyTapBinding(key, 0.5f, 0.5f)))
                        selectedMarker = "key:$key"
                        newKey = ""
                    }
                }, enabled = newKey.isNotBlank() && profile.keyTaps.size < KeyTapBindings.MAX_BINDINGS) { Text("Adicionar") }
            }
            if (profile.keyTaps.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Teclas:", color = Muted, style = MaterialTheme.typography.bodySmall)
                    profile.keyTaps.forEach { binding ->
                        AssistChip(onClick = { onProfileChange(profile.copy(keyTaps = profile.keyTaps.filterNot { it.key == binding.key })); selectedMarker = "view" }, label = { Text("${binding.key} ×") })
                    }
                }
            }
            if (saveMessage.isNotBlank()) Text(saveMessage, color = Green, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun rememberCalibrationBitmap(uriString: String?): Bitmap? {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = uriString) {
        value = if (uriString.isNullOrBlank()) null else withContext(Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse(uriString)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                val maxDimension = maxOf(bounds.outWidth, bounds.outHeight).coerceAtLeast(1)
                val sample = Integer.highestOneBit((maxDimension / 2048).coerceAtLeast(1))
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
            }.getOrNull()
        }
    }
    return bitmap
}

@Composable
private fun DraggableMarker(
    id: String,
    label: String,
    x: Float,
    y: Float,
    widthPx: Float,
    heightPx: Float,
    color: Color,
    selected: Boolean,
    onSelect: () -> Unit,
    onMove: (Float, Float) -> Unit
) {
    val currentX by rememberUpdatedState(x)
    val currentY by rememberUpdatedState(y)
    val markerSizePx = with(LocalDensity.current) { 56.dp.roundToPx() }
    Box(
        Modifier.offset { IntOffset((x.coerceIn(0f, 1f) * widthPx).roundToInt() - markerSizePx / 2, (y.coerceIn(0f, 1f) * heightPx).roundToInt() - markerSizePx / 2) }
            .size(56.dp)
            .background(if (selected) color.copy(alpha = 0.38f) else color.copy(alpha = 0.22f), CircleShape)
            .pointerInput(id, widthPx, heightPx) {
                detectDragGestures(onDragStart = { onSelect() }) { change, drag ->
                    change.consume()
                    onMove((currentX + drag.x / widthPx).coerceIn(0f, 1f), (currentY + drag.y / heightPx).coerceIn(0f, 1f))
                }
            }, contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(38.dp).background(color, CircleShape), contentAlignment = Alignment.Center) {
            Text(label.take(5), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun MarkerLegend(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Text(label, color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun BackendCard(title: String, status: String, active: Boolean, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(title, fontWeight = FontWeight.Bold)
                Text(status, color = if (active) Green else Blue, style = MaterialTheme.typography.labelMedium)
            }
            Text(detail, color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
