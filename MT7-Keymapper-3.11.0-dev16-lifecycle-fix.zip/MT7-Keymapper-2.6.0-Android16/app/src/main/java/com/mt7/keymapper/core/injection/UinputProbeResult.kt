package com.mt7.keymapper.core.injection

/** Parsed result emitted by the standalone privileged uinput probe helper. */
data class UinputProbeResult(
    val createdAndDestroyed: Boolean,
    val stage: String?,
    val errno: Int?,
    val detail: String
) {
    companion object {
        fun parse(exitCode: Int, output: String): UinputProbeResult {
            val success = Regex("MT7_UINPUT_PROBE:created-and-destroyed:([^\\s]+):max=(\\d+)x(\\d+):slots=(\\d+)")
                .find(output)
            if (exitCode == 0 && success != null) {
                val (path, width, height, slots) = success.destructured
                return UinputProbeResult(
                    true, null, null,
                    "Dispositivo uinput criado e removido com sucesso em $path ($width×$height, $slots slots). Nenhum toque foi enviado."
                )
            }
            val failure = Regex("MT7_UINPUT_PROBE:failed:([a-z-]+)(?::errno=(\\d+):([^\\r\\n]*))?")
                .find(output)
            val stage = failure?.groupValues?.get(1)
            val errno = failure?.groupValues?.get(2)?.toIntOrNull()
            val reason = failure?.groupValues?.get(3).orEmpty().ifBlank { output.trim().take(240) }
            return UinputProbeResult(
                false, stage, errno,
                if (stage != null) "Falha na etapa '$stage'${errno?.let { " (errno $it)" } ?: ""}: ${reason.ifBlank { "sem detalhes" }}"
                else "O helper não confirmou a criação e remoção do dispositivo. ${reason.ifBlank { "Código de saída $exitCode." }}"
            )
        }
    }
}
