package com.mt7.keymapper.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mt7.keymapper.ui.theme.*

@Composable
fun HomeScreen(
    shizukuOk: Boolean,
    rootOk: Boolean,
    permissionsGranted: Int,
    permissionsTotal: Int,
    mappedApps: Int,
    message: String,
    onPermissions: () -> Unit,
    onApps: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ready = permissionsGranted >= permissionsTotal && (shizukuOk || rootOk)
    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("MT7", color = Neon.Cyan, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Text("KEYMAPPER", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                Text("Seu setup. Seu controle.", color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
            }
            Box(
                Modifier.size(58.dp).clip(RoundedCornerShape(19.dp))
                    .background(Brush.linearGradient(listOf(Neon.Cyan.copy(alpha = .22f), Neon.Magenta.copy(alpha = .22f))))
                    .border(1.dp, Neon.Cyan.copy(alpha = .65f), RoundedCornerShape(19.dp)),
                contentAlignment = Alignment.Center
            ) { Text("M7", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black) }
        }

        NeonCard(accent = if (ready) Neon.Green else Neon.Amber) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("CENTRAL DE CONTROLE", color = Neon.Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Text(if (ready) "Tudo pronto para jogar" else "Falta preparar o MT7", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                }
                StatusChip(if (ready) "● ONLINE" else "● ATENÇÃO", if (ready) Neon.Green else Neon.Amber)
            }
            Text(
                if (ready) "Abra um jogo marcado na aba Apps. A central flutuante MT7 aparecerá sobre o jogo."
                else "Conclua as permissões e conecte Root ou Shizuku para liberar o mapeamento.",
                color = Neon.Muted
            )
            if (message.isNotBlank()) Text(message, color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
        }

        Text("VISÃO GERAL", color = Neon.Cyan, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            MetricCard("SHIZUKU", if (shizukuOk) "CONECTADO" else "INATIVO", shizukuOk, Modifier.weight(1f))
            MetricCard("ROOT", if (rootOk) "CONECTADO" else "INATIVO", rootOk, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            MetricCard("PERMISSÕES", "$permissionsGranted / $permissionsTotal", permissionsGranted >= permissionsTotal, Modifier.weight(1f))
            MetricCard("JOGOS", mappedApps.toString(), mappedApps > 0, Modifier.weight(1f))
        }

        Text("ACESSO RÁPIDO", color = Neon.Cyan, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            QuickAction("🎮", "Meus jogos", "Escolher apps", onApps, Modifier.weight(1f))
            QuickAction("🛡", "Permissões", "Configurar acesso", onPermissions, Modifier.weight(1f))
        }
        NeonCard(accent = Neon.Magenta) {
            Text("CONTROLES NA BOLINHA", color = Color.White, fontWeight = FontWeight.Black)
            Text("Abra um jogo marcado na aba Apps para iniciar o serviço e mostrar a bolinha MT7. Durante o jogo, use a central flutuante para acessar os controles.", color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
        }
        Text("MT7 KEYMAPPER • ANDROID 10+", color = Neon.Muted, style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun MetricCard(label: String, value: String, ok: Boolean, modifier: Modifier = Modifier) {
    val accent = if (ok) Neon.Green else Neon.Magenta
    Column(
        modifier.clip(RoundedCornerShape(17.dp))
            .background(Brush.verticalGradient(listOf(Neon.Panel2, Neon.Panel)))
            .border(1.dp, accent.copy(alpha = .42f), RoundedCornerShape(17.dp))
            .padding(13.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(label, color = Neon.Muted, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        Text(value, color = accent, fontSize = 15.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun QuickAction(icon: String, title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(17.dp))
            .background(Neon.Panel.copy(alpha = .95f))
            .border(1.dp, Neon.Cyan.copy(alpha = .35f), RoundedCornerShape(17.dp))
            .padding(14.dp)
    ) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.height(8.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Neon.Muted, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        NeonOutlineButton("ABRIR", onClick = onClick)
    }
}
