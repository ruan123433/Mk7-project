package com.mt7.keymapper.core.injection

import com.mt7.keymapper.core.activation.PrivilegedCommandRunner
import com.mt7.keymapper.core.activation.RootBackend
import com.mt7.keymapper.core.activation.ShizukuBackend

/**
 * Read-only preflight for a future uinput transport. It never opens the node
 * for writing, changes permissions, loads kernel modules, or injects events.
 */
class UinputCapabilityInspector(
    private val root: RootBackend = RootBackend(),
    private val shizuku: ShizukuBackend = ShizukuBackend()
) {
    enum class Backend { ROOT, SHIZUKU }
    enum class NodeAccess { WRITABLE, PRESENT_NO_ACCESS, MISSING, COMMAND_FAILED }

    data class Report(
        val backend: Backend?,
        val nodePath: String?,
        val access: NodeAccess,
        val moduleLoaded: Boolean,
        val selinuxMode: String?,
        val detail: String
    ) {
        val readyForWriteProbe: Boolean
            get() = backend != null && nodePath != null && access == NodeAccess.WRITABLE
    }

    /** Root is preferred; Shizuku is used only when Root cannot run the probe. */
    fun inspect(): Report {
        if (root.inspectNow().available) {
            val result = PrivilegedCommandRunner.root(PROBE_COMMAND, 3_000)
            if (result.success) return parse(Backend.ROOT, result.output)
        }
        if (shizuku.inspectNow().available) {
            val result = PrivilegedCommandRunner.shizuku(PROBE_COMMAND, 3_000)
            if (result.success) return parse(Backend.SHIZUKU, result.output)
        }
        return Report(
            backend = null,
            nodePath = null,
            access = NodeAccess.COMMAND_FAILED,
            moduleLoaded = false,
            selinuxMode = null,
            detail = "Não foi possível executar o diagnóstico por Root ou Shizuku."
        )
    }

    companion object {
        /** Fixed shell script; no user-controlled value is interpolated. */
        internal val PROBE_COMMAND = """
            for p in /dev/uinput /dev/input/uinput; do
              if [ -c "${'$'}p" ]; then
                if [ -r "${'$'}p" ] && [ -w "${'$'}p" ]; then
                  echo "MT7_UINPUT_WRITABLE:${'$'}p"
                else
                  echo "MT7_UINPUT_NO_ACCESS:${'$'}p"
                fi
              fi
            done
            if [ -e /sys/module/uinput ]; then echo MT7_UINPUT_MODULE:loaded; else echo MT7_UINPUT_MODULE:not_loaded; fi
            if command -v getenforce >/dev/null 2>&1; then echo "MT7_SELINUX:${'$'}(getenforce 2>/dev/null)"; fi
        """.trimIndent()

        /** Pure parser exposed for deterministic unit tests. */
        fun parse(backend: Backend, output: String): Report {
            val writable = Regex("MT7_UINPUT_WRITABLE:(/dev/(?:input/)?uinput)")
                .find(output)?.groupValues?.get(1)
            val presentNoAccess = Regex("MT7_UINPUT_NO_ACCESS:(/dev/(?:input/)?uinput)")
                .find(output)?.groupValues?.get(1)
            val moduleLoaded = "MT7_UINPUT_MODULE:loaded" in output
            val selinux = Regex("MT7_SELINUX:([^\\r\\n]+)").find(output)?.groupValues?.get(1)?.trim()

            return when {
                writable != null -> Report(
                    backend, writable, NodeAccess.WRITABLE, moduleLoaded, selinux,
                    "Nó $writable existe e as permissões reportadas permitem leitura/escrita via $backend. Isso ainda não comprova criação de um touchscreen virtual."
                )
                presentNoAccess != null -> Report(
                    backend, presentNoAccess, NodeAccess.PRESENT_NO_ACCESS, moduleLoaded, selinux,
                    "Nó $presentNoAccess existe, mas o backend $backend não tem leitura/escrita."
                )
                else -> Report(
                    backend, null, NodeAccess.MISSING, moduleLoaded, selinux,
                    "Nenhum nó de caractere uinput foi encontrado pelo backend $backend."
                )
            }
        }
    }
}
