package com.mt7.keymapper.core.mapping

import com.mt7.keymapper.core.input.OtgEventMapper
import java.util.Locale

/**
 * One SS KeyMouse-style free key: while [key] is held, a virtual finger stays
 * pressed at ([x], [y]) given as fractions of the screen width and height.
 */
data class KeyTapBinding(val key: String, val x: Float, val y: Float) {
    init {
        require(key.isNotBlank() && key.length <= 16)
        require(x.isFinite() && x in 0f..1f && y.isFinite() && y in 0f..1f)
    }
}

object KeyTapBindings {
    /** Free keys use pointer ids 6.. so they never collide with joystick/look/fire/jump/reload/interact. */
    const val MAX_BINDINGS = 20

    /** Keys owned by the joystick and the fire contact; they cannot become free keys. */
    val RESERVED = setOf("W", "A", "S", "D", "MOUSE ESQUERDO")

    private val ALIASES = mapOf(
        "ESPACO" to "ESPAÇO", "SPACE" to "ESPAÇO", "SHIFT" to "SHIFT ESQ",
        "CTRL" to "CTRL ESQ", "ALT" to "ALT ESQ", "CAPSLOCK" to "CAPS",
        "MOUSE4" to "Mouse lateral 1", "MOUSE5" to "Mouse lateral 2",
        "MOUSE DIREITO" to "Mouse direito", "MOUSE DO MEIO" to "Mouse do meio",
        "MOUSE LATERAL 1" to "Mouse lateral 1", "MOUSE LATERAL 2" to "Mouse lateral 2",
        "NENHUMA" to "Nenhuma"
    )

    /** Normalizes typed text ("g", "espaco", "mouse4") to the label produced by [OtgEventMapper]. */
    fun canonicalKey(raw: String): String {
        val up = raw.trim().uppercase(Locale.ROOT)
        ALIASES[up]?.let { return it }
        return OtgEventMapper.KNOWN_LABELS.firstOrNull { it.uppercase(Locale.ROOT) == up } ?: up
    }

    /**
     * Parses "G=55,80; 1=40,10" (key = percent of width, percent of height).
     * Entries may be split by ';' or new lines. Invalid, reserved and duplicate keys are skipped.
     */
    fun parse(text: String): List<KeyTapBinding> {
        val result = mutableListOf<KeyTapBinding>()
        text.split(';', '\n').forEach { entry ->
            if (result.size >= MAX_BINDINGS) return@forEach
            val parts = entry.split('=')
            if (parts.size != 2) return@forEach
            val key = canonicalKey(parts[0])
            if (key.isBlank() || key.length > 16 || key == "Nenhuma") return@forEach
            if (key.uppercase(Locale.ROOT) in RESERVED) return@forEach
            if (result.any { it.key == key }) return@forEach
            val coords = parts[1].split(',').map { it.trim().toFloatOrNull() }
            if (coords.size != 2) return@forEach
            val px = coords[0] ?: return@forEach
            val py = coords[1] ?: return@forEach
            if (!px.isFinite() || !py.isFinite() || px !in 0f..100f || py !in 0f..100f) return@forEach
            result += KeyTapBinding(key, px / 100f, py / 100f)
        }
        return result
    }

    fun format(bindings: List<KeyTapBinding>): String =
        bindings.joinToString("; ") { "${it.key}=${pct(it.x)},${pct(it.y)}" }

    private fun pct(v: Float): String {
        val scaled = Math.round(v * 1000f) / 10f
        return if (scaled == scaled.toInt().toFloat()) scaled.toInt().toString() else scaled.toString()
    }
}
