package com.mt7.keymapper.core.mapping

import com.mt7.keymapper.core.input.OtgEventMapper
import java.util.Locale

/** Text/editor helpers for profile-persisted physical key chords. */
object KeyComboBindings {
    const val MAX_BINDINGS = 16

    fun canonical(raw: String): String {
        val value = raw.trim().uppercase(Locale.ROOT)
        val aliases = mapOf("CTRL" to "CTRL ESQ", "CONTROL" to "CTRL ESQ", "SHIFT" to "SHIFT ESQ", "ALT" to "ALT ESQ", "SPACE" to "ESPAÇO", "ESPACO" to "ESPAÇO", "MOUSE4" to "Mouse lateral 1", "MOUSE5" to "Mouse lateral 2")
        return aliases[value] ?: OtgEventMapper.KNOWN_LABELS.firstOrNull { it.equals(value, ignoreCase = true) } ?: value
    }

    /** Format: CTRL ESQ+1=ESPAÇO; SHIFT ESQ+Q=R */
    fun parse(text: String, allowedTargets: Set<String> = setOf("ESPAÇO", "R", "F")): List<KeyComboBinding> {
        val result = mutableListOf<KeyComboBinding>()
        text.split(';', '\n').forEach { raw ->
            if (result.size >= MAX_BINDINGS) return@forEach
            val sides = raw.trim().split('=')
            if (sides.size != 2) return@forEach
            val keys = sides[0].split('+').map(::canonical).toSet()
            val target = canonical(sides[1])
            if (keys.size !in 2..4 || keys.any { it !in OtgEventMapper.KNOWN_LABELS || it.startsWith("Mouse ", true) } || target !in allowedTargets || target !in OtgEventMapper.KNOWN_LABELS) return@forEach
            if (target in keys || result.any { it.signature == keys.sorted().joinToString("+") } || result.any { it.targetKey == target }) return@forEach
            runCatching { KeyComboBinding(keys, target) }.getOrNull()?.let(result::add)
        }
        return result
    }

    fun format(bindings: List<KeyComboBinding>): String =
        bindings.joinToString("; ") { "${it.keys.sorted().joinToString("+") }=${it.targetKey}" }
}
