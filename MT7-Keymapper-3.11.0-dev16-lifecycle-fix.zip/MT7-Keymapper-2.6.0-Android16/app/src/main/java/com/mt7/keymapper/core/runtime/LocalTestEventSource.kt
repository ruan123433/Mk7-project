package com.mt7.keymapper.core.runtime

import com.mt7.keymapper.core.mapping.PointerDelta

/**
 * Explicit in-app event source for diagnostics.
 * Values are supplied by the user through the MT7 test screen.
 * This is not an Android input-capture or injection API.
 */
class LocalTestEventSource {
    fun createDelta(x: Float, y: Float): PointerDelta {
        require(x.isFinite() && y.isFinite()) { "Test values must be finite" }
        return PointerDelta(x, y)
    }
}
