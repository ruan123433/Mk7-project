package com.mt7.keymapper.core.runtime

import java.util.concurrent.atomic.AtomicLong

/** Health state for the active input-injection path. It reports faults; it never
 * silently switches privileges or retries an injection that may duplicate input.
 */
enum class BackendHealth { HEALTHY, DEGRADED, FAILED }

data class BackendHealthSnapshot(
    val health: BackendHealth,
    val consecutiveFailures: Long,
    val totalFailures: Long,
    val lastFailure: String?
)

class BackendHealthDiagnostics(
    private val failureThreshold: Long = 3
) {
    init { require(failureThreshold > 0) }

    private val total = AtomicLong(0)
    private val consecutive = AtomicLong(0)
    @Volatile private var lastFailure: String? = null
    @Volatile private var health: BackendHealth = BackendHealth.HEALTHY

    @Synchronized
    fun recordFailure(reason: String): BackendHealthSnapshot {
        val cleanReason = reason.trim().ifBlank { "Falha sem detalhes" }.take(240)
        lastFailure = cleanReason
        total.incrementAndGet()
        val count = consecutive.incrementAndGet()
        health = if (count >= failureThreshold) BackendHealth.FAILED else BackendHealth.DEGRADED
        return snapshot()
    }

    /** A confirmed successful delivery clears the consecutive-failure streak. */
    @Synchronized
    fun recordSuccess(): BackendHealthSnapshot {
        consecutive.set(0)
        health = BackendHealth.HEALTHY
        return snapshot()
    }

    @Synchronized
    fun snapshot() = BackendHealthSnapshot(health, consecutive.get(), total.get(), lastFailure)

    @Synchronized
    fun reset() {
        total.set(0)
        consecutive.set(0)
        lastFailure = null
        health = BackendHealth.HEALTHY
    }
}
