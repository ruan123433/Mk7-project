package com.mt7.keymapper.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DiagnosticNavy = Color(0xFF07111F)
private val DiagnosticPanel = Color(0xFF0D1B2B)
private val DiagnosticBlue = Color(0xFF1597FF)
private val DiagnosticMuted = Color(0xFF9CB0C7)
private val DiagnosticGreen = Color(0xFF35D07F)
private val DiagnosticAmber = Color(0xFFFFC15A)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackendDiagnosticsScreen(
    shizukuAvailable: Boolean,
    shizukuDetail: String,
    rootAvailable: Boolean,
    rootDetail: String,
    profileCount: Int,
    selectedProfileName: String,
    onBack: () -> Unit
) {
    Scaffold(
        containerColor = DiagnosticNavy,
        topBar = {
            TopAppBar(
                title = { Text("Diagnóstico MT7", fontWeight = FontWeight.Bold) },
                navigationIcon = { TextButton(onClick = onBack) { Text("VOLTAR", color = DiagnosticBlue) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DiagnosticNavy, titleContentColor = Color.White)
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("SAÚDE DOS BACKENDS", color = DiagnosticBlue, fontWeight = FontWeight.Black, fontSize = 13.sp)
            DiagnosticStatusCard("Shizuku", shizukuAvailable, shizukuDetail)
            DiagnosticStatusCard("Root", rootAvailable, rootDetail)

            Text("PIPELINE DE ENTRADA", color = DiagnosticBlue, fontWeight = FontWeight.Black, fontSize = 13.sp)
            DiagnosticInfoCard("Sessão OTG", "INATIVA", "Nenhuma sessão de captura/injeção está vinculada a esta tela.")
            DiagnosticInfoCard("Eventos por segundo", "—", "Indisponível sem sessão OTG ativa.")
            DiagnosticInfoCard("Eventos recebidos / ações entregues", "— / —", "O painel não recebe ainda o snapshot de uma sessão ativa.")
            DiagnosticInfoCard("Fila de entrada", "—", "A fila é criada somente durante uma sessão OTG.")
            DiagnosticInfoCard("Tempo de processamento", "—", "Não representa latência física USB até a tela.")

            Text("PERFIL ATUAL", color = DiagnosticBlue, fontWeight = FontWeight.Black, fontSize = 13.sp)
            DiagnosticInfoCard("Perfil selecionado", selectedProfileName, "$profileCount perfil(is) carregado(s).")

            Surface(color = DiagnosticPanel, shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Como interpretar", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(
                        "Verde indica que o serviço foi detectado, não que a injeção em jogo foi validada. A validação exige iniciar uma sessão OTG e testar o dispositivo físico.",
                        color = DiagnosticMuted,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun DiagnosticStatusCard(title: String, available: Boolean, detail: String) {
    Surface(color = DiagnosticPanel, shape = RoundedCornerShape(14.dp), tonalElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(if (available) "DISPONÍVEL" else "INDISPONÍVEL",
                    color = if (available) DiagnosticGreen else DiagnosticAmber,
                    fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
            Text(detail.ifBlank { "Sem detalhes fornecidos pelo verificador." }, color = DiagnosticMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun DiagnosticInfoCard(title: String, value: String, detail: String) {
    Surface(color = DiagnosticPanel, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = DiagnosticMuted, style = MaterialTheme.typography.labelMedium)
            Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = DiagnosticMuted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
