package com.mt7.keymapper.ui.permissions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mt7.keymapper.core.permissions.PermissionItem
import com.mt7.keymapper.core.permissions.PermissionState
import com.mt7.keymapper.ui.theme.*

@Composable
fun PermissionScreen(
    items: List<PermissionItem>,
    onOpen: (PermissionItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val granted = items.count { it.granted }
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
          Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Permissões", color = Neon.Cyan, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            Text("Toque em cada item para liberar. O status atualiza quando você volta ao app.", color = Neon.Muted)
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { if (items.isEmpty()) 0f else granted.toFloat() / items.size },
                color = Neon.Green,
                trackColor = Neon.Panel2,
                modifier = Modifier.fillMaxWidth().height(8.dp)
            )
            Text("$granted de ${items.size} liberadas", color = Neon.Muted, style = MaterialTheme.typography.labelMedium)
          }
        }
        items(items, key = { it.id }) { item ->
            val chipColor = when {
                item.granted -> Neon.Green
                item.state == PermissionState.REQUIRED -> Neon.Magenta
                else -> Neon.Amber
            }
            NeonCard(accent = chipColor) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(item.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    StatusChip(
                        when {
                            item.granted -> "ATIVADA"
                            item.state == PermissionState.REQUIRED -> "NECESSÁRIA"
                            else -> "OPCIONAL"
                        },
                        chipColor
                    )
                }
                Text(item.description, color = Neon.Muted)
                if (item.action != null && !item.granted) {
                    NeonButton("Liberar agora") { onOpen(item) }
                }
            }
        }
    }
}
