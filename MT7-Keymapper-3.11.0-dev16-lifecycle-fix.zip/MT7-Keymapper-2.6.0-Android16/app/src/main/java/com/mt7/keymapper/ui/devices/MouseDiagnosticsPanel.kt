package com.mt7.keymapper.ui.devices

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.isPrimaryPressed
import androidx.compose.ui.input.pointer.isSecondaryPressed
import androidx.compose.ui.input.pointer.isTertiaryPressed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mt7.keymapper.core.devices.InputDeviceInspector
import com.mt7.keymapper.service.InputCaptureMonitor
import androidx.compose.runtime.collectAsState
import kotlin.math.roundToInt

/** In-app mouse test surface. It only receives pointer events delivered to this app. */
@Composable
fun MouseDiagnosticsPanel(modifier: Modifier = Modifier) {
    var devices by remember { mutableStateOf(InputDeviceInspector.scan()) }
    var sensitivityX by remember { mutableStateOf(1f) }
    var sensitivityY by remember { mutableStateOf(1f) }
    var rawX by remember { mutableStateOf(0f) }
    var rawY by remember { mutableStateOf(0f) }
    var outputX by remember { mutableStateOf(0f) }
    var outputY by remember { mutableStateOf(0f) }
    var wheel by remember { mutableStateOf(0f) }
    var moves by remember { mutableIntStateOf(0) }
    var presses by remember { mutableIntStateOf(0) }
    var buttonState by remember { mutableStateOf("Nenhum") }
    val capture by InputCaptureMonitor.state.collectAsState()

    val mice = devices.filter { "Mouse" in it.sources }

    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(modifier = Modifier.weight(1f)) {
                Text("MT7 KEYMOUSE", color = Color(0xFF1597FF), style = MaterialTheme.typography.titleLarge)
                Text("Laboratório de mouse", color = Color.White, style = MaterialTheme.typography.bodyMedium)
            }
            Button(onClick = { devices = InputDeviceInspector.scan() }) { Text("Atualizar") }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B))) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Captura global OTG", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(if (capture.mappingActive) "Mapeamento ativo" else "Mapeamento pausado", color = if (capture.mappingActive) Color(0xFF36C98F) else Color(0xFFFFC266))
                Text("Teclas: ${capture.keyboardEvents}  •  Movimentos: ${capture.mouseMoves}", color = Color(0xFFCAD7E5))
                Text("Botões: ${capture.mouseButtons}  •  Scroll: ${capture.wheelEvents}", color = Color(0xFFCAD7E5))
                Text("Último evento: ${capture.lastInput}", color = Color.White)
                Text("Dispositivo: ${capture.lastDevice}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
                Text("Delta recente: X ${capture.lastDeltaX.toInt()} • Y ${capture.lastDeltaY.toInt()}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
                Button(onClick = { InputCaptureMonitor.reset() }) { Text("Zerar captura") }
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B))) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(if (mice.isEmpty()) "Mouse não identificado" else "${mice.size} mouse(s) identificado(s)", color = Color.White)
                mice.forEach { Text("${it.name} • ID ${it.id} • VID ${it.vendorId} / PID ${it.productId}", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall) }
                if (mice.isEmpty()) Text("Conecte o mouse e toque em Atualizar. O Android pode ocultar alguns dispositivos de aplicativos comuns.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
            }
        }

        Text("Área de teste: mova o mouse aqui e clique nos botões", color = Color.White, style = MaterialTheme.typography.titleMedium)
        Column(
            modifier = Modifier.fillMaxWidth().height(150.dp)
                .background(Color(0xFF10243A), RoundedCornerShape(14.dp))
                .border(1.dp, Color(0xFF1597FF), RoundedCornerShape(14.dp))
                .pointerInput(sensitivityX, sensitivityY) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            val mouseChanges = event.changes.filter { it.type == PointerType.Mouse }
                            if (mouseChanges.isNotEmpty()) {
                                val change = mouseChanges.first()
                                when (event.type) {
                                    PointerEventType.Move -> {
                                        val delta = change.positionChange()
                                        rawX += delta.x
                                        rawY += delta.y
                                        outputX += delta.x * sensitivityX
                                        outputY += delta.y * sensitivityY
                                        moves++
                                    }
                                    PointerEventType.Press -> {
                                        presses++
                                        buttonState = when {
                                            event.buttons.isPrimaryPressed -> "Esquerdo pressionado"
                                            event.buttons.isSecondaryPressed -> "Direito pressionado"
                                            event.buttons.isTertiaryPressed -> "Botão do meio pressionado"
                                            else -> "Botão pressionado"
                                        }
                                    }
                                    PointerEventType.Release -> buttonState = "Solto"
                                    PointerEventType.Scroll -> wheel += change.scrollDelta.y
                                }
                            }
                        }
                    }
                }
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text("MOUSE ATIVO NA ÁREA", color = Color(0xFF1597FF), style = MaterialTheme.typography.labelLarge)
            Text("Movimentos: $moves   •   Cliques: $presses", color = Color.White)
            Text("Estado: $buttonState   •   Scroll: ${wheel.roundToInt()}", color = Color(0xFFCAD7E5))
            Text("Se os números não mudarem, o Android não entregou eventos de mouse a esta área.", color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall)
        }

        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2B))) {
            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sensibilidade linear de teste", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("X: ${"%.2f".format(sensitivityX)}x", color = Color(0xFFCAD7E5))
                Slider(value = sensitivityX, onValueChange = { sensitivityX = it }, valueRange = 0.1f..5f)
                Text("Y: ${"%.2f".format(sensitivityY)}x", color = Color(0xFFCAD7E5))
                Slider(value = sensitivityY, onValueChange = { sensitivityY = it }, valueRange = 0.1f..5f)
                Text("Delta bruto: X ${rawX.roundToInt()} • Y ${rawY.roundToInt()}", color = Color(0xFF9CB0C7))
                Text("Delta transformado: X ${outputX.roundToInt()} • Y ${outputY.roundToInt()}", color = Color(0xFF1597FF))
                Button(onClick = {
                    rawX = 0f; rawY = 0f; outputX = 0f; outputY = 0f
                    wheel = 0f; moves = 0; presses = 0; buttonState = "Nenhum"
                }) { Text("Zerar teste") }
            }
        }

        Text(
            "A captura global depende do Serviço de acessibilidade MT7 estar ativado e do mapeamento estar ligado. O contador acima só aumenta quando o Android entrega eventos ao serviço.",
            color = Color(0xFF9CB0C7), style = MaterialTheme.typography.bodySmall
        )
    }
}
