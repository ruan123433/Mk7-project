package com.mt7.keymapper.core.runtime

import com.mt7.keymapper.core.activation.BackendKind
import com.mt7.keymapper.core.activation.BackendStatus
import com.mt7.keymapper.core.mapping.PointerDelta
import com.mt7.keymapper.core.mapping.PointerTransform
import com.mt7.keymapper.core.mapping.VisionSettings
import com.mt7.keymapper.core.input.OtgEventMapper
import com.mt7.keymapper.core.input.OtgInputEventReader
import com.mt7.keymapper.core.mapping.OtgTouchMappingController

enum class RuntimeState { STOPPED, WAITING_AUTHORIZATION, READY, PAUSED }

data class RuntimeSnapshot(
    val state: RuntimeState,
    val backend: BackendKind?,
    val message: String
)

/**
 * Local mapping lifecycle and deterministic event processor.
 *
 * The caller must supply pointer deltas explicitly. This class does not
 * capture device input, inject events, or communicate with other apps.
 */
class MappingRuntime(
    private val transform: PointerTransform = PointerTransform()
) {
    private var selectedBackend: BackendKind? = null
    private var authorized = false
    private var running = false
    private var paused = false
    val diagnostics = InputEngineDiagnostics()
    val backendHealth = BackendHealthDiagnostics()

    @Synchronized
    fun selectBackend(status: BackendStatus): RuntimeSnapshot {
        selectedBackend = status.kind
        authorized = status.available
        return snapshot()
    }

    @Synchronized
    fun start(): RuntimeSnapshot {
        running = true
        paused = false
        return snapshot()
    }

    @Synchronized
    fun pause(): RuntimeSnapshot {
        if (running) paused = true
        return snapshot()
    }

    @Synchronized
    fun resume(): RuntimeSnapshot {
        if (running) paused = false
        return snapshot()
    }

    @Synchronized
    fun stop(): RuntimeSnapshot {
        running = false
        paused = false
        return snapshot()
    }


    /** Maps one captured OTG event and forwards its semantic action to the active uinput controller. */
    @Synchronized
    fun processAndInject(
        event: OtgInputEventReader.InputEvent,
        mapper: OtgEventMapper,
        controller: OtgTouchMappingController
    ): Boolean {
        val startedAt = System.nanoTime()
        if (snapshot().state != RuntimeState.READY) {
            diagnostics.record(startedAt, producedAction = false, delivery = null)
            return false
        }
        val action = mapper.map(event)
        if (action == null) {
            diagnostics.record(startedAt, producedAction = false, delivery = null)
            return true
        }
        val delivered = controller.accept(action)
        diagnostics.record(startedAt, producedAction = true, delivery = delivered)
        if (delivered) {
            backendHealth.recordSuccess()
        } else {
            backendHealth.recordFailure("O controlador uinput recusou uma ação de entrada.")
            controller.releaseAll()
            paused = true
        }
        return delivered
    }

    /** Releases all virtual contacts before pausing or stopping the mapping runtime. */
    @Synchronized
    fun pauseAndRelease(controller: OtgTouchMappingController): RuntimeSnapshot {
        controller.releaseAll()
        return pause()
    }

    @Synchronized
    fun stopAndRelease(controller: OtgTouchMappingController): RuntimeSnapshot {
        controller.releaseAll()
        return stop()
    }

    @Synchronized
    fun snapshot(): RuntimeSnapshot {
        val state = when {
            !running -> RuntimeState.STOPPED
            paused -> RuntimeState.PAUSED
            !authorized -> RuntimeState.WAITING_AUTHORIZATION
            else -> RuntimeState.READY
        }
        val message = when (state) {
            RuntimeState.STOPPED -> "Mapeamento parado."
            RuntimeState.WAITING_AUTHORIZATION -> "Aguardando autorização do backend selecionado."
            RuntimeState.READY -> "Camada local pronta; aguardando eventos fornecidos pelo próprio app."
            RuntimeState.PAUSED -> "Mapeamento suspenso."
        }
        return RuntimeSnapshot(state, selectedBackend, message)
    }

    /**
     * Processes a supplied relative delta only while the runtime is ready.
     * Returns null while stopped, paused, or waiting for authorization.
     */
    @Synchronized
    fun process(delta: PointerDelta, settings: VisionSettings): PointerDelta? {
        if (snapshot().state != RuntimeState.READY) return null
        return transform.apply(delta, settings)
    }

    /**
     * Routes a captured OTG event through the mapping runtime's authorization
     * and lifecycle gate, then returns its semantic action. No Android input
     * is synthesized and no touch is injected by this method.
     */
    @Synchronized
    fun processInput(
        event: OtgInputEventReader.InputEvent,
        mapper: OtgEventMapper
    ): OtgEventMapper.Action? {
        if (snapshot().state != RuntimeState.READY) return null
        return mapper.map(event)
    }
}
