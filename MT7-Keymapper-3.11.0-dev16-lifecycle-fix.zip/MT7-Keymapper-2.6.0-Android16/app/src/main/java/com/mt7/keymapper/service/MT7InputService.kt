package com.mt7.keymapper.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.mt7.keymapper.core.mapping.ProfileStore
import com.mt7.keymapper.core.input.OtgInputEventReader
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import com.mt7.keymapper.core.runtime.PrivilegedOtgMappingSession

/** Foreground owner for the floating UI and the privileged OTG mapping pipeline. */
class MT7InputService : Service() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var floatingBall: FloatingBallController? = null
    private var mappingSession: PrivilegedOtgMappingSession? = null
    private var reconnectExecutor: ScheduledExecutorService? = null
    private val reconnecting = AtomicBoolean(false)
    @Volatile private var lastProfileId: String? = null
    @Volatile private var activeMousePath: String? = null
    @Volatile private var activeKeyboardPath: String? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Aguardando configuração OTG"))
        floatingBall = FloatingBallController(
            context = this,
            onStop = { stopSelf() },
            onMappingEnabledChanged = { enabled ->
                if (!enabled) mappingSession?.pause() else mappingSession?.resume()
            }
        ).also { it.show() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_MAPPING -> startMapping(intent)
            ACTION_AUTO_START -> autoStartMapping(intent.getStringExtra(EXTRA_TARGET_PACKAGE))
            ACTION_PAUSE -> {
                mappingSession?.pause()
                floatingBall?.setPaused(true)
                updateNotification("Mapeamento pausado")
            }
            ACTION_RESUME -> {
                floatingBall?.setPaused(false)
                mappingSession?.resume()
                updateNotification(if (mappingSession != null) "Mapeamento OTG ativo" else "Overlay ativo; OTG não configurado")
            }
            ACTION_SET_POINTER_SUSPENSION -> {
                val enabled = intent.getBooleanExtra(EXTRA_POINTER_SUSPENSION_ENABLED, true)
                getSharedPreferences("mt7_vision", MODE_PRIVATE).edit()
                    .putBoolean("suspend_pointer_while_aiming", enabled).apply()
                val applied = mappingSession?.setPointerSuspensionEnabled(enabled) ?: true
                updateNotification(if (applied) "Suspensão da seta ${if (enabled) "ativada" else "desativada"}" else "Não foi possível alterar a suspensão da seta")
            }
            ACTION_REFRESH_SOFTWARE_CURSOR -> floatingBall?.refreshGameCursor()
            ACTION_RELOAD_PROFILE -> {
                val requested = intent.getStringExtra(EXTRA_PROFILE_ID) ?: lastProfileId
                val mouse = activeMousePath
                if (mouse != null && lastProfileId != null) {
                    lastProfileId = requested
                    startMappingWithPaths(mouse, activeKeyboardPath, requested)
                } else {
                    updateNotification("Perfil salvo. Inicie o OTG para aplicar o novo mapeamento.")
                }
            }
            ACTION_STOP -> { lastProfileId = null; stopReconnectSupervisor(); stopSelf() }
        }
        return START_STICKY
    }


    /** Starts the floating control bubble and discovers the USB mouse/keyboard automatically. */
    private fun autoStartMapping(targetPackage: String?) {
        updateNotification("Central flutuante ativa${targetPackage?.let { " • $it" } ?: ""}; procurando mouse e teclado OTG…")
        reconnectExecutor?.shutdownNow()
        reconnecting.set(false)
        reconnectExecutor = Executors.newSingleThreadScheduledExecutor { task ->
            Thread(task, "MT7-USB-AutoStart").apply { isDaemon = true }
        }.also { executor ->
            executor.execute {
                val devices = runCatching { OtgInputEventReader().use { it.listDevices() } }.getOrDefault(emptyList())
                val mouse = devices.firstOrNull { it.hasMouse }
                if (mouse == null) {
                    updateNotification("Bolinha MT7 ativa • conecte o mouse OTG e tente abrir o jogo novamente")
                    return@execute
                }
                val keyboard = when {
                    mouse.hasKeyboard -> mouse.path
                    else -> devices.firstOrNull { it.hasKeyboard && it.path != mouse.path }?.path
                }
                if (keyboard == null) {
                    updateNotification("Bolinha MT7 ativa • teclado OTG não detectado; verifique o hub USB")
                    return@execute
                }
                val profile = ProfileStore(this).loadAll().firstOrNull()
                if (profile == null) {
                    updateNotification("Bolinha MT7 ativa • crie um perfil em Editar Keymap")
                    return@execute
                }
                startMappingWithPaths(mouse.path, keyboard, profile.id)
            }
        }
    }

    private fun startMapping(intent: Intent) {
        val mousePath = intent.getStringExtra(EXTRA_MOUSE_DEVICE_PATH)?.trim().orEmpty()
        val keyboardPath = intent.getStringExtra(EXTRA_KEYBOARD_DEVICE_PATH)?.trim()?.takeIf { it.isNotEmpty() }
        val profileId = intent.getStringExtra(EXTRA_PROFILE_ID)
        if (!mousePath.matches(Regex("""/dev/input/event\d+"""))) {
            updateNotification("Erro: selecione um dispositivo de mouse OTG válido")
            return
        }
        stopReconnectSupervisor()
        lastProfileId = profileId
        activeMousePath = mousePath
        activeKeyboardPath = keyboardPath
        startMappingWithPaths(mousePath, keyboardPath, profileId)
    }

    @Synchronized
    private fun startMappingWithPaths(mousePath: String, keyboardPath: String?, profileId: String?) {
        activeMousePath = mousePath
        activeKeyboardPath = keyboardPath
        mappingSession?.close()
        mappingSession = null
        val (width, height) = displaySize()
        if (width <= 1 || height <= 1) {
            updateNotification("Erro: não foi possível detectar a resolução da tela")
            return
        }
        val profiles = ProfileStore(this).loadAll()
        val profile = profiles.firstOrNull { it.id == profileId } ?: profiles.firstOrNull()
        if (profile == null) {
            updateNotification("Erro: nenhum perfil de mapeamento disponível")
            return
        }
        lastProfileId = profile.id
        val visionPrefs = getSharedPreferences("mt7_vision", MODE_PRIVATE)
        val suspendPointer = if (visionPrefs.contains("suspend_pointer_while_aiming")) {
            visionPrefs.getBoolean("suspend_pointer_while_aiming", profile.suspendPointerWhileAiming)
        } else {
            profile.suspendPointerWhileAiming.also {
                visionPrefs.edit().putBoolean("suspend_pointer_while_aiming", it).apply()
            }
        }
        val optimizationPrefs = getSharedPreferences("mt7_optimization", MODE_PRIVATE)
        val runtimeProfile = profile.copy(
            suspendPointerWhileAiming = suspendPointer,
            optimizationFilter = optimizationPrefs.getFloat("filter", profile.optimizationFilter).coerceIn(0f, 0.8f),
            optimizationThreshold = optimizationPrefs.getFloat("threshold", profile.optimizationThreshold).coerceIn(0f, 4f),
            optimizationBurst = optimizationPrefs.getFloat("burst", profile.optimizationBurst).coerceIn(0f, 0.5f),
            optimizationBrake = optimizationPrefs.getFloat("brake", profile.optimizationBrake).coerceIn(0f, 0.8f)
        )
        val result = runCatching {
            PrivilegedOtgMappingSession.start(
                context = this,
                devicePath = mousePath,
                keyboardDevicePath = keyboardPath,
                displayWidth = width,
                displayHeight = height,
                profile = runtimeProfile,
                onPointerSuspensionChanged = { /* status is exposed by the runtime diagnostics */ },
                onSoftwareCursorVisibilityChanged = { visible ->
                    mainHandler.post {
                        if (visible) floatingBall?.showGameCursor() else floatingBall?.hideGameCursor()
                    }
                },
                onSoftwareCursorMoved = { dx, dy ->
                    mainHandler.post { floatingBall?.moveGameCursor(dx, dy) }
                },
                onSoftwareCursorClick = { button, pressed -> dispatchSoftwareCursorClick(button, pressed) },
                onDeviceDisconnected = { missingPath ->
                    synchronized(this) { mappingSession = null }
                    updateNotification("USB desconectado ($missingPath) • liberando controles e aguardando reconexão")
                    startReconnectSupervisor()
                }
            )
        }.getOrElse {
            updateNotification("Falha ao iniciar OTG: ${it.message ?: "erro inesperado"}")
            return
        }
        mappingSession = result.session
        updateNotification(if (result.session != null) "MT7 ativo • ${result.detail}" else "Falha OTG • ${result.detail}")
    }

    /** Waits for the hub to return, rediscovers event nodes (which may be renumbered), and restarts capture. */
    @Synchronized
    private fun startReconnectSupervisor() {
        if (isFinishingOrDestroyed() || !reconnecting.compareAndSet(false, true)) return
        reconnectExecutor?.shutdownNow()
        reconnectExecutor = Executors.newSingleThreadScheduledExecutor { task ->
            Thread(task, "MT7-USB-Reconnect").apply { isDaemon = true }
        }.also { executor ->
            executor.scheduleWithFixedDelay({
                if (mappingSession != null || isFinishingOrDestroyed()) {
                    stopReconnectSupervisor()
                    return@scheduleWithFixedDelay
                }
                val inventory = runCatching { OtgInputEventReader().listDevices() }.getOrDefault(emptyList())
                val mouse = inventory.firstOrNull { it.hasMouse } ?: return@scheduleWithFixedDelay
                val keyboard = when {
                    mouse.hasKeyboard -> mouse.path
                    else -> inventory.firstOrNull { it.hasKeyboard && it.path != mouse.path }?.path
                }
                // Do not restart until both HID functions are visible on the hub.
                if (keyboard == null) return@scheduleWithFixedDelay
                startMappingWithPaths(mouse.path, keyboard, lastProfileId)
                if (mappingSession != null) {
                    updateNotification("MT7 reconectado • mouse e teclado detectados automaticamente")
                    stopReconnectSupervisor()
                }
            }, 2, 2, TimeUnit.SECONDS)
        }
    }

    private fun isFinishingOrDestroyed(): Boolean = lastProfileId == null

    @Synchronized
    private fun stopReconnectSupervisor() {
        reconnecting.set(false)
        reconnectExecutor?.shutdownNow()
        reconnectExecutor = null
    }

    @Suppress("DEPRECATION")
    private fun displaySize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = getSystemService(WindowManager::class.java).currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val metrics = android.util.DisplayMetrics()
            getSystemService(WindowManager::class.java).defaultDisplay.getRealMetrics(metrics)
            metrics.widthPixels to metrics.heightPixels
        }
    }

    private fun dispatchSoftwareCursorClick(button: String, pressed: Boolean): Boolean {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return floatingBall?.dispatchGameCursorClick(button, pressed) ?: false
        }
        val handled = java.util.concurrent.atomic.AtomicBoolean(false)
        val completed = CountDownLatch(1)
        mainHandler.post {
            try {
                handled.set(floatingBall?.dispatchGameCursorClick(button, pressed) ?: false)
            } finally {
                completed.countDown()
            }
        }
        return try {
            completed.await()
            handled.get()
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            false
        }
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        lastProfileId = null
        activeMousePath = null
        activeKeyboardPath = null
        stopReconnectSupervisor()
        mappingSession?.close()
        mappingSession = null
        floatingBall?.hide()
        floatingBall = null
        super.onDestroy()
    }

    private fun buildNotification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("MT7 Keymouse")
            .setContentText(message.take(180))
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Serviço MT7", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "mt7_input_service"
        const val NOTIFICATION_ID = 7001
        const val ACTION_START_MAPPING = "com.mt7.keymapper.action.START_MAPPING"
        const val ACTION_AUTO_START = "com.mt7.keymapper.action.AUTO_START"
        const val EXTRA_TARGET_PACKAGE = "com.mt7.keymapper.extra.TARGET_PACKAGE"
        const val ACTION_PAUSE = "com.mt7.keymapper.action.PAUSE"
        const val ACTION_RESUME = "com.mt7.keymapper.action.RESUME"
        const val ACTION_STOP = "com.mt7.keymapper.action.STOP"
        const val ACTION_RELOAD_PROFILE = "com.mt7.keymapper.action.RELOAD_PROFILE"
        const val ACTION_SET_POINTER_SUSPENSION = "com.mt7.keymapper.action.SET_POINTER_SUSPENSION"
        const val ACTION_REFRESH_SOFTWARE_CURSOR = "com.mt7.keymapper.action.REFRESH_SOFTWARE_CURSOR"
        const val EXTRA_POINTER_SUSPENSION_ENABLED = "com.mt7.keymapper.extra.POINTER_SUSPENSION_ENABLED"
        const val EXTRA_MOUSE_DEVICE_PATH = "com.mt7.keymapper.extra.MOUSE_DEVICE_PATH"
        const val EXTRA_KEYBOARD_DEVICE_PATH = "com.mt7.keymapper.extra.KEYBOARD_DEVICE_PATH"
        const val EXTRA_PROFILE_ID = "com.mt7.keymapper.extra.PROFILE_ID"
    }
}
