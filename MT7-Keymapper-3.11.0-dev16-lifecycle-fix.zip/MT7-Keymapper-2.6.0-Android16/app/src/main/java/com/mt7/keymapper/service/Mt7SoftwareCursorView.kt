package com.mt7.keymapper.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * MT7 independent software pointer, styled after the classic white GG Mouse Pro
 * pointer: broad triangular head, black outline and rounded lower tail.
 *
 * It remains a visual-only overlay. Mouse movement is supplied by the OTG
 * input pipeline; this view does not consume game touch events.
 */
internal class Mt7SoftwareCursorView(
    context: Context,
    private val sizeScale: Float
) : View(context) {
    private val density = resources.displayMetrics.density

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 2.25f * density * sizeScale
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = density * sizeScale

        // Classic white mouse arrow with a black border and rounded tail.
        // The proportions follow the default pointer appearance in GG Mouse Pro.
        val arrow = Path().apply {
            moveTo(2.0f * s, 1.0f * s)
            lineTo(32.0f * s, 19.7f * s)
            quadTo(34.4f * s, 21.0f * s, 31.8f * s, 21.8f * s)
            lineTo(21.8f * s, 22.9f * s)
            lineTo(29.8f * s, 34.0f * s)
            cubicTo(
                31.7f * s, 36.5f * s,
                31.3f * s, 39.0f * s,
                28.8f * s, 40.4f * s
            )
            cubicTo(
                26.3f * s, 41.8f * s,
                23.9f * s, 40.8f * s,
                22.3f * s, 38.6f * s
            )
            lineTo(14.4f * s, 27.2f * s)
            lineTo(9.8f * s, 38.8f * s)
            quadTo(8.7f * s, 41.2f * s, 7.8f * s, 38.6f * s)
            close()
        }

        canvas.drawPath(arrow, fill)
        canvas.drawPath(arrow, edge)
    }
}
