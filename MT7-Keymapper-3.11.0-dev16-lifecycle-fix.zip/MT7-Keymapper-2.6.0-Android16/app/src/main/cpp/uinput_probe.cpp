// MT7 privileged uinput probe. Creates and immediately destroys a virtual
// direct-touch device, or runs a persistent multitouch session when requested.
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <poll.h>
#include <sys/time.h>
#include <string>
#include <sstream>
#include <vector>
#include <sys/ioctl.h>
#include <unistd.h>

namespace {
constexpr int kDefaultMaxX = 1079;
constexpr int kDefaultMaxY = 2399;
constexpr int kDefaultSlots = 10;

struct Contact { int pointer_id; int slot; int tracking_id; };

bool set_abs(int fd, unsigned int code, int minimum, int maximum) {
    uinput_abs_setup setup{};
    setup.code = static_cast<__u16>(code);
    setup.absinfo.minimum = minimum;
    setup.absinfo.maximum = maximum;
    return ioctl(fd, UI_ABS_SETUP, &setup) == 0;
}

bool configure_device(int fd, int max_x, int max_y, int slots, const char* name) {
    if (ioctl(fd, UI_SET_EVBIT, EV_SYN) < 0 ||
        ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0 ||
        ioctl(fd, UI_SET_EVBIT, EV_ABS) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, BTN_TOOL_FINGER) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_SLOT) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_X) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_Y) < 0) return false;
#ifdef UI_SET_PROPBIT
    if (ioctl(fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT) < 0) return false;
#endif
    if (!set_abs(fd, ABS_MT_SLOT, 0, slots - 1) ||
        !set_abs(fd, ABS_MT_TRACKING_ID, 0, 65535) ||
        !set_abs(fd, ABS_MT_POSITION_X, 0, max_x) ||
        !set_abs(fd, ABS_MT_POSITION_Y, 0, max_y)) return false;
    uinput_setup setup{};
    setup.id.bustype = BUS_VIRTUAL;
    setup.id.vendor = 0x4D37;
    setup.id.product = 0x0002;
    setup.id.version = 1;
    std::snprintf(setup.name, UINPUT_MAX_NAME_SIZE, "%s", name);
    return ioctl(fd, UI_DEV_SETUP, &setup) == 0 && ioctl(fd, UI_DEV_CREATE) == 0;
}

bool write_event(int fd, unsigned short type, unsigned short code, int value) {
    input_event event{};
    event.type = type;
    event.code = code;
    event.value = value;
    const char* data = reinterpret_cast<const char*>(&event);
    size_t remaining = sizeof(event);
    while (remaining > 0) {
        const ssize_t written = write(fd, data + (sizeof(event) - remaining), remaining);
        if (written > 0) {
            remaining -= static_cast<size_t>(written);
            continue;
        }
        if (written < 0 && errno == EINTR) continue;
        if (written < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            pollfd descriptor{fd, POLLOUT, 0};
            const int ready = poll(&descriptor, 1, 100);
            if (ready > 0 && (descriptor.revents & POLLOUT)) continue;
        }
        return false;
    }
    return true;
}

int serve(int fd, int max_x, int max_y, int slots) {
    if (!configure_device(fd, max_x, max_y, slots, "MT7 Virtual Touchscreen")) {
        const int saved = errno;
        close(fd);
        std::printf("MT7_UINPUT_SESSION:failed:create:errno=%d:%s\n", saved, std::strerror(saved));
        return 1;
    }
    std::vector<Contact> contacts;
    int next_tracking = 1;
    bool touching = false;
    bool failed = false;
    std::string line;
    const auto emit = [&](unsigned short type, unsigned short code, int value) {
        if (write_event(fd, type, code, value)) return true;
        const int saved = errno;
        std::printf("MT7_UINPUT_SESSION:failed:write:errno=%d:%s\n", saved, std::strerror(saved));
        std::fflush(stdout);
        return false;
    };
    const auto sync = [&]() { return emit(EV_SYN, SYN_REPORT, 0); };
    std::puts("MT7_UINPUT_SESSION:ready");
    std::fflush(stdout);
    while (std::getline(std::cin, line)) {
        std::istringstream input(line);
        char command = 0; int pointer = 0; int x = 0; int y = 0;
        input >> command;
        if (command == 'Q') break;
        if (command == 'C') {
            for (const auto& c : contacts) {
                if (!emit(EV_ABS, ABS_MT_SLOT, c.slot) ||
                    !emit(EV_ABS, ABS_MT_TRACKING_ID, -1)) { failed = true; break; }
            }
            contacts.clear();
            if (touching) {
                if (!emit(EV_KEY, BTN_TOUCH, 0) || !emit(EV_KEY, BTN_TOOL_FINGER, 0)) failed = true;
                touching = false;
            }
            if (!sync()) failed = true;
            if (failed) break;
            continue;
        }
        if (!(input >> pointer >> x >> y)) continue;
        auto it = std::find_if(contacts.begin(), contacts.end(), [pointer](const Contact& c) { return c.pointer_id == pointer; });
        if (command == 'D') {
            if (it != contacts.end() || static_cast<int>(contacts.size()) >= slots) continue;
            int slot = 0;
            for (; slot < slots; ++slot) {
                const bool used = std::any_of(contacts.begin(), contacts.end(), [slot](const Contact& c) { return c.slot == slot; });
                if (!used) break;
            }
            const int tracking_id = next_tracking;
            next_tracking = (next_tracking >= 65535) ? 1 : next_tracking + 1;
            contacts.push_back(Contact{pointer, slot, tracking_id});
            it = contacts.end() - 1;
            if (!emit(EV_ABS, ABS_MT_SLOT, slot) || !emit(EV_ABS, ABS_MT_TRACKING_ID, it->tracking_id)) { failed = true; break; }
            if (!touching) {
                if (!emit(EV_KEY, BTN_TOUCH, 1) || !emit(EV_KEY, BTN_TOOL_FINGER, 1)) { failed = true; break; }
                touching = true;
            }
        } else if (command == 'M') {
            if (it == contacts.end()) continue;
            if (!emit(EV_ABS, ABS_MT_SLOT, it->slot)) { failed = true; break; }
        } else if (command == 'U') {
            if (it == contacts.end()) continue;
            const int released_slot = it->slot;
            if (!emit(EV_ABS, ABS_MT_SLOT, released_slot) || !emit(EV_ABS, ABS_MT_TRACKING_ID, -1)) { failed = true; break; }
            contacts.erase(it);
            if (contacts.empty() && touching) {
                if (!emit(EV_KEY, BTN_TOUCH, 0) || !emit(EV_KEY, BTN_TOOL_FINGER, 0)) { failed = true; break; }
                touching = false;
            }
        } else continue;
        if (command == 'D' || command == 'M') {
            if (!emit(EV_ABS, ABS_MT_POSITION_X, std::max(0, std::min(max_x, x))) ||
                !emit(EV_ABS, ABS_MT_POSITION_Y, std::max(0, std::min(max_y, y)))) { failed = true; break; }
        }
        if (!sync()) { failed = true; break; }
    }
    // Best-effort release before destroying the virtual device, including on write failure.
    for (const auto& c : contacts) {
        write_event(fd, EV_ABS, ABS_MT_SLOT, c.slot);
        write_event(fd, EV_ABS, ABS_MT_TRACKING_ID, -1);
    }
    if (touching) {
        write_event(fd, EV_KEY, BTN_TOUCH, 0);
        write_event(fd, EV_KEY, BTN_TOOL_FINGER, 0);
    }
    write_event(fd, EV_SYN, SYN_REPORT, 0);
    ioctl(fd, UI_DEV_DESTROY);
    close(fd);
    if (failed) return 1;
    std::puts("MT7_UINPUT_SESSION:closed");
    return 0;
}

int fail(int fd, const char* stage) {
    const int saved = errno;
    if (fd >= 0) close(fd);
    std::printf("MT7_UINPUT_PROBE:failed:%s:errno=%d:%s\n", stage, saved, std::strerror(saved));
    return 1;
}
}

int main(int argc, char** argv) {
    if (argc > 1 && std::strcmp(argv[1], "--help") == 0) {
        std::puts("Usage: helper [device-path] [max-x] [max-y] [slots] | helper --serve [device-path] [max-x] [max-y] [slots]");
        std::puts("Session stdin commands: D|M|U pointerId x y; C (release all); Q (quit)");
        return 0;
    }
    const bool session_mode = argc > 1 && std::strcmp(argv[1], "--serve") == 0;
    const int offset = session_mode ? 1 : 0;
    const char* path = argc > 1 + offset ? argv[1 + offset] : "/dev/uinput";
    const int max_x = argc > 2 + offset ? std::atoi(argv[2 + offset]) : kDefaultMaxX;
    const int max_y = argc > 3 + offset ? std::atoi(argv[3 + offset]) : kDefaultMaxY;
    const int slots = argc > 4 + offset ? std::atoi(argv[4 + offset]) : kDefaultSlots;
    if (max_x <= 0 || max_y <= 0 || slots < 1 || slots > 32) {
        std::puts("MT7_UINPUT_PROBE:failed:invalid-arguments");
        return 2;
    }

    const int fd = open(path, O_WRONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) return fail(-1, "open");
    if (session_mode) return serve(fd, max_x, max_y, slots);

    if (ioctl(fd, UI_SET_EVBIT, EV_SYN) < 0 ||
        ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0 ||
        ioctl(fd, UI_SET_EVBIT, EV_ABS) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH) < 0 ||
        ioctl(fd, UI_SET_KEYBIT, BTN_TOOL_FINGER) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_SLOT) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_X) < 0 ||
        ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_Y) < 0) {
        return fail(fd, "capabilities");
    }
#ifdef UI_SET_PROPBIT
    if (ioctl(fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT) < 0) return fail(fd, "direct-property");
#endif
    if (!set_abs(fd, ABS_MT_SLOT, 0, slots - 1) ||
        !set_abs(fd, ABS_MT_TRACKING_ID, 0, 65535) ||
        !set_abs(fd, ABS_MT_POSITION_X, 0, max_x) ||
        !set_abs(fd, ABS_MT_POSITION_Y, 0, max_y)) {
        return fail(fd, "abs-setup");
    }

    uinput_setup setup{};
    setup.id.bustype = BUS_VIRTUAL;
    setup.id.vendor = 0x4D37;
    setup.id.product = 0x0001;
    setup.id.version = 1;
    std::snprintf(setup.name, UINPUT_MAX_NAME_SIZE, "%s", "MT7 Virtual Touchscreen (probe)");
    if (ioctl(fd, UI_DEV_SETUP, &setup) < 0) return fail(fd, "device-setup");
    if (ioctl(fd, UI_DEV_CREATE) < 0) return fail(fd, "device-create");

    // Successful creation is the only capability claim. Destroy immediately;
    // no touch events are ever sent to Android or to a running game.
    usleep(100 * 1000);
    if (ioctl(fd, UI_DEV_DESTROY) < 0) return fail(fd, "device-destroy");
    close(fd);
    std::printf("MT7_UINPUT_PROBE:created-and-destroyed:%s:max=%dx%d:slots=%d\n", path, max_x, max_y, slots);
    return 0;
}
