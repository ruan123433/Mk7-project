package com.mt7.keymapper.core.injection

import org.junit.Assert.*
import org.junit.Test

class UinputCapabilityInspectorTest {
    @Test fun parsesWritableUinputNode() {
        val report = UinputCapabilityInspector.parse(
            UinputCapabilityInspector.Backend.ROOT,
            "MT7_UINPUT_WRITABLE:/dev/uinput\nMT7_UINPUT_MODULE:loaded\nMT7_SELINUX:Enforcing"
        )
        assertEquals(UinputCapabilityInspector.NodeAccess.WRITABLE, report.access)
        assertEquals("/dev/uinput", report.nodePath)
        assertTrue(report.moduleLoaded)
        assertEquals("Enforcing", report.selinuxMode)
        assertTrue(report.readyForWriteProbe)
    }

    @Test fun distinguishesExistingNodeWithoutAccess() {
        val report = UinputCapabilityInspector.parse(
            UinputCapabilityInspector.Backend.SHIZUKU,
            "MT7_UINPUT_NO_ACCESS:/dev/input/uinput\nMT7_UINPUT_MODULE:not_loaded"
        )
        assertEquals(UinputCapabilityInspector.NodeAccess.PRESENT_NO_ACCESS, report.access)
        assertFalse(report.moduleLoaded)
        assertFalse(report.readyForWriteProbe)
    }

    @Test fun reportsMissingNode() {
        val report = UinputCapabilityInspector.parse(
            UinputCapabilityInspector.Backend.ROOT,
            "MT7_UINPUT_MODULE:not_loaded"
        )
        assertEquals(UinputCapabilityInspector.NodeAccess.MISSING, report.access)
        assertNull(report.nodePath)
    }
}
