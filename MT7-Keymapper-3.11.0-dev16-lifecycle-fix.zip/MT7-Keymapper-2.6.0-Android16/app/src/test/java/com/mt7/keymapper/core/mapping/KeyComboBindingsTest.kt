package com.mt7.keymapper.core.mapping

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyComboBindingsTest {
    @Test fun parsesAndFormatsCombos() {
        val parsed = KeyComboBindings.parse("CTRL+1=ESPAÇO; SHIFT+Q=R")
        assertEquals(2, parsed.size)
        assertEquals("1+CTRL ESQ", parsed[0].signature)
        assertEquals("ESPAÇO", parsed[0].targetKey)
        assertEquals(parsed, KeyComboBindings.parse(KeyComboBindings.format(parsed)))
    }

    @Test fun ignoresInvalidDuplicateAndOversizedCombos() {
        val parsed = KeyComboBindings.parse("CTRL+1=ESPAÇO; 1+CTRL=R; W=ESPAÇO; CTRL+1+Q+E+T=F")
        assertEquals(1, parsed.size)
        assertTrue(KeyComboBindings.parse("CTRL+1=CTRL").isEmpty())
    }
}
