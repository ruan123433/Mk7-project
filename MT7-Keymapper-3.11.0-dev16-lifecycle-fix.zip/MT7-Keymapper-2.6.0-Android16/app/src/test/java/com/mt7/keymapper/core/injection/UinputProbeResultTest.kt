package com.mt7.keymapper.core.injection

import org.junit.Assert.*
import org.junit.Test

class UinputProbeResultTest {
    @Test fun parsesSuccessfulCreateAndDestroy() {
        val result = UinputProbeResult.parse(
            0,
            "MT7_UINPUT_PROBE:created-and-destroyed:/dev/uinput:max=1079x2399:slots=10"
        )
        assertTrue(result.createdAndDestroyed)
        assertNull(result.stage)
        assertTrue(result.detail.contains("Nenhum toque foi enviado"))
    }

    @Test fun parsesOpenFailure() {
        val result = UinputProbeResult.parse(
            1,
            "MT7_UINPUT_PROBE:failed:open:errno=13:Permission denied"
        )
        assertFalse(result.createdAndDestroyed)
        assertEquals("open", result.stage)
        assertEquals(13, result.errno)
        assertTrue(result.detail.contains("Permission denied"))
    }

    @Test fun doesNotTreatExitZeroWithoutMarkerAsSuccess() {
        val result = UinputProbeResult.parse(0, "permission denied")
        assertFalse(result.createdAndDestroyed)
    }
}
