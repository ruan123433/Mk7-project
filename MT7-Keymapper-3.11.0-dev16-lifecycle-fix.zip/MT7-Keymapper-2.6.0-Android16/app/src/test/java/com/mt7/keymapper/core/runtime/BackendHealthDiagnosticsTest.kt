package com.mt7.keymapper.core.runtime

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class BackendHealthDiagnosticsTest {
    @Test fun escalatesRepeatedFailuresAndRecoversAfterConfirmedDelivery() {
        val health = BackendHealthDiagnostics(failureThreshold = 3)
        assertEquals(BackendHealth.DEGRADED, health.recordFailure("injeção recusada").health)
        assertEquals(BackendHealth.DEGRADED, health.recordFailure("uinput ocupado").health)
        val failed = health.recordFailure("dispositivo desconectado")
        assertEquals(BackendHealth.FAILED, failed.health)
        assertEquals(3L, failed.consecutiveFailures)
        assertEquals(3L, failed.totalFailures)
        assertNotNull(failed.lastFailure)

        val recovered = health.recordSuccess()
        assertEquals(BackendHealth.HEALTHY, recovered.health)
        assertEquals(0L, recovered.consecutiveFailures)
        assertEquals(3L, recovered.totalFailures)
    }

    @Test fun resetClearsFaultHistory() {
        val health = BackendHealthDiagnostics()
        health.recordFailure("falha")
        health.reset()
        val snapshot = health.snapshot()
        assertEquals(BackendHealth.HEALTHY, snapshot.health)
        assertEquals(0L, snapshot.totalFailures)
        assertEquals(null, snapshot.lastFailure)
    }
}
