package com.mt7.keymapper.core.mapping

import org.junit.Assert.assertEquals
import org.junit.Test

class TouchLayoutProfileIntegrationTest {
    @Test
    fun fromProfileTransfersCalibratedPositionsAndFreeKeysToRuntimeLayout() {
        val profile = MappingProfile(
            id = "calibrated",
            name = "Perfil calibrado",
            joystickPositionX = 0.12f,
            joystickPositionY = 0.81f,
            viewPositionX = 0.67f,
            viewPositionY = 0.39f,
            firePositionX = 0.91f,
            firePositionY = 0.73f,
            jumpPositionX = 0.76f,
            jumpPositionY = 0.82f,
            reloadPositionX = 0.93f,
            reloadPositionY = 0.51f,
            interactPositionX = 0.61f,
            interactPositionY = 0.69f,
            keyTaps = listOf(KeyTapBinding("G", 0.44f, 0.56f))
        )

        val layout = TouchLayout.fromProfile(1920, 1080, profile)

        assertEquals(1920, layout.width)
        assertEquals(1080, layout.height)
        assertEquals(profile.joystickPositionX, layout.joystickX, 0.0001f)
        assertEquals(profile.joystickPositionY, layout.joystickY, 0.0001f)
        assertEquals(profile.viewPositionX, layout.lookX, 0.0001f)
        assertEquals(profile.viewPositionY, layout.lookY, 0.0001f)
        assertEquals(profile.firePositionX, layout.fireX, 0.0001f)
        assertEquals(profile.firePositionY, layout.fireY, 0.0001f)
        assertEquals(profile.jumpPositionX, layout.jumpX, 0.0001f)
        assertEquals(profile.jumpPositionY, layout.jumpY, 0.0001f)
        assertEquals(profile.reloadPositionX, layout.reloadX, 0.0001f)
        assertEquals(profile.reloadPositionY, layout.reloadY, 0.0001f)
        assertEquals(profile.interactPositionX, layout.interactX, 0.0001f)
        assertEquals(profile.interactPositionY, layout.interactY, 0.0001f)
        assertEquals(profile.keyTaps, layout.keyTaps)
    }
}
