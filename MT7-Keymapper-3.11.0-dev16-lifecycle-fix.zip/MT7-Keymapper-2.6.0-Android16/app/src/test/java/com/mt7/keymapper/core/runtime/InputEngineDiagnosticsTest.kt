package com.mt7.keymapper.core.runtime

import org.junit.Assert.assertEquals
import org.junit.Test

class InputEngineDiagnosticsTest {
    @Test fun countsProducedDeliveredFailedAndIgnoredEvents() {
        val diagnostics = InputEngineDiagnostics()
        diagnostics.record(System.nanoTime(), producedAction = false, delivery = null)
        diagnostics.record(System.nanoTime(), producedAction = true, delivery = true)
        diagnostics.record(System.nanoTime(), producedAction = true, delivery = false)

        val snapshot = diagnostics.snapshot()
        assertEquals(3L, snapshot.eventsReceived)
        assertEquals(2L, snapshot.actionsProduced)
        assertEquals(1L, snapshot.actionsDelivered)
        assertEquals(1L, snapshot.deliveryFailures)
        assertEquals(1L, snapshot.ignoredEvents)
    }

    @Test fun resetClearsCountersAndTimings() {
        val diagnostics = InputEngineDiagnostics()
        diagnostics.record(System.nanoTime(), producedAction = true, delivery = true)
        diagnostics.reset()
        val snapshot = diagnostics.snapshot()
        assertEquals(0L, snapshot.eventsReceived)
        assertEquals(0L, snapshot.actionsProduced)
        assertEquals(0L, snapshot.actionsDelivered)
        assertEquals(0L, snapshot.deliveryFailures)
        assertEquals(0L, snapshot.ignoredEvents)
        assertEquals(0L, snapshot.lastProcessingMicros)
        assertEquals(0L, snapshot.maxProcessingMicros)
    }
}
