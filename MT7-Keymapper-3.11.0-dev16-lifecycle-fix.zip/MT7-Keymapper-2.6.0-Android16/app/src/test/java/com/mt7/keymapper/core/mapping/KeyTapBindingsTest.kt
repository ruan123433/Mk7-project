package com.mt7.keymapper.core.mapping

import org.junit.Assert.*
import org.junit.Test

class KeyTapBindingsTest {
    @Test fun parsesKeyPercentPairs() {
        val list = KeyTapBindings.parse("g=55,80; 1=40,10\nespaco=72.5,78")
        assertEquals(listOf("G", "1", "ESPAÇO"), list.map { it.key })
        assertEquals(0.55f, list[0].x, 0.0001f)
        assertEquals(0.80f, list[0].y, 0.0001f)
        assertEquals(0.725f, list[2].x, 0.0001f)
    }

    @Test fun skipsReservedInvalidAndDuplicateKeys() {
        val list = KeyTapBindings.parse("W=10,10; Mouse esquerdo=50,50; G=150,10; H=abc; G=20,20; G=30,30")
        assertEquals(listOf("G"), list.map { it.key })
        assertEquals(0.2f, list.single().x, 0.0001f)
    }

    @Test fun normalizesMouseButtonNames() {
        val list = KeyTapBindings.parse("mouse lateral 1=90,40; mouse4=10,10; mouse direito=50,50")
        assertEquals(listOf("Mouse lateral 1", "Mouse direito"), list.map { it.key })
    }

    @Test fun formatRoundTrips() {
        val text = "G=55,80; 1=40.5,10"
        assertEquals(text, KeyTapBindings.format(KeyTapBindings.parse(text)))
    }

    @Test fun capsAtMaxBindings() {
        val text = (1..9).joinToString(";") { "$it=1,1" } + ";" + "QETYUIOPZXCVBNM".map { "$it=2,2" }.joinToString(";")
        assertEquals(KeyTapBindings.MAX_BINDINGS, KeyTapBindings.parse(text).size)
    }
}
