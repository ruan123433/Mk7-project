package com.mt7.keymapper.core.input

import org.junit.Assert.*
import org.junit.Test

class OtgInputEventReaderTest {
    @Test fun parsesKeyEvent() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event4", "[ 123.456] /dev/input/event4: 0001 0110 00000001"
        )
        assertNotNull(event)
        assertEquals(1, event!!.type)
        assertEquals(0x0110, event.code)
        assertEquals(1, event.value)
        assertEquals("123.456", event.timestamp)
    }

    @Test fun parsesGeteventTimestampWithPaddedWhitespace() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event6", "[  1234.123456] /dev/input/event6: 0001 001e 00000001"
        )
        assertNotNull(event)
        assertEquals("1234.123456", event!!.timestamp)
        assertEquals(1, event.value)
    }

    @Test fun parsesRelativeMouseEvent() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event5", "[ 7.25] 0002 0000 fffffffe"
        )
        assertNotNull(event)
        assertEquals(2, event!!.type)
        assertEquals(0, event.code)
        assertEquals(-2, event.value)
    }

    @Test fun parsesNativeGrabHelperEventLineWithoutTimestampOrDevicePrefix() {
        val event = OtgInputEventReader.parseLine(
            "/dev/input/event7", "0002 0000 fffffffe"
        )
        assertNotNull(event)
        assertEquals(2, event!!.type)
        assertEquals(0, event.code)
        assertEquals(-2, event.value)
        assertEquals("/dev/input/event7", event.devicePath)
    }

    @Test fun classifiesUsbHubMouseAndKeyboardNodesAutomatically() {
        val listing = """
            add device 1: /dev/input/event4
              name: "USB Receiver Mouse"
              events:
                KEY (0001): BTN_LEFT BTN_RIGHT
                REL (0002): REL_X REL_Y REL_WHEEL
            add device 2: /dev/input/event5
              name: "USB Receiver Keyboard"
              events:
                KEY (0001): KEY_ESC KEY_1 KEY_Q KEY_A KEY_ENTER KEY_SPACE
        """.trimIndent()

        val devices = OtgInputEventReader().parseDeviceListing(listing)
        assertEquals(2, devices.size)
        assertTrue(devices.first { it.path.endsWith("event4") }.hasMouse)
        assertFalse(devices.first { it.path.endsWith("event4") }.hasKeyboard)
        assertTrue(devices.first { it.path.endsWith("event5") }.hasKeyboard)
        assertFalse(devices.first { it.path.endsWith("event5") }.hasMouse)
    }

    @Test fun classifiesCombinedHidNodeAsMouseAndKeyboard() {
        val listing = """
            add device 1: /dev/input/event7
              name: "USB Composite HID"
              events:
                KEY (0001): KEY_A KEY_ENTER BTN_LEFT
                REL (0002): REL_X REL_Y
        """.trimIndent()
        val device = OtgInputEventReader().parseDeviceListing(listing).single()
        assertTrue(device.hasMouse)
        assertTrue(device.hasKeyboard)
    }

    @Test fun rejectsUnrelatedLine() {
        assertNull(OtgInputEventReader.parseLine("/dev/input/event1", "waiting for events"))
    }

    @Test fun rejectsUnsafeDevicePathAtApiBoundary() {
        // Path validation is performed by start(); parser itself only parses event lines.
        assertNull(OtgInputEventReader.parseLine("/dev/input/event1", "not an event"))
    }
}
