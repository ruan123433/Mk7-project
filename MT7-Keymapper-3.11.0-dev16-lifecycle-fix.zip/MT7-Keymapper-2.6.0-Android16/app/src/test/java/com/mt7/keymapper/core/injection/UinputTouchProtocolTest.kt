package com.mt7.keymapper.core.injection

import org.junit.Assert.*
import org.junit.Test

class UinputTouchProtocolTest {
    private val protocol = UinputTouchProtocol(maxX = 1080, maxY = 2400, maxSlots = 2)

    @Test fun firstContactCreatesSlotAndEnablesTouch() {
        val events = protocol.pointerDown(pointerId = 7, x = 120, y = 300)
        assertEquals(
            listOf(
                UinputTouchProtocol.InputEvent(3, 0x2f, 0),
                UinputTouchProtocol.InputEvent(3, 0x39, 1),
                UinputTouchProtocol.InputEvent(3, 0x35, 120),
                UinputTouchProtocol.InputEvent(3, 0x36, 300),
                UinputTouchProtocol.InputEvent(1, 0x14a, 1),
                UinputTouchProtocol.InputEvent(1, 0x145, 1),
                UinputTouchProtocol.InputEvent(0, 0, 0)
            ), events
        )
    }

    @Test fun secondContactUsesAnotherSlotWithoutTogglingGlobalTouch() {
        protocol.pointerDown(1, 10, 20)
        val events = protocol.pointerDown(2, 30, 40)
        assertEquals(1, events.first { it.code == UinputTouchProtocol.ABS_MT_SLOT }.value)
        assertFalse(events.any { it.type == UinputTouchProtocol.EV_KEY })
        assertEquals(2, protocol.activePointers().size)
    }

    @Test fun moveClampsCoordinatesAndUnknownPointerIsIgnored() {
        protocol.pointerDown(1, 10, 20)
        val events = protocol.pointerMove(1, 5000, -5)
        assertEquals(1080, events.first { it.code == UinputTouchProtocol.ABS_MT_POSITION_X }.value)
        assertEquals(0, events.first { it.code == UinputTouchProtocol.ABS_MT_POSITION_Y }.value)
        assertTrue(protocol.pointerMove(99, 1, 1).isEmpty())
    }

    @Test fun touchIsDisabledOnlyAfterLastPointerIsReleased() {
        protocol.pointerDown(1, 10, 20)
        protocol.pointerDown(2, 30, 40)
        val firstUp = protocol.pointerUp(1)
        assertFalse(firstUp.any { it.type == UinputTouchProtocol.EV_KEY })
        val lastUp = protocol.pointerUp(2)
        assertEquals(0, lastUp.first { it.type == UinputTouchProtocol.EV_KEY && it.code == UinputTouchProtocol.BTN_TOUCH }.value)
        assertEquals(0, protocol.activePointers().size)
    }

    @Test fun cancelAllReleasesEverySlotAndIsIdempotent() {
        protocol.pointerDown(1, 10, 20)
        protocol.pointerDown(2, 30, 40)
        val events = protocol.cancelAll()
        assertEquals(2, events.count { it.type == UinputTouchProtocol.EV_ABS && it.code == UinputTouchProtocol.ABS_MT_TRACKING_ID && it.value == -1 })
        assertTrue(protocol.cancelAll().isEmpty())
        assertTrue(protocol.activePointers().isEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsMoreContactsThanConfiguredSlots() {
        protocol.pointerDown(1, 0, 0)
        protocol.pointerDown(2, 0, 0)
        protocol.pointerDown(3, 0, 0)
    }
}
