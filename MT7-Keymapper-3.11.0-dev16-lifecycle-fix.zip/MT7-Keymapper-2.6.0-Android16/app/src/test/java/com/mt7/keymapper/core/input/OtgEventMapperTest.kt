package com.mt7.keymapper.core.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OtgEventMapperTest {
    private val mapper = OtgEventMapper()

    private fun event(type: Int, code: Int, value: Int) =
        OtgInputEventReader.InputEvent("/dev/input/event4", type, code, value, null)

    @Test fun mapsWKeyPressAndRelease() {
        val down = mapper.map(event(0x01, 17, 1))!!
        val up = mapper.map(event(0x01, 17, 0))!!
        assertEquals("W", down.label)
        assertEquals(true, down.pressed)
        assertEquals(false, up.pressed)
    }

    @Test fun mapsMouseButtons() {
        val action = mapper.map(event(0x01, 0x110, 1))!!
        assertEquals(OtgEventMapper.Kind.MOUSE_BUTTON, action.kind)
        assertEquals("Mouse esquerdo", action.label)
        assertEquals(true, action.pressed)
    }

    @Test fun mapsRelativeMouseAxesAndScroll() {
        assertNull(mapper.map(event(0x02, 0x00, -7)))
        assertNull(mapper.map(event(0x02, 0x01, 4)))
        val movement = mapper.map(event(0x00, 0x00, 0))!!
        assertEquals(OtgEventMapper.Kind.POINTER_MOVE, movement.kind)
        assertEquals(-7, movement.deltaX)
        assertEquals(4, movement.deltaY)
        val wheel = mapper.map(event(0x02, 0x08, 1))!!
        assertEquals(OtgEventMapper.Kind.SCROLL, wheel.kind)
    }

    @Test fun coalescesBothAxesAtSynReportAndResetsForNextFrame() {
        assertNull(mapper.map(event(0x02, 0x00, 12)))
        assertNull(mapper.map(event(0x02, 0x01, -5)))
        val first = mapper.map(event(0x00, 0x00, 0))!!
        assertEquals(12, first.deltaX)
        assertEquals(-5, first.deltaY)
        assertNull(mapper.map(event(0x00, 0x00, 0)))
        assertNull(mapper.map(event(0x02, 0x01, 3)))
        val second = mapper.map(event(0x00, 0x00, 0))!!
        assertEquals(0, second.deltaX)
        assertEquals(3, second.deltaY)
    }

    @Test fun clampsMalformedHugeRelativeFrameWithoutIntegerOverflow() {
        assertNull(mapper.map(event(0x02, 0x00, Int.MAX_VALUE)))
        val movement = mapper.map(event(0x00, 0x00, 0))!!
        assertEquals(32767, movement.deltaX)
    }

    @Test fun preservesLinuxAutorepeatAsRepeatInsteadOfFreshPress() {
        val repeat = mapper.map(event(0x01, 17, 2))!!
        assertEquals("W", repeat.label)
        assertEquals(true, repeat.pressed)
        assertEquals(true, repeat.repeat)
        val down = mapper.map(event(0x01, 17, 1))!!
        assertEquals(false, down.repeat)
    }

    @Test fun resetDiscardsUnfinishedRelativeFrame() {
        assertNull(mapper.map(event(0x02, 0x00, 12)))
        mapper.reset()
        assertNull(mapper.map(event(0x00, 0x00, 0)))
    }

    @Test fun ignoresSynchronizationUnknownCodesAndInvalidKeyValues() {
        assertNull(mapper.map(event(0x00, 0, 0)))
        assertNull(mapper.map(event(0x01, 999, 1)))
        assertNull(mapper.map(event(0x01, 17, 9)))
    }
}
