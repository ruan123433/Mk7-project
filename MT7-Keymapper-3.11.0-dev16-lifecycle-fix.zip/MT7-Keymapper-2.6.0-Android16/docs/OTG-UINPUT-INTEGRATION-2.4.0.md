# MT7 2.4.0 — integração do pipeline OTG com uinput

## Fluxo implementado

1. `PrivilegedOtgMappingSession.start(context, devicePath, displayWidth, displayHeight, profile = perfil)` aplica o perfil salvo; sem `profile`, mantém o layout de fábrica. A chamada solicita uma sessão persistente de touchscreen virtual por `UinputTouchSession.start`.
2. O transporte tenta Root primeiro; se o helper não confirmar `MT7_UINPUT_SESSION:ready`, tenta Shizuku. Autorização por si só não é tratada como sucesso.
3. Após o uinput estar pronto, a sessão seleciona o backend confirmado no `MappingRuntime`, inicia o runtime e inicia `OtgInputEventReader` no nó `/dev/input/eventN` indicado.
4. Cada evento capturado passa por `OtgEventMapper`, `MappingRuntime.processAndInject` e `OtgTouchMappingController`, terminando em `D/M/U/C` no transporte uinput.

## Mapeamento inicial padrão

- WASD: contato contínuo no joystick virtual (diagonais normalizadas).
- Mouse esquerdo: contato de disparo.
- A partir da 2.4.3, o botão direito não controla a visão: é uma ação comum configurável. O modo de visão é alternado por binding independente; veja `OTG-MOUSE-VIEW-2.4.3.md`.
- Espaço: pulo; R: recarga; F: interação.
- Scroll e teclas não configuradas são ignorados por padrão.

As posições são frações da resolução informada em `TouchLayout`. Os valores padrão não foram calibrados para o HUD de Free Fire; precisam de editor visual, ajuste de orientação e teste no aparelho antes de serem considerados utilizáveis.

## Liberação e falhas

- `pause()` libera contatos antes de pausar.
- `close()` encerra a captura, envia `C`, para o runtime e fecha o helper (`Q`).
- Se o leitor OTG encerrar inesperadamente, os contatos são liberados e o runtime é pausado.
- `MappingRuntime.processAndInject` não envia nada se o runtime não estiver em `READY`.
- O helper C++ remove da lista os contatos já liberados para evitar crescimento de memória em uso prolongado.

## Limitações não resolvidas

- O início da sessão é uma API de integração; ainda não foi conectado a um fluxo de tela/editor de perfil no app. A captura passou a usar o helper nativo com grab sob demanda na versão 2.4.4; veja `OTG-NATIVE-GRAB-2.4.4.md`.
- O usuário ainda precisa selecionar o nó OTG correto; a seleção automática do mouse/teclado, separação de interfaces compostas e hotplug ainda não estão completas.
- O parser `getevent` e o caminho de captura precisam de validação em Android 16 e em dispositivos reais.
- As coordenadas assumem a mesma orientação e área útil do dispositivo virtual e do display; recortes, barras do sistema, rotação e densidade ainda precisam de calibração.
- Shizuku pode não ter permissão para abrir `/dev/uinput`; o fallback só será aceito se o helper realmente criar o dispositivo.
- Não foi gerado APK nesta execução e não houve teste físico no Redmi Note 14 4G.


## Ajustes de perfil adicionados na 2.4.1

- Sensibilidade X e Y independentes em passos de 0,1 (0,1 a 10,0), aplicadas ao movimento de visão quando o layout é criado por `TouchLayout.fromProfile(...)`.
- Intervalo mínimo entre acionamentos repetidos de teclas de ação (0 a 500 ms, passos de 10 ms; 0 desativa o limitador), persistido no perfil.
- Botão de tiro no mouse esquerdo, com posição HUD persistida e ajustável e modos TAP/HOLD/TOGGLE disponíveis no painel de configuração local. O toque de tiro da sessão OTG permanece pressionado enquanto o botão esquerdo estiver pressionado.
