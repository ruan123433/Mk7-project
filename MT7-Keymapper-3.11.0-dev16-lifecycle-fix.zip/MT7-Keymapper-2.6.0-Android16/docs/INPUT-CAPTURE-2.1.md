# Captura de entrada OTG — 2.1.0

## Objetivo
Receber eventos de mouse e teclado que o Android encaminha ao serviço de acessibilidade MT7, e mostrar evidência no painel de diagnóstico.

## Caminho de entrada
- Teclado: `AccessibilityService.onKeyEvent`, solicitado com `FLAG_REQUEST_FILTER_KEY_EVENTS`.
- Mouse: `AccessibilityService.onMotionEvent`, com `AccessibilityServiceInfo.setMotionEventSources(SOURCE_MOUSE | SOURCE_MOUSE_RELATIVE)` no Android 14+.
- Origem: `InputDevice.getDevice(event.deviceId)` para exibir o nome do dispositivo.

## Mapeamentos atualmente implementados
- W/A/S/D: joystick virtual por gesto de acessibilidade.
- Espaço: toque no ponto de disparo.
- Botão esquerdo: toque no ponto de disparo.
- Botão direito: toque no ponto de mira.
- Movimento: delta X/Y alimenta o gesto de câmera.
- Scroll: contabilizado no diagnóstico; ainda sem ação de jogo.
- Outras teclas e botões: observados, mas sem ação atribuída.

## Diagnóstico
`InputCaptureMonitor` mantém contadores e o último evento entregue ao serviço. O painel Laboratório de mouse exibe teclado, movimento, botões, scroll, nome do dispositivo e delta recente.

## Pré-requisitos e limites
- O usuário precisa ativar manualmente o Serviço de acessibilidade MT7.
- O mapeamento precisa estar ativo.
- O callback global de movimento do mouse requer Android 14/API 34+.
- A lista de dispositivos Android não é prova de que eventos estejam chegando ao serviço.
- Necessário compilar e testar no Redmi Note 14 4G; ainda não há resultado de teste físico nesta entrega.
