# MT7 2.3.6 — construtor de protocolo multitouch

## Implementado

- `UinputTouchProtocol` constrói registros Linux `EV_ABS`, `EV_KEY` e `EV_SYN` em memória.
- Cada contato usa um `ABS_MT_SLOT` e um `ABS_MT_TRACKING_ID` exclusivos enquanto estiver ativo.
- `pointerDown`, `pointerMove` e `pointerUp` geram os eventos e `SYN_REPORT` necessários para cada quadro.
- `BTN_TOUCH` e `BTN_TOOL_FINGER` só são ativados no primeiro contato e desativados após o último contato.
- Coordenadas são limitadas ao intervalo configurado; número máximo de slots é validado (1 a 32).
- `cancelAll()` libera todos os tracking IDs ativos e é idempotente.
- Testes unitários cobrem primeiro/segundo contato, movimento, limites, liberação, cancelamento e limite de slots.

## Limite deliberado desta versão

Esta classe é um construtor de protocolo puro. Não abre `/dev/uinput`, não chama `ioctl`, não cria dispositivo virtual, não inicia processo Root/Shizuku e não envia eventos ao Android ou ao Free Fire. Portanto, não deve ser apresentada como injeção multitouch funcional.

## Próxima etapa de engenharia

Implementar um transporte nativo privilegiado separado, com criação do dispositivo uinput (capacidades ABS/MT e ioctl), canal de comandos/eventos, encerramento confiável e liberação de todos os contatos em pausa, parada, falha ou perda do backend. Root deve ser preferido; Shizuku só pode ser selecionado se o processo efetivamente tiver permissão para abrir e configurar o nó. O teste final deve ocorrer primeiro numa tela de teste controlada, nunca diretamente numa partida.

## Validação desta versão

- O arquivo Kotlin `UinputTouchProtocol.kt` foi compilado isoladamente com `kotlinc` nesta sessão.
- Não foi possível executar o conjunto JUnit/Gradle nem gerar APK: o ZIP não contém `gradlew`/`gradle-wrapper.jar` e não há Gradle instalado no ambiente.
- Não houve teste em dispositivo Android.
