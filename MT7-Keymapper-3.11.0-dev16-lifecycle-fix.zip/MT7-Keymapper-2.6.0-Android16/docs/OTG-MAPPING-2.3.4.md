# MT7 2.3.4 — interpretação de eventos OTG

## O que entrou

- `OtgEventMapper` converte registros Linux `EV_KEY` e `EV_REL` em ações semânticas locais.
- Teclas reconhecidas incluem WASD, Espaço, Shift, Ctrl, R, F e outras teclas comuns.
- Botões reconhecidos incluem esquerdo, direito, meio e dois botões laterais do mouse.
- Movimento relativo X/Y e roda vertical/horizontal são identificados.
- O painel de Dispositivos mostra ações interpretadas e mantém a lista de eventos brutos para diagnóstico.
- `MappingRuntime.processInput` oferece uma porta de entrada que respeita os estados STOPPED, PAUSED e WAITING_AUTHORIZATION. Só processa eventos quando o backend selecionado está autorizado e o runtime está READY.

## Limites importantes

Esta versão ainda não cria dispositivo virtual `uinput`, não injeta multitouch, não converte ações em coordenadas de toque e não controla o Free Fire. O método do runtime devolve ações semânticas locais; não envia eventos para outro aplicativo. O painel de diagnóstico mostra a interpretação para validar os códigos recebidos.

A leitura de `/dev/input/eventN` continua dependente do acesso efetivo concedido por Root/Shizuku, do binário `getevent`, do kernel e das políticas SELinux do aparelho. O comportamento no Redmi Note 14 4G com Android 16 precisa ser validado fisicamente.

## Testes adicionados

- Mapeamento de pressionar/soltar W.
- Mapeamento de botões do mouse.
- Movimento relativo e scroll.
- Ignorar eventos desconhecidos, sincronização e valores inválidos.
- Bloqueio do processamento pelo ciclo de vida/autorização do runtime.

A compilação Android e a execução da suíte Gradle não foram realizadas neste ambiente: o ZIP não contém `gradlew` e não há Gradle instalado.
