# MT7 2.5.0 — detecção automática de HUB USB OTG

## O que mudou

- A listagem privilegiada `getevent -pl` agora é interpretada por blocos de dispositivo.
- Cada nó `/dev/input/eventN` recebe indicadores de capacidade de mouse e teclado com base no nome e nas capacidades Linux `REL_X`, `REL_Y`, `BTN_LEFT` e códigos `KEY_*`.
- O botão **Detectar HUB automaticamente** seleciona o nó de mouse e o nó de teclado quando o Android os expõe separadamente.
- Se o Android expuser um único nó HID composto, o mesmo caminho é atribuído aos dois papéis e a sessão abre apenas um capturador para evitar leitura duplicada.
- A seleção detectada é salva nas preferências do MT7. A seleção manual continua disponível para dispositivos que não possam ser classificados pelo nome/capacidades.
- Foram adicionados testes unitários para receptor com nós separados e nó HID composto.

## Limites e validação

A detecção depende da saída de `getevent -pl` e da autorização Root/Shizuku. Alguns kernels ou fabricantes podem omitir nomes/capacidades, exigindo seleção manual. A detecção de nós não garante por si só captura nem injeção: o acesso real depende de permissões, SELinux, suporte ao helper nativo e disponibilidade de `/dev/uinput`.

Esta atualização é código-fonte. Não foi compilada nem testada em um aparelho Android neste ambiente.
