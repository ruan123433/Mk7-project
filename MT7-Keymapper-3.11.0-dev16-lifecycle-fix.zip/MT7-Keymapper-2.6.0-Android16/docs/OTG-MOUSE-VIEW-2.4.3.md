# MT7 2.4.3 — controles configuráveis e modo de visão independente

## Regras dos botões

- Mouse esquerdo é reservado exclusivamente ao contato de tiro (`FIRE_ID`). Nenhuma outra ação pode sobrescrevê-lo.
- Mouse direito não ativa nem encerra o modo de visão. Ele executa a ação comum configurada no perfil.
- Scroll vertical para cima e para baixo têm ações independentes configuráveis.
- Por padrão, o clique do botão do meio alterna o modo de visão; esse binding pode ser alterado para uma tecla ou outro botão reconhecido pelo mapper.

## Modo de visão

- O movimento relativo do mouse só movimenta o contato `LOOK_ID` enquanto o modo de visão está ativo.
- A ativação é por alternância (toggle), não por segurar o botão direito.
- Eventos de autorepeat do binding de alternância não alternam o modo repetidamente: somente a transição de solto para pressionado é considerada.
- Ao desativar, pausar ou liberar a sessão, o contato de visão é levantado e o callback de suspensão recebe `false`.
- Ao ativar, o callback de suspensão recebe `true`, se a opção estiver ligada.

## Ações mapeáveis nesta etapa

Para botão direito, scroll para cima e scroll para baixo, o perfil aceita `Nenhuma`, `ESPAÇO`, `R` ou `F`. O editor local expõe esses campos como texto; digite exatamente um desses valores.

## Limites importantes

O callback `onPointerSuspensionChanged` é apenas uma integração para a camada de plataforma. Nesta versão ele ainda não implementa captura exclusiva do dispositivo (`EVIOCGRAB`) nem garante ocultação global do cursor sobre o Free Fire. O leitor ainda usa `getevent`; por isso o modo de visão está implementado no pipeline lógico, mas a equivalência completa com o modo FPS do SS KeyMouse Pro/GG Mouse Pro depende da próxima etapa nativa de captura/grab e validação no Android 16.

A preferência de polling Hz continua sendo uma preferência de perfil; não altera a taxa física USB do mouse.
