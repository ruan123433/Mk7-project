# MT7 2.5.2 — Reconexão automática USB

## Comportamento
- Enquanto a sessão OTG está ativa, `PrivilegedOtgMappingSession` monitora os nós Linux selecionados.
- Ao desaparecer mouse ou teclado, a sessão é fechada: leitores são parados, contatos virtuais são liberados e o uinput é encerrado.
- O serviço mantém um supervisor de reconexão com intervalo de 2 segundos.
- O supervisor enumera novamente `getevent -pl`; não presume que os nós mantenham o mesmo número `eventN` após reconectar.
- Quando encontra uma função de mouse e uma função de teclado (no mesmo nó HID composto ou em nós separados), tenta recriar a sessão com o último perfil usado.
- Se Root/Shizuku não estiver disponível, se o HUB ainda estiver enumerando ou se a inicialização falhar, continua aguardando e tenta novamente.
- Ao parar o serviço, o supervisor é cancelado.

## Limitações / validação necessária
- Reconexão exige que Root ou Shizuku permaneça autorizado e que `getevent -pl` consiga enumerar os dispositivos.
- A classificação de mouse/teclado depende das capacidades reportadas pelo kernel Android; alguns receptores HID podem expor nomes/capacidades incomuns.
- O código-fonte não foi compilado nem testado em aparelho nesta execução. Validar conexão, remoção, reconexão, teclado/mouse combinados e separados em Android 16 antes de distribuir APK.
- O aplicativo não controla a negociação USB Power Delivery. O carregamento depende do hub, fonte, cabo e compatibilidade do telefone.
