# MT7 2.5.1 — proteção contra remoção do HUB USB

## O que foi acrescentado
- A sessão OTG verifica a cada 2 segundos se os nós Linux selecionados (`/dev/input/eventN`) continuam acessíveis usando o backend privilegiado ativo (Root ou Shizuku).
- Ao detectar a ausência do mouse ou do teclado selecionado, a sessão é encerrada uma única vez.
- O encerramento fecha os dois leitores, libera os contatos/toques virtuais, interrompe o runtime e fecha a sessão uinput.
- O serviço atualiza a notificação para informar que o HUB foi desconectado e que o mapeamento foi encerrado com segurança.
- O monitor é iniciado somente depois que mouse e teclado (quando selecionado) iniciam a captura. Ele é finalizado junto com a sessão.

## Limitações importantes
- Esta versão **não reconecta automaticamente** nem escolhe novos caminhos `/dev/input/eventN` após reconectar o HUB. É necessário reconectar e iniciar o mapeamento novamente no diagnóstico OTG.
- A verificação depende de Root ou Shizuku continuarem autorizados e conseguirem executar `test -r` no nó.
- A compilação Android e o teste físico em Android 16 ainda precisam ser executados em ambiente com Android SDK/Gradle e no aparelho.
- O aplicativo não controla a negociação USB Power Delivery. A carga simultânea depende do HUB, da fonte e da compatibilidade USB-C/PD do telefone.
