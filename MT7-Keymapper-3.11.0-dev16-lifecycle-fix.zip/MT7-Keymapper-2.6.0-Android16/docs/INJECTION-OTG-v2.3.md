# MT7 v2.3 — transporte de injeção OTG sem Acessibilidade

## Decisão
O método automático tenta Root e, se não estiver disponível, Shizuku. A injeção inicial usa o utilitário Android `input` para emitir tap e swipe.

## Componentes
- `PrivilegedCommandRunner`: execução limitada por timeout através de `su -c` ou `Shizuku.newProcess`.
- `TouchInjectionRepository`: detecção automática e operações `tap`/`swipe`.
- `MT7InputService`: serviço flutuante sem acoplamento com o serviço de acessibilidade.
- Manifest: não declara mais o `MT7AccessibilityService`.

## Limitações conhecidas
- `input tap/swipe` não é um dispositivo touchscreen virtual e não mantém múltiplos contatos independentes.
- Não há ainda leitura global do teclado/mouse OTG em segundo plano. O diagnóstico de `InputDevice` só enumera dispositivos; não é captura global.
- A disponibilidade de `input` e as permissões de injeção variam conforme Android, ROM, SELinux e identidade Shizuku.
- Root tem precedência; Shizuku é fallback. A seleção ocorre no momento da operação.
- Não há validação de compilação ou teste físico nesta entrega.

## Próximo marco
Criar leitor privilegiado de eventos Linux para dispositivos USB, filtrar teclas/botões/movimento, mapear coordenadas e evoluir para multitouch/uinput quando o kernel e as permissões do aparelho permitirem.
