# MT7 2.4.9 — teclas livres (estilo SS KeyMouse)

Converte qualquer tecla do teclado (ou botão extra do mouse) em um toque na tela, como o SS KeyMouse Pro.

## Como usar

1. Abra o laboratório/editor de perfil e procure **TECLAS LIVRES (ESTILO SS KEYMOUSE)**.
2. Escreva uma tecla por item: `TECLA=X,Y`, separando com `;` ou nova linha.
   - X = % da largura (0 esquerda, 100 direita); Y = % da altura (0 topo, 100 base), celular deitado.
   - Exemplo: `G=55,80; 1=40,10; Q=60,30; Mouse lateral 1=90,40`
3. Toque em **Salvar perfil** e inicie o mapeamento em **Avançado > Dispositivos**.

## Regras

- Segurar a tecla = segurar o dedo no ponto; soltar a tecla = soltar o dedo. Autorepeat do teclado não gera toques extras.
- Cada tecla livre usa um dedo próprio (ids 6 em diante), então dá para segurar várias juntas.
- Até 20 teclas livres por perfil. Teclas repetidas, coordenadas fora de 0–100 e texto inválido são ignorados.
- W, A, S, D (joystick) e Mouse esquerdo (tiro) são reservados.
- Uma tecla livre para ESPAÇO, R ou F substitui a posição de fábrica dessas teclas.
- Mouse direito, Mouse lateral 1/2 e Mouse do meio (quando não for o botão de vista) podem ser teclas livres.
- Botão direito e roda do mouse podem disparar qualquer tecla livre (ex.: Ação do botão direito = `G`).
- O delay entre acionamentos do perfil também vale para as teclas livres.

## Teclas reconhecidas

Letras A–Z, Ç, números 0–9, F1–F12, setas (CIMA, BAIXO, ESQUERDA, DIREITA), ESPAÇO, ENTER, TAB, ESC,
BACKSPACE, CAPS, SHIFT/CTRL/ALT (ESQ/DIR), VÍRGULA, PONTO e botões do mouse.

## Validação

Os testes unitários de `KeyTapBindings` e `OtgTouchMappingController` passaram (47 testes de mapeamento/entrada).
A tela Compose e o `ProfileStore` não foram compilados fora do Android Studio/GitHub Actions, e não houve teste em aparelho.
