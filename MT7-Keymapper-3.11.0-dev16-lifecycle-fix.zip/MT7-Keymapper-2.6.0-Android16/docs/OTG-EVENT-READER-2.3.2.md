# MT7 2.3.2 — leitor de eventos OTG

## Implementado nesta revisão
- Novo `OtgInputEventReader`: enumera `/dev/input/eventN` com `getevent -pl`.
- Seleciona Root primeiro e Shizuku como fallback, verificando autorização e existência de `getevent`.
- Abre fluxo contínuo `getevent -t /dev/input/eventN`.
- Faz parsing dos eventos Linux EV_KEY, EV_REL e EV_ABS em hexadecimal.
- Valida o caminho do dispositivo antes de compor o comando shell.
- Inclui testes unitários do parser.

## Limites importantes
- O leitor está implementado como camada reutilizável, mas ainda não foi ligado ao serviço/UI nem ao `MappingRuntime`.
- A enumeração depende do que o backend consegue ler no aparelho. Root normalmente tem acesso maior; Shizuku executa como shell e pode não conseguir abrir todos os nós.
- A implementação usa `getevent`; ainda não cria dispositivo touchscreen virtual (`uinput`) e não injeta toque.
- Ainda falta mapear códigos de teclas/botões e deltas para comandos de mapeamento, tratar hot-plug e garantir encerramento no ciclo de vida do serviço.
- Nenhum evento é injetado ou enviado ao Free Fire por esta classe.

## Teste no Redmi Note 14 4G / Android 16
1. Instale e conceda Root ou Shizuku.
2. Conecte teclado/mouse OTG.
3. Em uma tela de diagnóstico futura, liste dispositivos e selecione o `eventN` correto.
4. Se a lista vier vazia, verificar `getevent -pl` manualmente via backend; pode ser restrição de permissões/SELinux/kernel.

Código-fonte não foi compilado nem validado em hardware nesta revisão.
