# Correções aplicadas (build Android 16)

1. app/build.gradle.kts: `jniLibs.srcDir(layout.buildDirectory.dir(...))` trocado por `jniLibs.srcDir(file("build/generated/mt7-jniLibs"))` (AGP 9 não aceitava).
2. Novo arquivo ShizukuProcess.kt: chama `Shizuku.newProcess` (privado no Shizuku 13.1.5) por reflexão. Usado em PrivilegedCommandRunner.kt, UinputTouchSession.kt e OtgInputEventReader.kt.
3. InputDeviceInspector.kt: `hasSource(` -> `supportsSource(`.
4. MouseDiagnosticsPanel.kt: imports que faltavam (positionChange, isPrimaryPressed, isSecondaryPressed, isTertiaryPressed).
5. MT7App.kt: `inspectShizuku()` -> `inspectShizukuNow()` e `inspectRootPlaceholder()` -> `inspectRootNow()`.

Para compilar: crie `local.properties` com `sdk.dir=/caminho/do/Android/Sdk` e rode `./gradlew assembleDebug` (ou `gradle assembleDebug`).
Requer: JDK 17, platform android-37.1, NDK 28.2.13676358, CMake 3.22.1.
