# Correções de compilação e mapeamento — MT7 Keymapper 3.11.0-dev13

## Compilação
- Declarada diretamente `androidx.lifecycle:lifecycle-runtime:2.11.0`, artefato que fornece `androidx.lifecycle.ViewTreeLifecycleOwner` usado pelo `ComposeView` no painel flutuante.

## Cursor e bolinha
- Cliques esquerdo do mouse capturado passam a ser encaminhados ao painel MT7 ou à bolinha quando a ponta da seta está sobre esses elementos.
- Cliques fora da interface MT7 continuam seguindo o caminho normal do jogo (incluindo o botão de tiro).
- O encaminhamento de toque sintético é feito na thread principal e mantém o par pressionar/soltar.

## Estado do mapeamento OTG
- Separado o estado real da captura EVIOCGRAB da preferência salva.
- Falha na primeira captura oculta a seta MT7 e bloqueia Vista/movimento de cursor até a captura ser restabelecida.
- Falha assíncrona limpa contatos e estados de teclas/joystick sem solicitar nova confirmação EVIOCGRAB na própria thread leitora.
- Desativar captura durante Vista libera o contato de câmera antes de restaurar o ponteiro do sistema.

## Sensibilidade
- Sensibilidade horizontal e vertical agora são independentes nos perfis e no editor. O eixo Y não fica mais limitado pelo valor de X.

## Verificação realizada
- Integridade do ZIP validada.
- Controlador de mapeamento compilado isoladamente com Kotlin e verificado em 8 cenários rápidos.
- A compilação Gradle completa, os testes unitários do app e o teste no aparelho ainda precisam ser executados no GitHub Actions/dispositivo Android.
