package com.mt7.keymapper.core.mapping

import com.mt7.keymapper.core.input.OtgEventMapper
import org.junit.Assert.*
import org.junit.Test

class OtgTouchMappingControllerTest {
    private class FakeOutput : MultiTouchOutput {
        val calls = mutableListOf<String>()
        override fun pointerDown(pointerId: Int, x: Int, y: Int): Boolean { calls += "D:$pointerId:$x:$y"; return true }
        override fun pointerMove(pointerId: Int, x: Int, y: Int): Boolean { calls += "M:$pointerId:$x:$y"; return true }
        override fun pointerUp(pointerId: Int): Boolean { calls += "U:$pointerId"; return true }
        override fun cancelAll(): Boolean { calls += "C"; return true }
    }

    private fun action(kind: OtgEventMapper.Kind, label: String, pressed: Boolean? = null, dx: Int = 0, dy: Int = 0) =
        OtgEventMapper.Action(kind, label, pressed, dx, dy)

    @Test fun wasdCreatesMovesAndReleasesJoystickContact() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400))
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "W", true)))
        assertEquals(2, output.calls.size)
        assertTrue(output.calls[0].startsWith("D:0:")) // neutral center contact
        assertTrue(output.calls[1].startsWith("M:0:")) // then deflect toward W
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "D", true)))
        assertTrue(output.calls.last().startsWith("M:0:"))
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "W", false)))
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "D", false)))
        assertEquals("U:0", output.calls.last())
    }

    @Test fun rightMouseIsNotBoundToViewAndCanMapToConfiguredNormalAction() {
        val output = FakeOutput()
        val layout = TouchLayout(1080, 2400, mouseRightMappedKey = "F")
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse direito", true))
        assertTrue(output.calls.single().startsWith("D:5:"))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse direito", false))
        assertEquals("U:5", output.calls.last())
        assertEquals(2, output.calls.size)
    }

    @Test fun middleClickTogglesViewAndMouseMovementControlsLookIndependentlyOfRightButton() {
        val output = FakeOutput()
        val suspension = mutableListOf<Boolean>()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400), suspension::add)
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dx = 10, dy = -5))
        assertTrue(output.calls.single().startsWith("D:1:"))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse direito", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse direito", false))
        assertEquals(1, output.calls.count { it.startsWith("D:1:") })
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        assertEquals("U:1", output.calls.last())
        assertEquals(listOf(true, false), suspension)
    }

    @Test fun wheelActionsAreConfigurableAndDoNotStealLeftFireButton() {
        val output = FakeOutput()
        val layout = TouchLayout(1080, 2400, scrollUpMappedKey = "R", scrollDownMappedKey = "F")
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.SCROLL, "Roda vertical", dy = 1))
        controller.accept(action(OtgEventMapper.Kind.SCROLL, "Roda vertical", dy = -1))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse esquerdo", true))
        assertTrue(output.calls[0].startsWith("D:4:"))
        assertTrue(output.calls[2].startsWith("D:5:"))
        assertTrue(output.calls[4].startsWith("D:2:"))
    }

    @Test fun fireButtonAndJumpAreIndependentContacts() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse esquerdo", true))
        controller.accept(action(OtgEventMapper.Kind.KEY, "ESPAÇO", true))
        assertTrue(output.calls[0].startsWith("D:2:"))
        assertTrue(output.calls[1].startsWith("D:3:"))
        controller.releaseAll()
        assertEquals("C", output.calls.last())
    }

    @Test fun autorepeatDoesNotCreateDuplicateActionContacts() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400))
        controller.accept(action(OtgEventMapper.Kind.KEY, "R", true))
        controller.accept(action(OtgEventMapper.Kind.KEY, "R", true))
        assertEquals(1, output.calls.size)
    }

    @Test fun configuredKeyComboActivatesTargetOnlyWhenChordIsCompleteAndReleasesOnKeyUp() {
        val output = FakeOutput()
        val layout = TouchLayout(
            1080, 2400,
            keyCombos = listOf(KeyComboBinding(setOf("CTRL ESQ", "1"), "F"))
        )
        val controller = OtgTouchMappingController(output, layout)
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "CTRL ESQ", true)))
        assertTrue(output.calls.isEmpty())
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "1", true)))
        assertEquals(1, output.calls.size)
        assertTrue(output.calls.single().startsWith("D:5:"))
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "CTRL ESQ", false)))
        assertEquals("U:5", output.calls.last())
        assertTrue(controller.accept(action(OtgEventMapper.Kind.KEY, "1", false)))
        assertEquals(2, output.calls.size)
    }

    @Test fun profileBuildsTouchLayoutWithIndependentSensitivityAndFirePosition() {
        val profile = MappingProfile(
            id = "ff", name = "Free Fire", sensitivityX = 2.3f, sensitivityY = 0.7f,
            keyRepeatDelayMs = 120, firePositionX = 0.91f, firePositionY = 0.66f
        )
        val layout = TouchLayout.fromProfile(1000, 2000, profile)
        assertEquals(2.3f, layout.lookSensitivityX, 0.001f)
        assertEquals(0.7f, layout.lookSensitivityY, 0.001f)
        assertEquals(120, layout.keyRepeatDelayMs)
        assertEquals(910, (layout.fireX * layout.width).toInt())
        assertEquals(1320, (layout.fireY * layout.height).toInt())
    }

    @Test fun actionRepeatDelayLimitsRapidReactivationAfterRelease() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400, keyRepeatDelayMs = 500))
        controller.accept(action(OtgEventMapper.Kind.KEY, "R", true))
        controller.accept(action(OtgEventMapper.Kind.KEY, "R", false))
        val callCountAfterFirstTap = output.calls.size
        controller.accept(action(OtgEventMapper.Kind.KEY, "R", true))
        assertEquals(callCountAfterFirstTap, output.calls.size)
    }

    @Test fun fireButtonUsesTheConfiguredHudPosition() {
        val output = FakeOutput()
        val layout = TouchLayout(1000, 2000, fireX = 0.9f, fireY = 0.65f)
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse esquerdo", true))
        assertEquals("D:2:900:1300", output.calls.single())
    }

    @Test fun suspendsPointerOnAimAndRestoresItWhenAimEnds() {
        val output = FakeOutput()
        val suspension = mutableListOf<Boolean>()
        val layout = TouchLayout(1080, 2400, suspendPointerWhileAiming = true)
        val controller = OtgTouchMappingController(output, layout, suspension::add)
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        assertEquals(listOf(true, false), suspension)
    }

    @Test fun profileCarriesPollingRateAndPointerSuspensionPreference() {
        val profile = MappingProfile(
            id = "ff", name = "Free Fire", pollingRateHz = 1000,
            suspendPointerWhileAiming = false,
            viewToggleBinding = "X",
            mouseRightMappedKey = "F",
            scrollUpMappedKey = "R"
        )
        val layout = TouchLayout.fromProfile(1080, 2400, profile)
        assertEquals(1000, layout.pollingRateHz)
        assertFalse(layout.suspendPointerWhileAiming)
        assertEquals("X", layout.viewToggleBinding)
        assertEquals("F", layout.mouseRightMappedKey)
        assertEquals("R", layout.scrollUpMappedKey)
    }


    @Test fun failedExclusiveGrabDoesNotEnterViewModeOrMoveLookContact() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1080, 2400), onPointerSuspensionChanged = { enabled -> !enabled })
        assertFalse(controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true)))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dx = 50, dy = 20))
        assertTrue(output.calls.isEmpty())
    }

    @Test fun lookContactStaysInsideRightSideSafeArea() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1000, 2000, lookX = 0.9f, lookY = 0.5f))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dx = 5, dy = 5))
        controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dx = 10000, dy = 10000))
        assertTrue(output.calls.any { it == "U:1" })
        val rebased = output.calls.last().split(":")
        assertEquals("D", rebased[0])
        assertEquals(1, rebased[1].toInt())
        assertEquals(672, rebased[2].toInt())
        assertEquals(198, rebased[3].toInt())
    }


    @Test fun fractionalMouseDeltasAccumulateAtLowSensitivityInsteadOfBeingLost() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(
            output,
            TouchLayout(1000, 2000, lookX = 0.69f, lookY = 0.43f, lookSensitivityX = 0.1f, lookSensitivityY = 0.1f)
        )
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        repeat(10) { controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dx = 1)) }
        assertEquals("D:1:691:860", output.calls.last())
    }


    @Test fun rightMouseDoesNotChangeLookSensitivityWhileAiming() {
        val output = FakeOutput()
        val layout = TouchLayout(
            1000, 2000, lookX = 0.69f, lookY = 0.43f,
            lookSensitivityX = 1.0f, lookSensitivityY = 1.0f,
            mouseDpi = 1200
        )
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse direito", true))
        controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dx = 10, dy = 0))
        val aimedX = output.calls.last().split(":")[2].toInt()
        assertEquals(700, aimedX) // Same 1.0 sensitivity while aiming.
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse direito", false))
    }

    @Test fun profileTransfersDpiAccelerationAndSmoothingIntoLiveLayout() {
        val profile = MappingProfile(
            id = "ff", name = "Free Fire", mouseDpi = 1200, acceleration = 0.8f,
            smoothing = 0.2f, firePullMultiplier = 2.2f
        )
        val layout = TouchLayout.fromProfile(1080, 2400, profile)
        assertEquals(1200, layout.mouseDpi)
        assertEquals(0.8f, layout.acceleration, 0.001f)
        assertEquals(0.2f, layout.smoothing, 0.001f)
        assertEquals(2.2f, layout.firePullMultiplier, 0.001f)
    }


    @Test fun fastUpwardMousePullWhileFiringGetsMoreGainThanSlowOrNonFiringMove() {
        fun resultingUpwardPixels(fire: Boolean): Int {
            val output = FakeOutput()
            val controller = OtgTouchMappingController(
                output,
                TouchLayout(1000, 2000, lookX = 0.69f, lookY = 0.43f,
                    lookSensitivityX = 1f, lookSensitivityY = 1f,
                    mouseDpi = 1200, acceleration = 2f, smoothing = 0f)
            )
            controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
            controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
            if (fire) controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse esquerdo", true))
            controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dy = -10))
            val y = output.calls.last().split(":").last().toInt()
            return 860 - y
        }
        val firingPull = resultingUpwardPixels(true)
        val normalPull = resultingUpwardPixels(false)
        assertTrue("firing upward pull should gain more than normal movement", firingPull > normalPull)
    }

    @Test fun firePullMultiplierOnlyAmplifiesUserDrivenUpwardCameraMotionWhileFiring() {
        fun upwardPixels(multiplier: Float, fire: Boolean): Int {
            val output = FakeOutput()
            val controller = OtgTouchMappingController(
                output,
                TouchLayout(1000, 2000, lookX = 0.69f, lookY = 0.43f,
                    lookSensitivityX = 1f, lookSensitivityY = 1f,
                    mouseDpi = 1200, acceleration = 0f, firePullMultiplier = multiplier)
            )
            controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
            controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
            if (fire) controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse esquerdo", true))
            controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dy = -10))
            val y = output.calls.last().split(":").last().toInt()
            return 860 - y
        }
        val standardWhileFiring = upwardPixels(1f, true)
        val strongerWhileFiring = upwardPixels(2f, true)
        val strongerWithoutFiring = upwardPixels(2f, false)
        assertTrue(strongerWhileFiring > standardWhileFiring)
        assertEquals(standardWhileFiring, strongerWithoutFiring)
    }

    @Test fun firingContactRemainsHeldUntilLeftMouseRelease() {
        val output = FakeOutput()
        val controller = OtgTouchMappingController(output, TouchLayout(1000, 2000))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse esquerdo", true))
        controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dy = -5))
        assertFalse(output.calls.contains("U:2"))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse esquerdo", false))
        assertEquals("U:2", output.calls.last())
    }

    @Test fun softwareCursorStaysVisibleOutsideVistaUntilMapperRelease() {
        val output = FakeOutput()
        val cursor = mutableListOf<Boolean>()
        val capture = mutableListOf<Boolean>()
        val controller = OtgTouchMappingController(
            output, TouchLayout(1080, 2400),
            onPointerSuspensionChanged = { capture += it; true },
            onSoftwareCursorVisibilityChanged = { cursor += it }
        )
        assertTrue(controller.setPointerSuspensionEnabled(true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        assertEquals(listOf(true), cursor)
        assertEquals(listOf(true), capture)
        assertTrue(controller.releaseAll())
        assertEquals(listOf(true, false), cursor)
        assertEquals(listOf(true, false), capture)
    }

    @Test fun disablingPointerCaptureDuringAimHidesSoftwareCursorAndCanReenableIt() {
        val output = FakeOutput()
        val cursor = mutableListOf<Boolean>()
        val capture = mutableListOf<Boolean>()
        val controller = OtgTouchMappingController(
            output, TouchLayout(1080, 2400),
            onPointerSuspensionChanged = { capture += it; true },
            onSoftwareCursorVisibilityChanged = { cursor += it }
        )
        assertTrue(controller.setPointerSuspensionEnabled(true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        assertTrue(controller.setPointerSuspensionEnabled(false))
        assertTrue(controller.setPointerSuspensionEnabled(true))
        assertEquals(listOf(true, false, true), cursor)
        assertEquals(listOf(true, false, true), capture)
    }

    @Test fun failedDynamicPointerCaptureChangeKeepsPreviousPreferenceAndCursorState() {
        val output = FakeOutput()
        val cursor = mutableListOf<Boolean>()
        val controller = OtgTouchMappingController(
            output, TouchLayout(1080, 2400),
            onPointerSuspensionChanged = { enabled -> enabled }, // captura liga, mas a liberação dinâmica falha
            onSoftwareCursorVisibilityChanged = { cursor += it }
        )
        assertTrue(controller.setPointerSuspensionEnabled(true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse do meio", false))
        assertFalse(controller.setPointerSuspensionEnabled(false))
        assertEquals(listOf(true), cursor)
        controller.releaseAll()
        assertEquals(listOf(true, false), cursor)
    }

    @Test fun independentCursorTracksMouseOutsideVista() {
        val output = FakeOutput()
        val moves = mutableListOf<Pair<Int, Int>>()
        val controller = OtgTouchMappingController(
            output, TouchLayout(1080, 2400),
            onSoftwareCursorMoved = { dx, dy -> moves += dx to dy }
        )
        controller.accept(action(OtgEventMapper.Kind.POINTER_MOVE, "Movimento", dx = 7, dy = -4))
        assertEquals(listOf(7 to -4), moves)
        assertTrue(output.calls.isEmpty())
    }

    @Test fun rightMouseCannotBeChosenAsViewToggleBinding() {
        val error = runCatching { TouchLayout(1080, 2400, viewToggleBinding = "Mouse direito") }.exceptionOrNull()
        assertNotNull(error)
    }


    @Test fun freeKeyHoldsFingerAtConfiguredPointUntilReleased() {
        val output = FakeOutput()
        val layout = TouchLayout(2400, 1080, keyTaps = listOf(KeyTapBinding("G", 0.5f, 0.25f)))
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.KEY, "G", true))
        controller.accept(action(OtgEventMapper.Kind.KEY, "G", true)) // autorepeat must not tap again
        controller.accept(action(OtgEventMapper.Kind.KEY, "G", false))
        assertEquals(listOf("D:6:1200:270", "U:6"), output.calls)
    }

    @Test fun eachFreeKeyGetsItsOwnFingerSoTheyCanBeHeldTogether() {
        val output = FakeOutput()
        val layout = TouchLayout(1000, 1000, keyTaps = listOf(KeyTapBinding("1", 0.1f, 0.1f), KeyTapBinding("2", 0.2f, 0.2f)))
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.KEY, "1", true))
        controller.accept(action(OtgEventMapper.Kind.KEY, "2", true))
        assertEquals(listOf("D:6:100:100", "D:7:200:200"), output.calls)
    }

    @Test fun freeKeyOverridesBuiltInSpacePosition() {
        val output = FakeOutput()
        val layout = TouchLayout(1000, 1000, keyTaps = listOf(KeyTapBinding("ESPAÇO", 0.3f, 0.4f)))
        OtgTouchMappingController(output, layout).accept(action(OtgEventMapper.Kind.KEY, "ESPAÇO", true))
        assertEquals(listOf("D:6:300:400"), output.calls)
    }

    @Test fun sideMouseButtonAndRightMouseCanBeFreeKeys() {
        val output = FakeOutput()
        val layout = TouchLayout(1000, 1000, keyTaps = listOf(KeyTapBinding("Mouse lateral 1", 0.9f, 0.4f), KeyTapBinding("Mouse direito", 0.8f, 0.3f)))
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse lateral 1", true))
        controller.accept(action(OtgEventMapper.Kind.MOUSE_BUTTON, "Mouse direito", true))
        assertEquals(listOf("D:6:900:400", "D:7:800:300"), output.calls)
    }

    @Test fun rightMouseAndWheelCanTriggerAFreeKey() {
        val output = FakeOutput()
        val layout = TouchLayout(1000, 1000, mouseRightMappedKey = "G", scrollUpMappedKey = "G",
            keyTaps = listOf(KeyTapBinding("G", 0.5f, 0.5f)))
        val controller = OtgTouchMappingController(output, layout)
        controller.accept(action(OtgEventMapper.Kind.SCROLL, "Roda vertical", dy = 1))
        assertEquals(listOf("D:6:500:500", "U:6"), output.calls)
    }
}
