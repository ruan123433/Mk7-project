plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.mt7.keymapper"
    compileSdk = 37

    sourceSets {
        getByName("main") {
            // CMake copies the standalone PIE helpers here after compiling each ABI.
            // jniLibs packaging places them in nativeLibraryDir with executable permissions.
            jniLibs.srcDir(file("build/generated/mt7-jniLibs"))
        }
    }

    packaging {
        jniLibs {
            // The privileged helpers are executed as standalone PIE binaries, not dlopened.
            useLegacyPackaging = true
        }
    }

    defaultConfig {
        applicationId = "com.mt7.keymapper"
        minSdk = 29
        targetSdk = 36
        versionCode = 53
        versionName = "3.11.0-dev14"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        externalNativeBuild {
            cmake {
                cppFlags += listOf("-std=c++17", "-Wall", "-Wextra")
            }
        }

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.09.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.11.0")
    // ViewTreeLifecycleOwner is part of lifecycle-runtime (Android API).
    implementation("androidx.lifecycle:lifecycle-runtime:2.11.0")
    // Android-specific ViewTreeLifecycleOwner API used by the floating Compose editor.
    implementation("androidx.lifecycle:lifecycle-runtime-android:2.11.0")

    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")

    debugImplementation("androidx.compose.ui:ui-tooling")
    testImplementation("junit:junit:4.13.2")
}
