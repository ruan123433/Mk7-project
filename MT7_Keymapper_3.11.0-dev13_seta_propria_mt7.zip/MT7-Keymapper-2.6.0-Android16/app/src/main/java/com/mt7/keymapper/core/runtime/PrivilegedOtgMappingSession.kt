package com.mt7.keymapper.core.runtime

import android.content.Context
import android.provider.Settings
import com.mt7.keymapper.core.activation.BackendKind
import com.mt7.keymapper.core.activation.BackendStatus
import com.mt7.keymapper.core.injection.UinputTouchSession
import com.mt7.keymapper.core.input.OtgEventMapper
import com.mt7.keymapper.core.input.OtgInputEventReader
import com.mt7.keymapper.core.mapping.OtgTouchMappingController
import com.mt7.keymapper.core.mapping.MappingProfile
import com.mt7.keymapper.core.mapping.TouchLayout
import java.io.Closeable
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.RejectedExecutionException

/**
 * Owns the complete privileged OTG -> mapping -> uinput pipeline.
 * Caller supplies the selected Linux event node and the actual display pixel size.
 */
class PrivilegedOtgMappingSession private constructor(
    private val reader: OtgInputEventReader,
    private val keyboardReader: OtgInputEventReader?,
    private val touch: UinputTouchSession,
    private val runtime: MappingRuntime,
    private val mapper: OtgEventMapper,
    private val controller: OtgTouchMappingController,
    private val monitoredPaths: List<String>,
    private val onDeviceDisconnected: (String) -> Unit
) : Closeable {
    private val closed = AtomicBoolean(false)
    private val disconnectReported = AtomicBoolean(false)
    /** One ordered consumer merges mouse and keyboard callbacks into a single event stream. */
    private val inputEventQueue = ThreadPoolExecutor(
        1, 1, 0L, TimeUnit.MILLISECONDS, ArrayBlockingQueue(2048),
        { task -> Thread(task, "MT7-Input-Engine").apply { isDaemon = true } },
        ThreadPoolExecutor.AbortPolicy()
    )
    private val deviceMonitor = java.util.concurrent.Executors.newSingleThreadScheduledExecutor { task ->
        Thread(task, "MT7-USB-Watch").apply { isDaemon = true }
    }

    /** Runtime toggle exposed by the floating control panel. */
    fun setPointerSuspensionEnabled(enabled: Boolean): Boolean =
        controller.setPointerSuspensionEnabled(enabled)

    private fun startDeviceMonitor() {
        deviceMonitor.scheduleWithFixedDelay({
            if (closed.get() || disconnectReported.get()) return@scheduleWithFixedDelay
            val missing = monitoredPaths.firstOrNull { path ->
                val pathReader = if (path == monitoredPaths.first()) reader else keyboardReader ?: reader
                !pathReader.isDevicePresent(path)
            }
            if (missing != null) reportDisconnect(missing)
        }, 1, 2, java.util.concurrent.TimeUnit.SECONDS)
    }

    /** A capture process can die while its /dev/input node still exists. Treat that as a
     * disconnect too; checking only test -r would otherwise leave a dead session running.
     */
    private fun reportDisconnect(path: String) {
        if (!closed.get() && disconnectReported.compareAndSet(false, true)) {
            close()
            runtime.backendHealth.recordFailure("Dispositivo de entrada desconectado: $path")
            runCatching { onDeviceDisconnected(path) }
        }
    }

    fun snapshot(): RuntimeSnapshot = runtime.snapshot()
    /** Live pipeline counters; timings cover processing, not physical device-to-screen latency. */
    fun inputDiagnostics(): InputEngineSnapshot = runtime.diagnostics.snapshot()
    /** Backend faults are observable by the UI; recovery always requires an explicit user action. */
    fun backendHealth(): BackendHealthSnapshot = runtime.backendHealth.snapshot()
    fun resetInputDiagnostics() = runtime.diagnostics.reset()
    fun injectionBackend(): String = touch.backend
    fun queuedInputEvents(): Int = inputEventQueue.queue.size

    private fun enqueueInputEvent(event: OtgInputEventReader.InputEvent, sourceMapper: OtgEventMapper) {
        if (closed.get()) return
        try {
            inputEventQueue.execute {
                if (!closed.get()) runtime.processAndInject(event, sourceMapper, controller)
            }
        } catch (_: RejectedExecutionException) {
            // Queue saturation must fail safe: stop consuming stale movement and release every contact.
            if (!closed.get()) {
                sourceMapper.reset()
                runtime.backendHealth.recordFailure("Fila de entrada saturada; eventos descartados para evitar atraso e ações obsoletas.")
                runtime.pauseAndRelease(controller)
            }
        }
    }

    @Synchronized
    fun pause(): RuntimeSnapshot {
        inputEventQueue.queue.clear()
        val paused = runtime.pause()
        controller.releaseAll()
        return paused
    }

    @Synchronized
    fun resume(): RuntimeSnapshot {
        if (!controller.resumePointerCapture()) {
            runtime.backendHealth.recordFailure("Não foi possível reativar a captura exclusiva do mouse ao retomar o mapeador.")
            return runtime.snapshot()
        }
        return runtime.resume()
    }

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        inputEventQueue.shutdownNow()
        reader.close()
        keyboardReader?.close()
        runtime.stop()
        controller.releaseAll()
        mapper.reset()
        touch.close()
        deviceMonitor.shutdownNow()
    }

    companion object {
        data class StartResult(val session: PrivilegedOtgMappingSession?, val detail: String)

        fun start(
            context: Context,
            devicePath: String,
            displayWidth: Int,
            displayHeight: Int,
            reader: OtgInputEventReader = OtgInputEventReader(),
            keyboardDevicePath: String? = null,
            keyboardReader: OtgInputEventReader? = keyboardDevicePath?.let { OtgInputEventReader() },
            runtime: MappingRuntime = MappingRuntime(),
            mapper: OtgEventMapper = OtgEventMapper(),
            profile: MappingProfile? = null,
            layoutFactory: (Int, Int) -> TouchLayout = { width, height -> TouchLayout(width, height) },
            onPointerSuspensionChanged: (Boolean) -> Unit = {},
            onDeviceDisconnected: (String) -> Unit = {},
            onSoftwareCursorVisibilityChanged: (Boolean) -> Unit = {},
            onSoftwareCursorMoved: (Int, Int) -> Unit = { _, _ -> }
        ): StartResult {
            require(displayWidth > 0 && displayHeight > 0)
            val layout = profile?.let {
                TouchLayout.fromProfile(displayWidth - 1, displayHeight - 1, it)
            } ?: layoutFactory(displayWidth - 1, displayHeight - 1)
            // Never grab and hide Android's hardware cursor unless MT7 can draw
            // its own independent pointer above the game.
            if (layout.suspendPointerWhileAiming && !Settings.canDrawOverlays(context)) {
                return StartResult(null, "Permita 'Exibir sobre outros apps' para o MT7 mostrar sua seta própria antes de ocultar a seta do Android.")
            }
            val touchResult = UinputTouchSession.start(
                context = context,
                maxX = displayWidth - 1,
                maxY = displayHeight - 1,
                slots = 10
            )
            val touch = touchResult.session ?: return StartResult(null, touchResult.detail)
            val controller = OtgTouchMappingController(
                touch, layout,
                onPointerSuspensionChanged = { aiming ->
                    // Only the mouse node is grabbed. Keyboard remains available for WASD.
                    reader.setExclusiveGrab(aiming)
                },
                onSoftwareCursorVisibilityChanged = onSoftwareCursorVisibilityChanged,
                onSoftwareCursorMoved = onSoftwareCursorMoved
            )
            val monitoredPaths = listOfNotNull(devicePath, keyboardDevicePath?.takeIf { it != devicePath })
            val session = PrivilegedOtgMappingSession(
                reader, keyboardReader, touch, runtime, mapper, controller,
                monitoredPaths, onDeviceDisconnected
            )
            val kind = if (touch.backend.equals("Root", ignoreCase = true)) BackendKind.ROOT else BackendKind.SHIZUKU
            runtime.selectBackend(BackendStatus(kind, true, touchResult.detail))
            runtime.start()
            val grabHelper = java.io.File(context.applicationInfo.nativeLibraryDir, "libmt7-input-grab.so").absolutePath
            val capture = reader.startNativeCapture(
                devicePath = devicePath,
                helperPath = grabHelper,
                onEvent = { event ->
                    session.enqueueInputEvent(event, mapper)
                },
                onStopped = {
                    if (!session.closed.get()) session.reportDisconnect(devicePath)
                },
                onGrabStatus = { active, error ->
                    onPointerSuspensionChanged(active)
                    if (!active && error != null && !session.closed.get()) {
                        controller.abortViewMode()
                        runtime.backendHealth.recordFailure("Falha ao ativar captura exclusiva do mouse: ${error.take(180)}")
                        runtime.pauseAndRelease(controller)
                    }
                }
            )
            if (capture is OtgInputEventReader.StartResult.Failed) {
                runtime.backendHealth.recordFailure("Falha ao iniciar captura OTG: ${capture.reason}")
                session.close()
                return StartResult(null, "uinput criado, mas captura OTG falhou: ${capture.reason}")
            }
            if (keyboardDevicePath != null && keyboardReader != null && keyboardDevicePath != devicePath) {
                // A split HID keyboard has its own SYN_REPORT stream. Keep its
                // relative-axis accumulator separate from the mouse's frame state.
                val keyboardMapper = OtgEventMapper()
                val keyboardCapture = keyboardReader.startNativeCapture(
                    devicePath = keyboardDevicePath,
                    helperPath = grabHelper,
                    onEvent = { event ->
                        session.enqueueInputEvent(event, keyboardMapper)
                    },
                    onStopped = {
                        if (!session.closed.get()) session.reportDisconnect(keyboardDevicePath)
                    }
                )
                if (keyboardCapture is OtgInputEventReader.StartResult.Failed) {
                    runtime.backendHealth.recordFailure("Falha ao iniciar captura do teclado: ${keyboardCapture.reason}")
                    session.close()
                    return StartResult(null, "Mouse capturado, mas teclado OTG falhou: ${keyboardCapture.reason}")
                }
            }
            val keyboardDetail = when {
                keyboardDevicePath != null && keyboardDevicePath != devicePath -> "; teclado capturado separadamente em $keyboardDevicePath"
                keyboardDevicePath == devicePath -> "; mouse e teclado capturados juntos em $devicePath"
                else -> "; teclado não selecionado — selecione o nó correspondente no diagnóstico OTG"
            }
            // Match the mapper behavior used by dedicated keymappers: take exclusive
            // ownership of the mouse as soon as mapping starts, hide Android's cursor,
            // and show MT7's own independent overlay cursor instead.
            if (!controller.setPointerSuspensionEnabled(layout.suspendPointerWhileAiming)) {
                val detail = reader.captureError() ?: "o Android não confirmou EVIOCGRAB"
                session.close()
                return StartResult(null, "Não foi possível ativar a seta independente do MT7: $detail")
            }
            session.startDeviceMonitor()
            return StartResult(session, "${touchResult.detail}; mouse EVIOCGRAB em $devicePath$keyboardDetail; seta MT7 independente ativa; monitor USB ativo")
        }
    }
}
