package com.mt7.keymapper.service

import android.content.Context
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import com.mt7.keymapper.ui.FloatingMappingEditor
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.SystemClock
import android.view.Gravity
import android.view.ViewGroup
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.SeekBar
import android.widget.ScrollView
import android.provider.Settings

/** Floating MT7 launcher and mapping controls. */
internal class FloatingBallController(
    private val context: Context,
    private val onStop: () -> Unit,
    private val onMappingEnabledChanged: (Boolean) -> Unit,
    private val onPointerSuspensionChanged: (Boolean) -> Boolean
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val visionPrefs = context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE)
    private var ball: TextView? = null
    private var cursorView: View? = null
    private var cursorParams: WindowManager.LayoutParams? = null
    // Keep the MT7 cursor's own last position, normalized so it survives rotation.
    private var cursorX = visionPrefs.getFloat("mt7_cursor_x_norm", 0.5f).coerceIn(0f, 1f) *
        context.resources.displayMetrics.widthPixels
    private var cursorY = visionPrefs.getFloat("mt7_cursor_y_norm", 0.5f).coerceIn(0f, 1f) *
        context.resources.displayMetrics.heightPixels
    private var paused = false
    private var pointerSuspensionEnabled = visionPrefs.getBoolean("suspend_pointer_while_aiming", true)
    private var lastTapAt = 0L

    fun show() {
        if (ball != null || !Settings.canDrawOverlays(context)) return
        val view = TextView(context).apply {
            text = "M7"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = circleBackground()
            contentDescription = "MT7 Keymouse. Toque para abrir a central de controles; arraste para mover."
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(58), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18)
            y = dp(180)
        }
        view.setOnTouchListener { _, event -> handleBallTouch(event, params) }
        try {
            windowManager.addView(view, params)
            ball = view
        } catch (_: SecurityException) {
            ball = null
        } catch (_: IllegalStateException) {
            ball = null
        }
    }

    fun hide() {
        closePanel()
        hideGameCursor()
        ball?.let { runCatching { windowManager.removeView(it) } }
        ball = null
    }

    /** Shows MT7's own software cursor while the physical Android pointer is captured. */
    fun showGameCursor() {
        if (cursorView != null || !Settings.canDrawOverlays(context)) return
        val cursorSize = visionPrefs.getFloat("cursor_size_dp", 34f).coerceIn(18f, 64f)
        val cursorWidth = (cursorSize * context.resources.displayMetrics.density).toInt().coerceAtLeast(1)
        val cursorHeight = (cursorSize * 1.24f * context.resources.displayMetrics.density).toInt().coerceAtLeast(1)
        val cursor = Mt7SoftwareCursorView(context, cursorSize / 34f)
        val maxX = (context.resources.displayMetrics.widthPixels - cursorWidth).coerceAtLeast(0)
        val maxY = (context.resources.displayMetrics.heightPixels - cursorHeight).coerceAtLeast(0)
        cursorX = cursorX.coerceIn(0f, maxX.toFloat())
        cursorY = cursorY.coerceIn(0f, maxY.toFloat())
        val params = WindowManager.LayoutParams(
            cursorWidth, cursorHeight, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = cursorX.toInt()
            y = cursorY.toInt()
        }
        runCatching {
            windowManager.addView(cursor, params)
            cursorView = cursor
            cursorParams = params
        }
    }

    /** Applies relative USB mouse deltas to the independent on-screen cursor. */
    fun moveGameCursor(dx: Int, dy: Int) {
        val view = cursorView ?: return
        val params = cursorParams ?: return
        view.post {
            if (cursorView !== view || cursorParams !== params) return@post
            val cursorSize = visionPrefs.getFloat("cursor_size_dp", 34f).coerceIn(18f, 64f)
            val cursorWidth = dp(cursorSize.toInt())
            val cursorHeight = dp((cursorSize * 1.24f).toInt())
            val speed = visionPrefs.getFloat("cursor_speed", 1f).coerceIn(0.25f, 3f)
            val maxX = (context.resources.displayMetrics.widthPixels - cursorWidth).coerceAtLeast(0)
            val maxY = (context.resources.displayMetrics.heightPixels - cursorHeight).coerceAtLeast(0)
            cursorX = (cursorX + dx * speed).coerceIn(0f, maxX.toFloat())
            cursorY = (cursorY + dy * speed).coerceIn(0f, maxY.toFloat())
            params.x = cursorX.toInt()
            params.y = cursorY.toInt()
            runCatching { windowManager.updateViewLayout(view, params) }
        }
    }

    fun hideGameCursor() {
        val screenWidth = context.resources.displayMetrics.widthPixels.coerceAtLeast(1).toFloat()
        val screenHeight = context.resources.displayMetrics.heightPixels.coerceAtLeast(1).toFloat()
        visionPrefs.edit()
            .putFloat("mt7_cursor_x_norm", (cursorX / screenWidth).coerceIn(0f, 1f))
            .putFloat("mt7_cursor_y_norm", (cursorY / screenHeight).coerceIn(0f, 1f))
            .apply()
        cursorView?.let { runCatching { windowManager.removeView(it) } }
        cursorView = null
        cursorParams = null
    }

    fun setPaused(value: Boolean) {
        paused = value
        ball?.text = if (paused) "Ⅱ" else "MT7"
        onMappingEnabledChanged(!paused)
    }

    private fun handleBallTouch(event: MotionEvent, params: WindowManager.LayoutParams): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                startX = params.x
                startY = params.y
                moved = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - downX).toInt()
                val dy = (event.rawY - downY).toInt()
                if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                if (moved) {
                    params.x = startX + dx
                    params.y = startY + dy
                    ball?.let { runCatching { windowManager.updateViewLayout(it, params) } }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) {
                    togglePanel()
                }
                return true
            }
        }
        return true
    }

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    private fun togglePanel() {
        if (activePanelView != null) {
            closePanel()
            return
        }
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(11), dp(12), dp(11))
            background = roundedBackground(Color.rgb(17, 18, 25), dp(18).toFloat())
        }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), dp(1), dp(2), dp(9))
        }
        val brand = TextView(context).apply {
            text = "◆  MT7 KEYMOUSE\n     CENTRAL DE CONTROLES"
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(0f, 0.92f)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(43), 1f))
        header.addView(TextView(context).apply {
            text = if (paused) "● PAUSADO" else "● MAPEADOR ATIVO"
            textSize = 9f
            setTextColor(if (paused) Color.rgb(255, 185, 70) else Color.rgb(92, 220, 150))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(3), 0, dp(5), 0)
        })
        header.addView(TextView(context).apply {
            text = "×"
            textSize = 25f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setOnClickListener { closePanel() }
        }, LinearLayout.LayoutParams(dp(32), dp(40)))
        content.addView(header)

        fun addTileRow(left: Pair<String, () -> Unit>, right: Pair<String, () -> Unit>) {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(menuTile(left.first, left.second), LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(4) })
            row.addView(menuTile(right.first, right.second), LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(4) })
            content.addView(row)
            content.addView(View(context), LinearLayout.LayoutParams(1, dp(5)))
        }
        val openEditor: () -> Unit = { showEditorPanel("VISTA") }
        // Mapping controls are edited in-place in the floating panel; the app remains for activation and permissions.
        addTileRow("⌖\nEDITAR KEYMAP" to openEditor, "⚙\nCONFIGURAÇÕES" to { showVisionSettings() })
        addTileRow("⌨\nPERFIS / TECLAS" to { showEditorPanel("PERFIL") }, "🎮\nPOSIÇÕES / JOYSTICK" to { showEditorPanel("JOYSTICK") })
        addTileRow("🎯\nVISTA / MIRA" to { showEditorPanel("VISTA") }, "🔥\nBOTÃO DE TIRO" to { showEditorPanel("TIRO") })
        addTileRow(
            (if (pointerSuspensionEnabled) "⌖\nSETA PRÓPRIA MT7 ATIVA" else "⌖\nUSAR SETA DO ANDROID") to {
                val next = !pointerSuspensionEnabled
                if (onPointerSuspensionChanged(next)) {
                    pointerSuspensionEnabled = next
                    context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE)
                        .edit().putBoolean("suspend_pointer_while_aiming", next).apply()
                }
                closePanel()
                togglePanel()
            },
            (if (paused) "▶\nATIVAR MAPEAMENTO" else "Ⅱ\nSUSPENDER MAPEAMENTO") to { setPaused(!paused); closePanel(); togglePanel() }
        )
        addTileRow("🧪\nOTIMIZAÇÃO" to { showEditorPanel("OTIMIZAR") }, "↙\nRECOLHER CENTRAL" to { closePanel() })
        content.addView(TextView(context).apply {
            text = "Arraste a bolinha para reposicionar • Toque para abrir"
            textSize = 9f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        })

        val screenW = context.resources.displayMetrics.widthPixels
        val screenH = context.resources.displayMetrics.heightPixels
        val ballParams = ball?.layoutParams as? WindowManager.LayoutParams
        val panelW = dp(286).coerceAtMost((screenW - dp(16)).coerceAtLeast(dp(240)))
        val panelH = (screenH - dp(24)).coerceAtMost(dp(500))
        val estimatedH = panelH
        val x = (ballParams?.x ?: dp(12)).coerceIn(0, (screenW - panelW).coerceAtLeast(0))
        val ballY = ballParams?.y ?: dp(180)
        val y = if (ballY + dp(70) + estimatedH < screenH) ballY + dp(66)
                else (ballY - estimatedH - dp(8)).coerceAtLeast(dp(8))
        val p = WindowManager.LayoutParams(
            panelW, panelH, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
        val scroll = ScrollView(context).apply {
            isFillViewport = true
            addView(content, ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        try {
            windowManager.addView(scroll, p)
            activePanelView = scroll
        } catch (_: Exception) {
            activePanelView = null
        }
    }

    private fun menuTile(label: String, action: () -> Unit): TextView = TextView(context).apply {
        text = label
        textSize = 11f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(5), dp(4), dp(5), dp(4))
        background = roundedBackground(Color.rgb(35, 36, 45), dp(10).toFloat())
        isClickable = true
        isFocusable = true
        setOnClickListener { action() }
    }


    /** Opens the real profile editor inside a focusable overlay instead of navigating back to the app. */
    private fun showEditorPanel(section: String) {
        closePanel()
        if (!Settings.canDrawOverlays(context)) {
            showMessage("Permissão de sobreposição necessária para abrir o editor flutuante.")
            return
        }
        val screenWidth = context.resources.displayMetrics.widthPixels
        val screenHeight = context.resources.displayMetrics.heightPixels
        val compactWidth = dp(340).coerceAtMost((screenWidth - dp(16)).coerceAtLeast(dp(240)))
        val compactHeight = dp(570).coerceAtMost((screenHeight - dp(24)).coerceAtLeast(dp(280)))
        val ballParams = ball?.layoutParams as? WindowManager.LayoutParams
        val compactX = (ballParams?.x ?: dp(12)).coerceIn(0, (screenWidth - compactWidth).coerceAtLeast(0))
        val compactY = (ballParams?.y ?: dp(120)).coerceIn(dp(8), (screenHeight - compactHeight).coerceAtLeast(dp(8)))

        lateinit var compose: ComposeView
        compose = ComposeView(context).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                FloatingMappingEditor(
                    context = context,
                    initialSection = section,
                    onClose = {
                        closePanel()
                        togglePanel()
                    },
                    onPositionModeChanged = { fullScreen ->
                        val current = compose.layoutParams as? WindowManager.LayoutParams
                        if (current != null && compose.isAttachedToWindow) {
                            current.width = if (fullScreen) screenWidth else compactWidth
                            current.height = if (fullScreen) screenHeight else compactHeight
                            current.x = if (fullScreen) 0 else compactX
                            current.y = if (fullScreen) 0 else compactY
                            runCatching { windowManager.updateViewLayout(compose, current) }
                        }
                    }
                )
            }
        }
        val positioningMode = section == "POSICIONAR"
        val params = WindowManager.LayoutParams(
            if (positioningMode) screenWidth else compactWidth,
            if (positioningMode) screenHeight else compactHeight,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (positioningMode) 0 else compactX
            y = if (positioningMode) 0 else compactY
        }
        runCatching {
            windowManager.addView(compose, params)
            activePanelView = compose
        }.onFailure { showMessage("Não foi possível abrir o editor flutuante: ${it.message}") }
    }

    /** Local tuning UI for independent pointer sensitivity and polling preference. */
    private fun showVisionSettings() {
        closePanel()
        val prefs = context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE)
        val rates = listOf(125, 250, 500, 1000)
        var selectedRate = prefs.getInt("polling_hz", 250).let { if (it in rates) it else 250 }
        var suspendPointer = prefs.getBoolean("suspend_pointer_while_aiming", true)
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBackground(Color.rgb(15, 24, 42), dp(18).toFloat())
        }
        content.addView(TextView(context).apply {
            text = "CONFIGURAÇÕES GERAIS"
            textSize = 15f
            setTextColor(Color.rgb(80, 180, 255))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        content.addView(TextView(context).apply {
            text = "Frequência, tamanho e velocidade da seta. Sensibilidade fica em Editar Keymap > Vista."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(6), 0, dp(8))
        })
        addFloatControl(content, "Tamanho da seta", prefs.getFloat("cursor_size_dp", 34f), "cursor_size_dp", 18f, 64f, 46)
        addFloatControl(content, "Velocidade da seta", prefs.getFloat("cursor_speed", 1f), "cursor_speed", 0.25f, 3f, 55)

        val rateLabel = TextView(context).apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        fun refreshRate() { rateLabel.text = "Preferência selecionada: $selectedRate Hz" }
        refreshRate()
        content.addView(rateLabel)
        val rateRow = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        rates.forEach { hz ->
            rateRow.addView(Button(context).apply {
                text = hz.toString()
                textSize = 10f
                isAllCaps = false
                setOnClickListener {
                    selectedRate = hz
                    prefs.edit().putInt("polling_hz", hz).apply()
                    refreshRate()
                }
            }, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        content.addView(rateRow)
        val pointerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(4))
        }
        pointerRow.addView(TextView(context).apply {
            text = "Usar seta própria do MT7"
            textSize = 12f
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        val pointerToggle = android.widget.Switch(context).apply {
            isChecked = suspendPointer
            setOnCheckedChangeListener { _, checked ->
                if (onPointerSuspensionChanged(checked)) {
                    suspendPointer = checked
                    prefs.edit().putBoolean("suspend_pointer_while_aiming", checked).apply()
                } else {
                    isChecked = suspendPointer
                    showMessage("Não foi possível alterar a captura da seta agora.")
                }
            }
        }
        pointerRow.addView(pointerToggle)
        content.addView(pointerRow)
        content.addView(TextView(context).apply {
            text = "Quando ativada, o MT7 captura o mouse durante todo o mapeamento, oculta a seta do Android e mostra uma seta própria sobre o jogo. Ao pausar ou parar o mapeador, o mouse é liberado."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(8))
        })
        content.addView(TextView(context).apply {
            text = "Hz é salvo como preferência. O leitor atual é orientado a eventos; a taxa USB real depende do mouse e do Android."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(6), 0, dp(8))
        })
        content.addView(menuButton("ABRIR VISTA / KEYMAP NA CENTRAL") { showEditorPanel("VISTA") })
        content.addView(menuButton("VOLTAR À CENTRAL") { closePanel(); togglePanel() })

        val scroll = ScrollView(context).apply { addView(content) }
        val params = WindowManager.LayoutParams(
            dp(300), dp(460), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val ballParams = ball?.layoutParams as? WindowManager.LayoutParams
            x = (ballParams?.x ?: dp(18)).coerceAtMost((context.resources.displayMetrics.widthPixels - dp(310)).coerceAtLeast(0))
            y = (ballParams?.y ?: dp(180)) + dp(66)
        }
        try {
            windowManager.addView(scroll, params)
            activePanelView = scroll
        } catch (_: Exception) {
            activePanelView = null
        }
    }

    private var activePanelView: View? = null

    private fun addFloatControl(parent: LinearLayout, label: String, initial: Float, key: String, min: Float, maxValue: Float, steps: Int) {
        val prefs = context.getSharedPreferences("mt7_vision", Context.MODE_PRIVATE)
        val valueText = TextView(context).apply {
            text = "$label: ${"%.2f".format(java.util.Locale.US, initial)}"
            textSize = 12f
            setTextColor(Color.WHITE)
        }
        parent.addView(valueText)
        parent.addView(SeekBar(context).apply {
            max = steps
            progress = (((initial.coerceIn(min, maxValue) - min) / (maxValue - min)) * steps).toInt().coerceIn(0, max)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = min + (maxValue - min) * progress / steps
                    valueText.text = "$label: ${"%.2f".format(java.util.Locale.US, value)}"
                    if (fromUser) prefs.edit().putFloat(key, value).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        })
    }

    private fun closePanel() {
        activePanelView?.let { runCatching { windowManager.removeView(it) } }
        activePanelView = null
    }

    private fun menuButton(label: String, action: () -> Unit) = Button(context).apply {
        text = label
        isAllCaps = false
        textSize = 12f
        setTextColor(Color.WHITE)
        setOnClickListener { action() }
    }

    private fun showMessage(message: String) {
        ball?.contentDescription = message
    }

    private fun circleBackground() = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.rgb(10, 35, 66))
        setStroke(dp(2), Color.rgb(35, 160, 255))
    }

    private fun roundedBackground(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        setStroke(dp(1), Color.rgb(35, 130, 220))
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else WindowManager.LayoutParams.TYPE_PHONE

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    companion object
}
