package com.mt7.keymapper.service

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * MT7's independent game pointer.
 *
 * This is intentionally drawn as a custom Canvas path rather than using
 * android.view.PointerIcon, so its silhouette and accent belong to the mapper.
 * The hosting WindowManager overlay is NOT_TOUCHABLE and does not block game input.
 */
internal class Mt7SoftwareCursorView(
    context: Context,
    private val sizeScale: Float
) : View(context) {
    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 2.35f * density * sizeScale
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0, 205, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.3f * density * sizeScale
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    init {
        isClickable = false
        isFocusable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = density * sizeScale

        // A compact gaming arrow: broader head and angled tail distinguish it
        // from the Android system pointer while keeping the familiar mouse cue.
        val arrow = Path().apply {
            moveTo(2.2f * s, 2.0f * s)
            lineTo(2.2f * s, 31.0f * s)
            lineTo(9.6f * s, 24.0f * s)
            lineTo(14.7f * s, 36.5f * s)
            lineTo(20.2f * s, 34.0f * s)
            lineTo(15.0f * s, 21.7f * s)
            lineTo(27.2f * s, 21.7f * s)
            close()
        }
        canvas.drawPath(arrow, fill)
        canvas.drawPath(arrow, edge)

        // Cyan inner stroke is the MT7 signature and improves contrast on bright HUDs.
        val innerLine = Path().apply {
            moveTo(5.4f * s, 8.0f * s)
            lineTo(5.4f * s, 24.0f * s)
            lineTo(9.4f * s, 20.2f * s)
        }
        canvas.drawPath(innerLine, accent)
    }
}
