# MT7 3.1.0-dev1 — Input Engine diagnostics\n\nConsulte `MT7-3.1.0-DEV1-INPUT-ENGINE.md` para as alterações desta revisão.\n\n# MT7 Keymapper

## 2.6.0 — estabilidade da captura OTG (Android 16)

- A sessão agora detecta também o encerramento inesperado do processo de captura, mesmo quando o caminho `/dev/input/eventN` ainda aparece como acessível.
- Se o leitor do mouse ou do teclado terminar inesperadamente, o MT7 fecha a sessão inteira, libera os contatos virtuais, encerra leitores e uinput e inicia o supervisor de reconexão.
- A reconexão continua redescobrindo os nós USB; não presume que os números `eventN` sejam os mesmos após reconectar.
- Atualizados `versionCode` para 32 e `versionName` para `2.6.0`.
- Requer Root ou Shizuku autorizado durante a reconexão.

Consulte `docs/MT7-2.6.0.md` e `docs/USB-RECONNECT-AUTO-2.5.2.md`.

> **Validação:** esta revisão de código ainda precisa passar pela compilação Gradle/NDK e por testes físicos no Android 16. O ZIP contém o projeto-fonte, não um APK validado.


## Implementado na versão 2.0.0
- Serviço de acessibilidade opcional para receber teclas globais e eventos de mouse.
- Conversão dos controles selecionados em gestos de toque Android.
- WASD movimenta o joystick virtual; espaço e clique esquerdo acionam o ponto de tiro; clique direito aciona o ponto de mira.
- Movimento do mouse gera pequenos gestos de arrasto na área de visão, com sensibilidade X/Y independente.
- Captura global de movimento do mouse usa `AccessibilityService.onMotionEvent` e `setMotionEventSources`, disponíveis a partir do Android 14 (API 34).
- O mapeamento só captura eventos do mouse enquanto o serviço está ativo; ao pausar/parar, remove as fontes de movimento e deixa o mouse passar normalmente.
- Posições e sensibilidade usam o perfil selecionado no laboratório local.
- A central de permissões inclui o atalho para ativar o serviço de acessibilidade.

## Limitações e compatibilidade
- O usuário precisa ativar manualmente o serviço MT7 em Configurações > Acessibilidade e conceder sobreposição para usar a bolinha.
- No Android 13 e anteriores, o filtro de teclado pode funcionar, mas a captura global de movimento do mouse via `onMotionEvent` não está disponível; para mouse global, use Android 14 ou superior.
- Os controles são fixos nesta primeira versão: WASD, espaço, botão esquerdo e botão direito. A roda do mouse e remapeamento individual de teclas ainda não estão implementados.
- A movimentação da visão é convertida em pequenos gestos de arrasto; a resposta depende do HUD, da escala e do comportamento do jogo. Ajuste as posições do perfil para combinar com o HUD.
- O backend Root e a integração privilegiada Shizuku continuam fora desta implementação. Não é necessário Root nem Shizuku para o modo de acessibilidade.
- A compilação e os testes em aparelho físico ainda precisam ser executados. Este ZIP é código-fonte, não APK validado.

## Próximas etapas
1. Conectar solicitação runtime de notificações (Android 13+).
2. Implementar a bolinha com overlay e controles de recolher/suspender.
3. Implementar persistência dos perfis e parâmetros decimais X/Y.
4. Implementar e testar backends de entrada compatíveis, sem contornar proteções de jogos ou do Android.

## v0.4 - bolinha flutuante (estrutura inicial)

- Dois toques na bolinha MT7 abrem/fecham o menu.
- A bolinha pode ser arrastada pela tela.
- O menu oferece ações de suspender/reativar visualmente, recolher e parar o serviço.
- O serviço de primeiro plano mantém a sobreposição enquanto o Android permitir.

**Limitação importante:** esta versão ainda não injeta eventos de mouse/teclado em outros aplicativos. O botão de suspensão altera o estado visual do protótipo; ele será ligado ao motor de entrada quando o backend autorizado estiver implementado. O item Visão/Sensibilidade é apenas um ponto de entrada para a próxima etapa.

Para testar, conceda a permissão "Sobrepor a outros apps" nas configurações do Android e toque em "Iniciar serviço MT7" na tela principal. Para parar, use "PARAR SERVIÇO" no menu ou encerre o serviço pela notificação/sistema.

## v0.5 - Painel de visão (configuração local)
- Sensibilidade X/Y independente, com passo de 0,01 e faixa de 0,05 a 10,00.
- Frequência selecionável de 125, 250, 500 ou 1000 Hz; padrão 250 Hz.
- Preferências salvas localmente em SharedPreferences.
- Estes controles armazenam configuração; não alteram a taxa física do mouse nem implementam injeção de eventos. A frequência efetiva depende do dispositivo, periférico e backend.


## v0.6 - Vision transform engine

- Added a deterministic linear X/Y pointer-delta transform in Kotlin.
- Updated the JNI/C++ bridge to apply independent X/Y sensitivity and reject
  non-finite values or out-of-range sensitivity values.
- Added tests for decimal sensitivity values (0.1 / 0.2), independent axes,
  and linear gain.
- The 250 Hz selection remains a configuration value only. This release does
  not change the physical mouse polling rate or implement Android input capture
  or injection. Device-level input integration remains a separate backend task.
- Acceleration protection means the MT7 transform does not add speed-dependent
  gain. It cannot disable game-side recoil, spread, aim behavior, or anti-cheat.
- Build and device validation have not yet been performed.


## v0.7 - Abas separadas de ativação

- Criadas abas independentes para Shizuku, Root e permissões Android.
- Shizuku mostra o estado do Binder e permite solicitar autorização ao usuário.
- Root aparece como backend separado, explicitamente pendente de implementação.
- Botão para iniciar apenas o serviço local do MT7, após conceder sobreposição.
- Nenhuma injeção de entrada em aplicativos terceiros é implementada nesta versão.
- A aba Root não executa comandos privilegiados nem solicita superusuário ainda.
- Compilação e testes em dispositivo físico ainda pendentes.


## v0.8 - Backends de ativação separados

- Criado `ShizukuBackend`, com inspeção do Binder e autorização explícita do MT7.
- Criado `RootBackend`, separado, que apenas procura binários `su` em locais comuns.
- A verificação Root não executa `su`, não solicita superusuário e não executa comandos privilegiados.
- A tela Shizuku recebe o resultado do pedido de autorização e permite atualizar o estado.
- A tela Root diferencia "binário encontrado" de "acesso Root autorizado"; esta última etapa ainda não existe.
- Não há captura/injeção de mouse ou teclado em jogos ou outros apps nesta versão.
- Não há tentativa de contornar anti-cheat ou restrições de segurança do Android.
- Compilação e teste em dispositivo físico ainda pendentes.


## v0.9: ciclo de vida do motor local
Consulte `docs/RUNTIME-v0.9.md`. Esta versão adiciona uma máquina de estados e processamento local de deltas fornecidos pelo próprio código, sem captura ou injeção de entrada em outros aplicativos. Os testes foram adicionados, mas ainda não foram executados neste ambiente.


## v1.0
Consulte `docs/LOCAL-TEST-v1.0.md` para o laboratório de eventos locais e seus limites.


## v1.1
Perfis locais com sensibilidade X/Y editável e persistência. Consulte `docs/PROFILES-v1.1.md`.


## v1.2
Configuração e simulação local do joystick, com zona morta e sensibilidade X/Y persistidas nos perfis. Consulte `docs/JOYSTICK-v1.2.md`.


## v1.3
Consulte `docs/FIRE-STATE-v1.3.md`. O laboratório local agora simula o botão de atirar nos modos Toque, Segurar e Alternar. O modo é salvo em cada perfil; perfis antigos assumem Toque. Esta versão não captura nem injeta entradas em outros aplicativos ou jogos.


## v1.4 - posições locais

A v1.4 adiciona configuração e prévia proporcional das posições X/Y do joystick, área de visão e botão de atirar, persistidas por perfil. Consulte `docs/CONTROL-POSITIONS-v1.4.md`.


## v1.5: editor de posições por arraste

A prévia proporcional agora permite selecionar e arrastar diretamente os marcadores de Joystick, Visão e Atirar. As coordenadas são normalizadas entre 0.0 e 1.0 e continuam sendo gravadas pelo fluxo de salvamento de perfil já existente. Os controles deslizantes X/Y permanecem disponíveis para ajuste fino. A interação altera somente a configuração local da prévia; não captura nem injeta eventos em outros aplicativos.


## v1.6 - validação do editor

A geometria de seleção e normalização dos marcadores foi extraída para `ControlPositionMath`, com testes para hit radius, seleção do marcador mais próximo, clamp e limites de tamanho zero. Consulte `docs/VALIDATION-v1.6.md` para o resultado e as limitações da validação disponível.


## v1.7.0 — sessão local integrada

- `LocalMappingSession` coordena o ciclo de vida local, o processamento de movimento relativo, a transformação do joystick e o estado do botão de atirar.
- Eventos de ponteiro e joystick só são processados quando a sessão está em `READY`.
- Pausar ou parar limpa o estado pressionado do botão de teste, evitando que o simulador fique preso em `HOLD`.
- A tela Laboratório usa a sessão integrada para os testes de ponteiro, joystick e botão.
- O backend Android usado no botão Iniciar é explicitamente um backend local de diagnóstico, não uma autorização de injeção.

**Limites:** esta sessão recebe somente valores gerados pelos controles do próprio aplicativo. Não lê dispositivos, não captura eventos globais, não injeta entrada em outros aplicativos e não interage com Free Fire. A indicação `READY` significa apenas que o simulador local está pronto.

## v1.8.0 - diagnóstico de dispositivos

- Nova aba de diagnóstico para dispositivos de entrada que o Android expõe ao aplicativo.
- Identifica fontes como mouse, teclado, gamepad, joystick, direcional e tela touch, além de alguns metadados do dispositivo.
- Inclui atualização manual e testes unitários da classificação.
- Corrige a área do laboratório local para permitir rolagem em telas menores.
- A leitura é somente de inventário: não captura eventos, não injeta entrada em jogos e não altera o comportamento do Free Fire.

## Preparar um APK de teste

Este pacote contém o projeto-fonte, não um APK pronto. Para gerar o APK, abra a pasta `MT7-Keymapper` no Android Studio em um computador, instale Android SDK Platform 37, NDK e CMake 3.22.1 pelo SDK Manager e sincronize as dependências Gradle. Depois use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de debug normalmente é criado em `app/build/outputs/apk/debug/app-debug.apk`.

A compilação Android completa ainda não foi executada neste ambiente porque não há Android SDK/Gradle instalados e a conexão de rede para baixar essas ferramentas está indisponível. O ZIP também não inclui os scripts/JAR do Gradle Wrapper; gere-os conforme `BUILD-APK-PT-BR.md`. Portanto, este pacote não deve ser tratado como APK já compilado ou validado em aparelho.


## v1.9.0 — primeira etapa do mouse (MT7 Keymouse)

- Marca exibida atualizada para MT7 Keymouse.
- Nova aba Mouse com inventário dos mouses expostos ao aplicativo.
- Área de teste local para movimento, clique esquerdo/direito/meio e roda de rolagem, quando o Android entrega esses eventos à tela do MT7.
- Sensibilidade linear X/Y ajustável de 0,10x a 5,00x para visualizar os deltas transformados.
- Contadores e botão para zerar as medições.

**Limites desta etapa:** a leitura acontece somente dentro da área de teste enquanto o MT7 está em primeiro plano. Não há captura global, captura em segundo plano nem injeção de eventos em outros aplicativos/jogos. Os valores X/Y são uma prévia local e ainda não são aplicados ao cursor do sistema ou a jogos. A taxa física/polling do mouse não é alterada.

**Validação:** o código-fonte foi atualizado, mas a compilação Android e o teste em dispositivo físico não foram executados neste ambiente (Android SDK/Gradle não estão disponíveis).


## v2.0.0 — ponte global de mouse e teclado

- Adicionado `MT7AccessibilityService`, com filtro global de teclas e captura de fontes de mouse no Android 14+.
- WASD mantém um gesto no joystick virtual; ao soltar as teclas, o MT7 encerra o gesto.
- Espaço/clique esquerdo acionam o ponto de tiro; clique direito aciona o ponto de mira.
- Movimento relativo do mouse é convertido em arrastos curtos na área de visão, respeitando sensibilidade X/Y.
- A bolinha agora ativa, pausa e desativa a captura global junto ao serviço em primeiro plano.
- O serviço só registra fontes globais do mouse enquanto o mapeamento está ativado, evitando bloquear o mouse quando pausado.
- A ativação exige consentimento explícito do usuário nas configurações de Acessibilidade.
- Posições de joystick, visão e tiro e sensibilidade X/Y são sincronizadas a partir do perfil selecionado.
- Ainda falta validação de compilação e teste real em dispositivo; a captura de mouse depende da implementação do fabricante e da API 34+.


## Versão 2.0.1 — diagnóstico OTG automático

- A tela **Dispositivos de entrada** atualiza o inventário Android automaticamente a cada 1 segundo enquanto estiver aberta.
- Isso permite observar a conexão e remoção de mouse/teclado USB OTG sem precisar tocar em Atualizar.
- A leitura continua sendo somente inventário via `InputDevice`; não representa captura contínua de eventos. A captura pelo serviço de acessibilidade depende de ativação do serviço e de o Android entregar os eventos ao aplicativo.
- Esta versão é baseada exclusivamente no código-fonte 2.0.0 fornecido nesta conversa; não usa a versão 1.8.0.

## Captura global de mouse e teclado (2.1.0)

A ponte global usa o `MT7AccessibilityService`:

- Teclado: `FLAG_REQUEST_FILTER_KEY_EVENTS`; WASD controla o joystick virtual e Espaço aciona o ponto de disparo. Outras teclas são observadas no diagnóstico, mas não são consumidas.
- Mouse: no Android 14 ou superior, o serviço solicita fontes `SOURCE_MOUSE` e `SOURCE_MOUSE_RELATIVE`; registra movimento, botões, scroll e dispositivo de origem. Botão esquerdo/direito acionam os pontos configurados.
- O painel **Laboratório de mouse** mostra contadores dos eventos que realmente chegaram ao serviço, separado da lista de dispositivos detectados pelo Android.

Para testar: habilite o Serviço de acessibilidade MT7 nas configurações do Android, inicie o serviço flutuante e deixe o mapeamento ativo. Abra o Laboratório de mouse, conecte o hub OTG e mova/clique/digite. Os contadores globais devem aumentar. A lista de dispositivos, isoladamente, não comprova captura de eventos.

Limitações: captura global de movimento do mouse pelo callback de acessibilidade requer Android 14 (API 34) ou superior. O serviço precisa estar habilitado pelo usuário. Esta versão ainda precisa ser compilada e testada no aparelho; o código-fonte não comprova compatibilidade com todos os firmwares/implementações de acessibilidade.


## v2.2 — diagnóstico real dos backends Root + Shizuku

Consulte `docs/BACKENDS-BOTH-v2.2.md`. O backend Root agora confirma autorização executando somente `su -c id` com timeout de 3 segundos; Shizuku confirma Binder e permissão concedida. O repositório expõe `inspectBothNow()` para apresentar os estados dos dois backends. Isso ainda não implementa injeção privilegiada de entrada; o mapeamento atual continua baseado em acessibilidade.


## v2.3.0 — primeira camada de injeção privilegiada sem Acessibilidade

- O serviço de acessibilidade foi removido do Manifest: o MT7 não solicita nem usa Acessibilidade para injetar toques.
- `TouchInjectionRepository` detecta automaticamente Root primeiro e Shizuku em seguida.
- Implementados comandos de toque simples (`input tap`) e arrasto (`input swipe`) por meio do utilitário Android `input`, executados no backend privilegiado selecionado.
- O executor Shizuku verifica Binder e autorização antes de iniciar o processo; Root verifica `uid=0`.
- A bolinha e o serviço em primeiro plano deixaram de ativar/desativar o serviço de acessibilidade.

**Limites desta etapa:** isto é a primeira camada de transporte de injeção, não o mapeador completo OTG. O app ainda não lê globalmente eventos USB de teclado/mouse fora de sua janela; isso exige um leitor privilegiado de `/dev/input/event*` com permissões compatíveis no firmware. O transporte atual usa `input tap/swipe`, não cria touchscreen virtual via `/dev/uinput` e não fornece multitouch simultâneo/joystick contínuo. A detecção `auto` prefere Root e usa Shizuku como alternativa; Shizuku em modo ADB pode não ter permissões de injeção em todos os Androids.

**Validação:** o código foi atualizado, mas não foi compilado nem executado em aparelho físico neste ambiente. A próxima etapa é implementar a captura OTG privilegiada (getevent/event nodes), testar acesso real aos dispositivos e depois ligar os eventos ao motor de mapeamento.


## Estado atual da revisão 2.3.1

Consulte `docs/ANDROID16-2.3.1.md` para compatibilidade Android 16 e limitações reais. As seções históricas abaixo descrevem versões anteriores e não significam que a captura global OTG esteja pronta.


## Revisão 2.3.2

Leitor inicial de eventos OTG: consulte `docs/OTG-EVENT-READER-2.3.2.md`. Ele enumera e lê eventos via getevent, mas ainda não está ligado ao mapeamento ou à injeção.

## Revisão 2.3.3

Integração inicial do leitor OTG ao painel **Dispositivos**. Agora é possível buscar nós privilegiados `/dev/input/eventN`, selecionar um dispositivo e visualizar eventos recentes via `getevent`. O executor de comandos foi ajustado para consumir a saída durante a execução e evitar bloqueio de pipe. Consulte `docs/OTG-DIAGNOSTICS-2.3.3.md` e `docs/VALIDATION-2.3.3.md`.

**Atenção:** 2.3.3 ainda é captura/diagnóstico somente de leitura. Não converte teclado/mouse em controles do Free Fire e não injeta multitouch. A compilação e o teste físico precisam ser feitos antes de considerar a captura validada.


## Revisão 2.3.4

Adicionada a camada `OtgEventMapper`, que interpreta teclas comuns (incluindo WASD e Espaço), botões do mouse, movimento relativo e scroll. O painel de Dispositivos passa a exibir ações interpretadas junto dos eventos brutos. `MappingRuntime.processInput` aplica a barreira de autorização e estado antes de devolver uma ação semântica. Isso ainda não injeta eventos no Free Fire nem implementa `uinput`/multitouch. Consulte `docs/OTG-MAPPING-2.3.4.md`. A compilação e o teste físico ainda precisam ser realizados.

## v2.3.5 — pré-diagnóstico uinput

Consulte `docs/UINPUT-PREFLIGHT-2.3.5.md`. O painel de dispositivos agora verifica, por Root (preferencial) ou Shizuku, a presença de `/dev/uinput` ou `/dev/input/uinput`, permissões de leitura/escrita, presença do módulo e modo SELinux. É um diagnóstico somente de leitura: ainda não cria dispositivo virtual nem injeta multitouch. Build e teste no Redmi Note 14 4G permanecem pendentes.


## v2.3.6 — protocolo multitouch em memória

Consulte `docs/UINPUT-TOUCH-PROTOCOL-2.3.6.md`. Foi adicionada uma máquina de estados Kotlin que constrói quadros Linux multi-touch (slots, tracking IDs, coordenadas, BTN_TOUCH e SYN_REPORT), com suporte configurável a múltiplos contatos, limites de coordenadas e cancelamento seguro. Ela ainda não abre `/dev/uinput`, não cria um dispositivo virtual e não injeta eventos. A próxima etapa é implementar o transporte privilegiado nativo e conectá-lo ao ciclo de vida do mapeamento, com encerramento/liberação de contatos garantidos.

## Versão 2.3.7 — preflight nativo uinput

Foi adicionado o helper C++ `mt7-uinput-probe`, que configura e cria/remove um dispositivo touchscreen virtual para verificar a operação real `UI_DEV_CREATE`, sem emitir eventos de toque. O helper está declarado no CMake, e `UinputProbeResult` interpreta seus resultados. **Nesta versão o binário ainda não é empacotado/iniciado pelo app**; a integração privilegiada Root/Shizuku e o transporte de eventos permanecem como etapas seguintes. Consulte `docs/UINPUT-PROBE-2.3.7.md`.


## Versão 2.3.8 — executor do probe uinput

Adicionado executor Kotlin que tenta o helper nativo via Root primeiro e Shizuku como fallback. O teste cria e destrói o dispositivo virtual sem enviar eventos de toque. Consulte `docs/UINPUT-PROBE-RUNNER-2.3.8.md`.

## Versão 2.3.9 — transporte persistente uinput

Adicionado o modo persistente do helper nativo para criar um touchscreen virtual multitouch e receber comandos `D/M/U/C/Q` por stdin. A classe `UinputTouchSession` executa o helper com Root primeiro e aceita Shizuku apenas após confirmação de criação do dispositivo. O transporte ainda precisa ser conectado ao `MappingRuntime` e ao leitor OTG; não declarar esta versão como jogável. Consulte `docs/UINPUT-SESSION-2.3.9.md`.

## Versão 2.4.0 — integração OTG → mapeamento → uinput

O transporte persistente `UinputTouchSession` agora implementa a interface `MultiTouchOutput`. Foi adicionado `OtgTouchMappingController`, que converte WASD em um contato de joystick, mouse direito + movimento relativo em arrasto de câmera, mouse esquerdo em botão de disparo e Espaço/R/F em contatos de ação. `MappingRuntime.processAndInject` faz a passagem dos eventos sem permitir injeção quando o runtime não está pronto. `PrivilegedOtgMappingSession` coordena a criação do touchscreen virtual, a captura do nó OTG e o encaminhamento dos eventos; pause/stop/fechamento liberam os contatos.

O layout inicial é apenas um ponto de partida e precisa de editor/calibração de HUD e coordenadas por orientação. Esta integração de classes ainda não equivale a um APK validado nem a uma versão pronta para jogar. O helper nativo foi ajustado para não acumular registros de contatos já liberados durante sessões longas.


## 2.4.2 — polling Hz e suspensão da seta

- Preferência de taxa: 125, 250, 500 e 1000 Hz, salva no perfil. Isso representa a taxa-alvo/preferência de processamento; Android não consegue reprogramar o polling físico do firmware do mouse por esta configuração.
- Opção “Suspender seta ao mirar”: a camada de mapeamento emite estado `true` ao pressionar o botão direito e `false` ao soltar ou cancelar a sessão. O adaptador de plataforma ainda precisa consumir esse callback para ocultar o cursor do sistema; a ocultação global sobre outro jogo não é garantida nesta versão.
- Sensibilidade X/Y ajustável em passos de 0,1 (0,1 a 10,0) no painel flutuante.


## v2.4.3 — botões configuráveis e modo de visão independente

- Corrigido o mapeamento para que o botão esquerdo seja exclusivamente o tiro.
- O botão direito deixou de controlar a visão e passou a executar uma ação comum configurável (`Nenhuma`, `ESPAÇO`, `R` ou `F`).
- Scroll para cima e para baixo agora possuem ações separadas configuráveis.
- O modo de visão é alternado por um binding independente, com clique do botão do meio como padrão; pode ser substituído por uma tecla reconhecida, por exemplo X.
- Movimento relativo do mouse só move o contato de visão quando esse modo está ativo. Autorepeat do binding não alterna o modo várias vezes.
- Novas opções são persistidas por perfil.
- Na versão 2.4.3, o callback era apenas lógico. A implementação nativa de `EVIOCGRAB` sob demanda entrou na 2.4.4; a ocultação visual global do cursor ainda não é garantida.
- Validação local do núcleo Kotlin e smoke test passaram; build Gradle completo e teste físico ainda pendentes.
- Detalhes: `docs/OTG-MOUSE-VIEW-2.4.3.md`.


## Versão 2.4.4 — captura nativa EVIOCGRAB

Foi adicionado o helper `libmt7-input-grab.so` e a API `OtgInputEventReader.startNativeCapture`. O leitor nativo permanece ativo, mas o grab exclusivo só é ligado (`G`) quando o modo de visão é ativado e desligado (`R`) ao sair do modo. Ao fechar a sessão, o helper recebe `Q` e libera o descritor. Consulte `docs/OTG-NATIVE-GRAB-2.4.4.md` para limitações, seleção do event node e validações pendentes.


## 2.4.5 — estabilidade do modo visão

A captura EVIOCGRAB é aplicada apenas ao nó selecionado como mouse. Para dispositivos que expõem teclado e mouse em nós separados, `PrivilegedOtgMappingSession.start` aceita também `keyboardDevicePath`; o teclado continua sendo lido sem grab. O modo visão limita o contato virtual a uma área segura no lado direito da tela, corrige o sentido do scroll Linux e sai do modo/libera contatos se o grab falhar. A captura exclusiva congela o cursor do sistema, mas não garante que o desenho da seta desapareça globalmente.


## MT7 2.4.5 — visão e cursor

Esta revisão melhora a captura exclusiva do mouse, permite informar um event node separado para o teclado, limita e reancora o contato virtual da câmera, corrige o sentido do scroll e trata falhas de escrita no uinput. Os helpers nativos são copiados pelo CMake para `build/generated/mt7-jniLibs/<abi>` e incluídos pelo Gradle no APK. Consulte `docs/OTG-VIEW-STABILITY-2.4.5.md` para limitações e parâmetros.


## v2.4.6 — seleção OTG e confirmação de captura

- Atribuição separada de nós event como mouse e teclado no painel Dispositivos.
- Preferências dos nós selecionados persistidas localmente e reavaliadas após nova enumeração.
- Captura nativa EVIOCGRAB no nó escolhido como mouse; teclado separado continua via getevent sem grab.
- Confirmação do kernel aguardada por até 900 ms; falhas de ioctl/timeouts não são tratadas como sucesso.
- Despacho dos eventos em executor separado para não bloquear a leitura das confirmações do helper.
- O painel oferece ativação/liberação manual do grab para diagnóstico.

**Limitação:** EVIOCGRAB interrompe a entrega de eventos aos demais consumidores, mas não garante apagar a imagem do cursor globalmente. A ocultação global no Free Fire e a ligação da sessão completa ao serviço de jogo continuam pendentes.

## Integração do serviço OTG privilegiado (2.4.8-dev)

O `MT7InputService` aceita `ACTION_START_MAPPING` para iniciar a sessão completa
`PrivilegedOtgMappingSession`. A chamada exige um caminho de mouse válido em
`EXTRA_MOUSE_DEVICE_PATH` (por exemplo, `/dev/input/eventN`), aceita um caminho
opcional de teclado em `EXTRA_KEYBOARD_DEVICE_PATH` e um identificador opcional
de perfil em `EXTRA_PROFILE_ID`. A sessão tenta o transporte UInput usando Root
e faz fallback para Shizuku conforme a implementação de `UinputTouchSession`.

O serviço encerra a sessão e libera os dispositivos ao ser destruído; pause/resume
liberam e retomam os controles mapeados. O início ainda depende de o usuário
selecionar previamente o nó correto de mouse/teclado no diagnóstico privilegiado.
Confirme fabricante/capacidades no painel de diagnóstico antes de iniciar a captura
exclusiva do mouse.

## 2.4.8 — captura OTG e início do mapeamento

- A tela Avançado > Dispositivos permite iniciar a sessão real de mapeamento usando os nós Linux selecionados para mouse e teclado.
- A sessão do teclado também usa o capturador nativo empacotado, em vez de depender do binário `getevent` para a captura contínua.
- O serviço recebe os caminhos selecionados e o perfil ativo, e mantém a sessão enquanto o serviço em primeiro plano estiver ativo.

A compatibilidade depende das permissões efetivas de Root/Shizuku, acesso a `/dev/input`, disponibilidade de uinput e política SELinux do aparelho. Esta versão-fonte ainda precisa ser compilada e validada em hardware Android real.


## v2.5.0 — detecção automática de HUB USB OTG

Consulte `docs/HUB-USB-AUTO-DETECT-2.5.0.md`. A tela de dispositivos agora classifica os nós do `getevent -pl` e tenta selecionar automaticamente mouse e teclado, incluindo receptores HID compostos em um único nó. A compilação Android e o teste físico ainda precisam ser executados.

## MT7 3.2.0-dev1

Veja `MT7-3.2.0-DEV1-INPUT-STATE.md` para as melhorias no tratamento de autorepeat e limpeza do estado de entrada.


## MT7 3.3.0-dev1

Fila serial de eventos OTG e suporte inicial a combos de teclas em `TouchLayout`. Consulte `MT7-3.3.0-DEV1-INPUT-QUEUE-COMBOS.md`.

## MT7 3.4.0-dev1

Editor visual de combos por perfil, persistência local e integração com `TouchLayout.fromProfile`. Consulte `MT7-3.4.0-DEV1-COMBO-PROFILE-EDITOR.md`.

## MT7 3.5.0-dev1 — Editor visual

A versão 3.5.0-dev1 adiciona uma prévia de tela com marcadores arrastáveis para joystick, mira, disparo e teclas livres. As posições são gravadas no perfil local. Consulte `MT7-3.5.0-DEV1-EDITOR-VISUAL.md` para instruções e limitações.


A versão 3.6.0-dev1 adiciona calibração visual usando uma captura de tela escolhida pelo usuário, com proporção preservada e imagem vinculada ao perfil. Consulte `MT7-3.6.0-DEV1-CALIBRACAO-CAPTURA.md` para instruções e limitações.
\n\n## MT7 3.7.0-dev1 — Calibração integrada\n\nConsulte `MT7-3.7.0-DEV1-CALIBRACAO-INTEGRADA.md` para as correções, teste de integração do perfil e limitações de validação.\n

## MT7 3.8.0-dev1 — Diagnóstico e recuperação de backend

Consulte `MT7-3.8.0-DEV1-BACKEND-HEALTH.md` para o estado de saúde do caminho uinput, registro de falhas, critérios de degradação e limitações de recuperação.


## MT7 3.9.0-dev1 — Live Diagnostics
Consulte `MT7-3.9.0-DEV1-LIVE-DIAGNOSTICS.md` para o painel de diagnóstico e suas limitações atuais.


## Seta própria do MT7 (DEV13)

Com a opção **Usar seta própria do MT7** ativada, o mapeador captura o mouse USB com EVIOCGRAB, desenha uma seta independente em overlay transparente e move essa seta pelos deltas do mouse. A seta do Android volta quando o mapeador é pausado, desativado ou encerrado. A camada visual é não clicável e não bloqueia o HUD do jogo.
